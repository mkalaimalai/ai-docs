"""Tests for the query engine templates and natural language routing."""

import pytest
from unittest.mock import MagicMock, patch

from src.query.engine import QueryEngine, QUERY_TEMPLATES


class TestQueryTemplates:
    """Verify that all query templates are well-formed."""

    def test_all_templates_have_required_fields(self):
        for name, template in QUERY_TEMPLATES.items():
            assert "description" in template, f"{name} missing description"
            assert "cypher" in template, f"{name} missing cypher"
            assert "params" in template, f"{name} missing params"
            assert isinstance(template["params"], list), f"{name} params must be a list"

    def test_all_templates_have_valid_cypher(self):
        """Basic syntax check — all templates should contain MATCH or CALL."""
        for name, template in QUERY_TEMPLATES.items():
            cypher = template["cypher"].strip().upper()
            assert "MATCH" in cypher or "CALL" in cypher, f"{name} has no MATCH or CALL"

    def test_template_count(self):
        """Ensure we have a reasonable number of templates."""
        assert len(QUERY_TEMPLATES) >= 7, "Expected at least 7 query templates"


class TestNaturalLanguageRouting:
    """Test that natural language questions route to correct templates."""

    @pytest.fixture
    def engine(self):
        mock_graph = MagicMock()
        mock_graph.run_query.return_value = []
        mock_graph.session.return_value.__enter__ = MagicMock()
        mock_graph.session.return_value.__exit__ = MagicMock()
        return QueryEngine(mock_graph)

    def test_dependency_routing(self, engine):
        """Questions about dependencies should route to service_dependencies."""
        with patch.object(engine, 'run_template', return_value=[]) as mock:
            engine.natural_language_query('What services depend on "PaymentService"?')
            mock.assert_called_once()
            call_args = mock.call_args
            assert call_args[0][0] == "service_dependencies"

    def test_hot_paths_routing(self, engine):
        with patch.object(engine, 'run_template', return_value=[]) as mock:
            engine.natural_language_query("Show me the hottest code paths")
            mock.assert_called_once()
            assert mock.call_args[0][0] == "hot_paths"

    def test_dead_code_routing(self, engine):
        with patch.object(engine, 'run_template', return_value=[]) as mock:
            engine.natural_language_query("Find unused dead code")
            mock.assert_called_once()
            assert mock.call_args[0][0] == "dead_code"

    def test_error_routing(self, engine):
        with patch.object(engine, 'run_template', return_value=[]) as mock:
            engine.natural_language_query("Which endpoints have the highest error rates?")
            mock.assert_called_once()
            assert mock.call_args[0][0] == "error_paths"

    def test_entity_extraction_quoted(self, engine):
        name = engine._extract_entity_name('What depends on "OrderService"?')
        assert name == "OrderService"

    def test_entity_extraction_pascal_case(self, engine):
        name = engine._extract_entity_name("Show blast radius for PaymentController")
        assert name == "PaymentController"
