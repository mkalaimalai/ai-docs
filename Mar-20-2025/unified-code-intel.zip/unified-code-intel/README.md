# Unified Code Intelligence Platform

A multi-layer code intelligence system that merges **static code analysis**, **runtime observability**, **infrastructure-as-code**, and **organizational knowledge** into a single Neo4j graph — queryable by LLM agents via MCP.

## Architecture

```
┌─────────────────────────────────────────────┐
│           LLM AGENT LAYER (MCP)             │
│     Claude Code · Custom Agents · CLI       │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│          QUERY & ORCHESTRATION              │
│    Cypher · Vector Search · GraphRAG        │
└──────────────────┬──────────────────────────┘
                   │
     ┌─────────────┴─────────────┐
     ▼                           ▼
┌──────────────┐  ┌──────────────────────────┐
│  KNOWLEDGE   │  │       CODE GRAPH         │
│  GRAPH       │  │  ┌────────────────────┐  │
│              │  │  │  Static Layer      │  │
│ • Patterns   │  │  │  (AST / LST)       │  │
│ • Standards  │  │  ├────────────────────┤  │
│ • ADRs       │  │  │  Runtime Layer     │  │
│ • Postmortems│  │  │  (OTel + Logs)     │  │
│              │  │  ├────────────────────┤  │
│              │  │  │  Infra Layer       │  │
│              │  │  │  (Terraform/K8s)   │  │
│              │  │  └────────────────────┘  │
└──────┬───────┘  └────────────┬─────────────┘
       └───────────┬───────────┘
                   ▼
          ┌────────────────┐
          │     Neo4j      │
          │  + Embeddings  │
          └────────────────┘
```

## Quick Start

```bash
# Start all services
docker compose up -d

# Wait for Neo4j to be ready
./scripts/wait-for-neo4j.sh

# Run the full ingestion pipeline
python -m src.main ingest --repo /path/to/your/repo

# Query the graph
python -m src.main query "What services call PaymentService?"

# Start the MCP server
python -m src.main mcp-server
```

## Project Structure

```
unified-code-intel/
├── docker-compose.yml          # Neo4j + app services
├── Dockerfile                  # Application container
├── pyproject.toml              # Python dependencies
├── src/
│   ├── main.py                 # CLI entry point
│   ├── graph.py                # Neo4j connection manager
│   ├── layers/
│   │   ├── static_layer.py     # AST/LST code parsing → graph
│   │   ├── runtime_layer.py    # OTel traces + logs → graph
│   │   ├── infra_layer.py      # Terraform/K8s → graph
│   │   └── knowledge_layer.py  # Docs/patterns → graph
│   ├── ingestion/
│   │   └── pipeline.py         # Orchestrates all layers
│   ├── query/
│   │   ├── engine.py           # Cypher + vector hybrid search
│   │   └── templates.py        # Pre-built query templates
│   ├── agents/
│   │   └── mcp_server.py       # MCP server for LLM agents
│   └── utils/
│       ├── embeddings.py       # Text embedding utilities
│       └── config.py           # Configuration management
├── config/
│   └── settings.yaml           # Default settings
├── scripts/
│   ├── wait-for-neo4j.sh       # Health check script
│   ├── seed-demo.py            # Demo data seeder
│   └── setup-constraints.cypher# Neo4j schema constraints
├── tests/
│   ├── test_static_layer.py
│   ├── test_runtime_layer.py
│   └── test_query_engine.py
└── README.md
```

## Layers

### Static Layer
Parses source code using Tree-sitter into AST nodes. Extracts classes, methods, functions, imports, and their relationships. Writes to Neo4j as `Class`, `Method`, `Function`, `Module` nodes with `CALLS`, `IMPORTS`, `CONTAINS`, `IMPLEMENTS` edges.

### Runtime Layer
Ingests OpenTelemetry trace JSON exports and structured application logs. Creates `Trace`, `Span`, `LogEntry` nodes linked to static code entities via `code.function` and `service.name` attributes. Adds runtime metrics like latency, error rate, and call frequency as edge properties.

### Infrastructure Layer
Parses Terraform HCL files and Kubernetes YAML manifests. Creates `TerraformResource`, `K8sService`, `K8sPod`, `K8sDeployment` nodes. Links infrastructure to code services via naming conventions and label matching.

### Knowledge Layer
Ingests markdown documents (ADRs, post-mortems, runbooks, best practices) using LLM-powered entity extraction. Creates `Pattern`, `Standard`, `Decision`, `Lesson` nodes linked to relevant code entities.

## Configuration

Copy `config/settings.yaml` and customize:

```yaml
neo4j:
  uri: bolt://localhost:7687
  user: neo4j
  password: changeme

embedding:
  model: all-MiniLM-L6-v2    # local sentence-transformers model
  dimension: 384

llm:
  provider: anthropic          # or openai, ollama
  model: claude-sonnet-4-20250514
```

## License

MIT
