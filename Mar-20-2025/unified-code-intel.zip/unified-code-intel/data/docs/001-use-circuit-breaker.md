# ADR-001: Use Circuit Breaker for Payment Service Calls

## Status
Accepted

## Context
The payment service occasionally experiences latency spikes and timeouts. When this happens, the order service threads get blocked, causing cascading failures.

## Decision
All calls from OrderService to PaymentService must be wrapped in a Resilience4j circuit breaker with failure rate threshold 50%, wait duration 30s, sliding window 10 calls.

## Pattern
## Best Practice
Use the Circuit Breaker pattern for all cross-service synchronous calls. The FraudChecker service should also be wrapped.

## Consequences
- Reduced cascade failures during payment service degradation
- Orders will fail fast instead of hanging when payments are down
- Need to implement fallback logic for payment failures
