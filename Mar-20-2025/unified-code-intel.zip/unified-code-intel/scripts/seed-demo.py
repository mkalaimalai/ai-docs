#!/usr/bin/env python3
"""Seed the Neo4j graph with demo data across all four layers.

Usage:
    python scripts/seed-demo.py

Creates a realistic sample graph representing a microservices e-commerce app
so you can explore queries without needing a real codebase.
"""

import json
import os
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.graph import GraphManager
from src.utils.config import load_config


def seed_static_layer(graph: GraphManager):
    """Create sample code entities."""
    print("  Seeding static layer...")

    cypher = """
    // Services as top-level modules
    MERGE (om:Module:CodeEntity {qualified_name: 'order-service'})
    SET om.name = 'order-service', om.language = 'java', om.layer = 'static'

    MERGE (pm:Module:CodeEntity {qualified_name: 'payment-service'})
    SET pm.name = 'payment-service', pm.language = 'java', pm.layer = 'static'

    MERGE (um:Module:CodeEntity {qualified_name: 'user-service'})
    SET um.name = 'user-service', um.language = 'java', um.layer = 'static'

    MERGE (im:Module:CodeEntity {qualified_name: 'inventory-service'})
    SET im.name = 'inventory-service', im.language = 'python', im.layer = 'static'

    MERGE (ns:Module:CodeEntity {qualified_name: 'notification-service'})
    SET ns.name = 'notification-service', ns.language = 'typescript', ns.layer = 'static'

    // Classes
    MERGE (oc:Class:CodeEntity {qualified_name: 'order-service::OrderController'})
    SET oc.name = 'OrderController', oc.language = 'java', oc.file_path = 'src/main/java/OrderController.java', oc.start_line = 15, oc.end_line = 120, oc.layer = 'static'

    MERGE (os_svc:Class:CodeEntity {qualified_name: 'order-service::OrderService'})
    SET os_svc.name = 'OrderService', os_svc.language = 'java', os_svc.file_path = 'src/main/java/OrderService.java', os_svc.start_line = 10, os_svc.end_line = 200, os_svc.layer = 'static'

    MERGE (pc:Class:CodeEntity {qualified_name: 'payment-service::PaymentController'})
    SET pc.name = 'PaymentController', pc.language = 'java', pc.file_path = 'src/main/java/PaymentController.java', pc.start_line = 12, pc.end_line = 85, pc.layer = 'static'

    MERGE (ps:Class:CodeEntity {qualified_name: 'payment-service::PaymentService'})
    SET ps.name = 'PaymentService', ps.language = 'java', ps.file_path = 'src/main/java/PaymentService.java', ps.start_line = 8, ps.end_line = 180, ps.layer = 'static'

    MERGE (fc:Class:CodeEntity {qualified_name: 'payment-service::FraudChecker'})
    SET fc.name = 'FraudChecker', fc.language = 'java', fc.file_path = 'src/main/java/FraudChecker.java', fc.start_line = 5, fc.end_line = 95, fc.layer = 'static'

    MERGE (uc:Class:CodeEntity {qualified_name: 'user-service::UserController'})
    SET uc.name = 'UserController', uc.language = 'java', uc.file_path = 'src/main/java/UserController.java', uc.start_line = 10, uc.end_line = 75, uc.layer = 'static'

    MERGE (ic:Class:CodeEntity {qualified_name: 'inventory-service::InventoryManager'})
    SET ic.name = 'InventoryManager', ic.language = 'python', ic.file_path = 'inventory/manager.py', ic.start_line = 15, ic.end_line = 140, ic.layer = 'static'

    MERGE (ne:Class:CodeEntity {qualified_name: 'notification-service::EmailNotifier'})
    SET ne.name = 'EmailNotifier', ne.language = 'typescript', ne.file_path = 'src/notifiers/email.ts', ne.start_line = 8, ne.end_line = 60, ne.layer = 'static'

    // Methods
    MERGE (m1:Method:CodeEntity {qualified_name: 'order-service::OrderController.createOrder'})
    SET m1.name = 'createOrder', m1.language = 'java', m1.file_path = 'src/main/java/OrderController.java', m1.start_line = 30, m1.end_line = 55, m1.layer = 'static'

    MERGE (m2:Method:CodeEntity {qualified_name: 'order-service::OrderService.processOrder'})
    SET m2.name = 'processOrder', m2.language = 'java', m2.file_path = 'src/main/java/OrderService.java', m2.start_line = 45, m2.end_line = 95, m2.layer = 'static'

    MERGE (m3:Method:CodeEntity {qualified_name: 'payment-service::PaymentService.processPayment'})
    SET m3.name = 'processPayment', m3.language = 'java', m3.file_path = 'src/main/java/PaymentService.java', m3.start_line = 30, m3.end_line = 70, m3.layer = 'static'

    MERGE (m4:Method:CodeEntity {qualified_name: 'payment-service::FraudChecker.checkFraud'})
    SET m4.name = 'checkFraud', m4.language = 'java', m4.file_path = 'src/main/java/FraudChecker.java', m4.start_line = 20, m4.end_line = 65, m4.layer = 'static'

    MERGE (m5:Method:CodeEntity {qualified_name: 'inventory-service::InventoryManager.reserveStock'})
    SET m5.name = 'reserveStock', m5.language = 'python', m5.file_path = 'inventory/manager.py', m5.start_line = 40, m5.end_line = 70, m5.layer = 'static'

    MERGE (m6:Method:CodeEntity {qualified_name: 'notification-service::EmailNotifier.sendOrderConfirmation'})
    SET m6.name = 'sendOrderConfirmation', m6.language = 'typescript', m6.file_path = 'src/notifiers/email.ts', m6.start_line = 20, m6.end_line = 45, m6.layer = 'static'

    MERGE (m7:Method:CodeEntity {qualified_name: 'user-service::UserController.getUser'})
    SET m7.name = 'getUser', m7.language = 'java', m7.file_path = 'src/main/java/UserController.java', m7.start_line = 25, m7.end_line = 40, m7.layer = 'static'

    // Dead code example
    MERGE (dc:Method:CodeEntity {qualified_name: 'order-service::OrderService.legacyExport'})
    SET dc.name = 'legacyExport', dc.language = 'java', dc.file_path = 'src/main/java/OrderService.java', dc.start_line = 180, dc.end_line = 200, dc.layer = 'static'

    // CONTAINS relationships
    MERGE (om)-[:CONTAINS]->(oc)
    MERGE (om)-[:CONTAINS]->(os_svc)
    MERGE (pm)-[:CONTAINS]->(pc)
    MERGE (pm)-[:CONTAINS]->(ps)
    MERGE (pm)-[:CONTAINS]->(fc)
    MERGE (um)-[:CONTAINS]->(uc)
    MERGE (im)-[:CONTAINS]->(ic)
    MERGE (ns)-[:CONTAINS]->(ne)

    MERGE (oc)-[:CONTAINS]->(m1)
    MERGE (os_svc)-[:CONTAINS]->(m2)
    MERGE (os_svc)-[:CONTAINS]->(dc)
    MERGE (ps)-[:CONTAINS]->(m3)
    MERGE (fc)-[:CONTAINS]->(m4)
    MERGE (ic)-[:CONTAINS]->(m5)
    MERGE (ne)-[:CONTAINS]->(m6)
    MERGE (uc)-[:CONTAINS]->(m7)

    // CALLS relationships
    MERGE (m1)-[:CALLS]->(m2)
    MERGE (m2)-[:CALLS]->(m3)
    MERGE (m2)-[:CALLS]->(m5)
    MERGE (m3)-[:CALLS]->(m4)
    MERGE (m2)-[:CALLS]->(m6)
    MERGE (m2)-[:CALLS]->(m7)
    """
    with graph.session() as session:
        session.run(cypher)


def seed_runtime_layer(graph: GraphManager):
    """Create sample runtime traces and spans."""
    print("  Seeding runtime layer...")

    cypher = """
    // Services
    MERGE (s1:Service {name: 'order-service'}) SET s1.layer = 'runtime'
    MERGE (s2:Service {name: 'payment-service'}) SET s2.layer = 'runtime'
    MERGE (s3:Service {name: 'user-service'}) SET s3.layer = 'runtime'
    MERGE (s4:Service {name: 'inventory-service'}) SET s4.layer = 'runtime'
    MERGE (s5:Service {name: 'notification-service'}) SET s5.layer = 'runtime'

    // Sample trace 1 — successful order
    MERGE (t1:Trace {trace_id: 'trace-001'}) SET t1.layer = 'runtime'
    MERGE (sp1:Span {span_id: 'span-001'})
    SET sp1.trace_id = 'trace-001', sp1.operation_name = 'POST /orders', sp1.service_name = 'order-service',
        sp1.duration_ms = 450.5, sp1.status = 'OK', sp1.code_function = 'createOrder', sp1.http_method = 'POST', sp1.http_route = '/orders', sp1.layer = 'runtime'

    MERGE (sp2:Span {span_id: 'span-002'})
    SET sp2.trace_id = 'trace-001', sp2.operation_name = 'OrderService.processOrder', sp2.service_name = 'order-service',
        sp2.duration_ms = 420.0, sp2.status = 'OK', sp2.code_function = 'processOrder', sp2.layer = 'runtime'

    MERGE (sp3:Span {span_id: 'span-003'})
    SET sp3.trace_id = 'trace-001', sp3.operation_name = 'POST /payments', sp3.service_name = 'payment-service',
        sp3.duration_ms = 180.2, sp3.status = 'OK', sp3.code_function = 'processPayment', sp3.http_method = 'POST', sp3.layer = 'runtime'

    MERGE (sp4:Span {span_id: 'span-004'})
    SET sp4.trace_id = 'trace-001', sp4.operation_name = 'FraudChecker.checkFraud', sp4.service_name = 'payment-service',
        sp4.duration_ms = 95.1, sp4.status = 'OK', sp4.code_function = 'checkFraud', sp4.layer = 'runtime'

    MERGE (sp5:Span {span_id: 'span-005'})
    SET sp5.trace_id = 'trace-001', sp5.operation_name = 'POST /inventory/reserve', sp5.service_name = 'inventory-service',
        sp5.duration_ms = 65.3, sp5.status = 'OK', sp5.code_function = 'reserveStock', sp5.layer = 'runtime'

    // Sample trace 2 — failed payment
    MERGE (t2:Trace {trace_id: 'trace-002'}) SET t2.layer = 'runtime'
    MERGE (sp6:Span {span_id: 'span-006'})
    SET sp6.trace_id = 'trace-002', sp6.operation_name = 'POST /orders', sp6.service_name = 'order-service',
        sp6.duration_ms = 1200.0, sp6.status = 'ERROR', sp6.code_function = 'createOrder', sp6.layer = 'runtime'

    MERGE (sp7:Span {span_id: 'span-007'})
    SET sp7.trace_id = 'trace-002', sp7.operation_name = 'POST /payments', sp7.service_name = 'payment-service',
        sp7.duration_ms = 850.0, sp7.status = 'ERROR', sp7.code_function = 'processPayment', sp7.layer = 'runtime'

    // Relationships
    MERGE (s1)-[:EMITS]->(t1)
    MERGE (s1)-[:EMITS]->(t2)
    MERGE (t1)-[:HAS_SPAN]->(sp1)
    MERGE (t1)-[:HAS_SPAN]->(sp2)
    MERGE (t1)-[:HAS_SPAN]->(sp3)
    MERGE (t1)-[:HAS_SPAN]->(sp4)
    MERGE (t1)-[:HAS_SPAN]->(sp5)
    MERGE (t2)-[:HAS_SPAN]->(sp6)
    MERGE (t2)-[:HAS_SPAN]->(sp7)

    MERGE (sp2)-[:CHILD_OF]->(sp1)
    MERGE (sp3)-[:CHILD_OF]->(sp2)
    MERGE (sp4)-[:CHILD_OF]->(sp3)
    MERGE (sp5)-[:CHILD_OF]->(sp2)
    MERGE (sp7)-[:CHILD_OF]->(sp6)

    MERGE (s1)-[:PRODUCES_SPAN]->(sp1)
    MERGE (s1)-[:PRODUCES_SPAN]->(sp2)
    MERGE (s2)-[:PRODUCES_SPAN]->(sp3)
    MERGE (s2)-[:PRODUCES_SPAN]->(sp4)
    MERGE (s4)-[:PRODUCES_SPAN]->(sp5)
    MERGE (s1)-[:PRODUCES_SPAN]->(sp6)
    MERGE (s2)-[:PRODUCES_SPAN]->(sp7)

    // Cross-layer: Span → CodeEntity
    WITH 1 AS dummy
    MATCH (sp:Span), (code:CodeEntity)
    WHERE sp.code_function IS NOT NULL AND sp.code_function <> '' AND code.name = sp.code_function
    MERGE (sp)-[:INVOKED_AT_RUNTIME]->(code)
    """
    with graph.session() as session:
        session.run(cypher)


def seed_infra_layer(graph: GraphManager):
    """Create sample infrastructure nodes."""
    print("  Seeding infrastructure layer...")

    cypher = """
    // Terraform resources
    MERGE (vpc:TerraformResource {address: 'aws_vpc.main'})
    SET vpc.type = 'aws_vpc', vpc.name = 'main', vpc.provider = 'aws', vpc.layer = 'infrastructure'

    MERGE (rds:TerraformResource {address: 'aws_rds_instance.orders_db'})
    SET rds.type = 'aws_rds_instance', rds.name = 'orders_db', rds.provider = 'aws', rds.layer = 'infrastructure'

    MERGE (redis:TerraformResource {address: 'aws_elasticache_cluster.sessions'})
    SET redis.type = 'aws_elasticache_cluster', redis.name = 'sessions', redis.provider = 'aws', redis.layer = 'infrastructure'

    MERGE (eks:TerraformResource {address: 'aws_eks_cluster.main'})
    SET eks.type = 'aws_eks_cluster', eks.name = 'main', eks.provider = 'aws', eks.layer = 'infrastructure'

    MERGE (rds)-[:DEPENDS_ON]->(vpc)
    MERGE (redis)-[:DEPENDS_ON]->(vpc)
    MERGE (eks)-[:DEPENDS_ON]->(vpc)

    // Kubernetes deployments
    MERGE (d1:K8sDeployment {qualified_name: 'prod/Deployment/order-service'})
    SET d1.name = 'order-service', d1.namespace = 'prod', d1.kind = 'Deployment', d1.replicas = 3, d1.layer = 'infrastructure'

    MERGE (d2:K8sDeployment {qualified_name: 'prod/Deployment/payment-service'})
    SET d2.name = 'payment-service', d2.namespace = 'prod', d2.kind = 'Deployment', d2.replicas = 2, d2.layer = 'infrastructure'

    MERGE (d3:K8sDeployment {qualified_name: 'prod/Deployment/user-service'})
    SET d3.name = 'user-service', d3.namespace = 'prod', d3.kind = 'Deployment', d3.replicas = 2, d3.layer = 'infrastructure'

    MERGE (d4:K8sDeployment {qualified_name: 'prod/Deployment/inventory-service'})
    SET d4.name = 'inventory-service', d4.namespace = 'prod', d4.kind = 'Deployment', d4.replicas = 2, d4.layer = 'infrastructure'

    // K8s Services
    MERGE (ks1:K8sService {qualified_name: 'prod/Service/order-service'})
    SET ks1.name = 'order-service', ks1.namespace = 'prod', ks1.service_type = 'ClusterIP', ks1.layer = 'infrastructure'

    MERGE (ks2:K8sService {qualified_name: 'prod/Service/payment-service'})
    SET ks2.name = 'payment-service', ks2.namespace = 'prod', ks2.service_type = 'ClusterIP', ks2.layer = 'infrastructure'

    MERGE (ks1)-[:ROUTES_TO]->(d1)
    MERGE (ks2)-[:ROUTES_TO]->(d2)

    // Cross-layer: K8sDeployment → Service
    WITH 1 AS dummy
    MATCH (dep:K8sDeployment), (svc:Service)
    WHERE dep.name = svc.name
    MERGE (dep)-[:DEPLOYS]->(svc)
    """
    with graph.session() as session:
        session.run(cypher)


def seed_knowledge_layer(graph: GraphManager):
    """Create sample knowledge entities."""
    print("  Seeding knowledge layer...")

    cypher = """
    // Documents
    MERGE (d1:Document {path: 'docs/adr/001-use-kafka-for-events.md'})
    SET d1.title = 'ADR-001: Use Kafka for Event-Driven Communication', d1.doc_type = 'adr', d1.layer = 'knowledge'

    MERGE (d2:Document {path: 'docs/patterns/circuit-breaker.md'})
    SET d2.title = 'Circuit Breaker Pattern', d2.doc_type = 'pattern', d2.layer = 'knowledge'

    MERGE (d3:Document {path: 'docs/postmortems/2024-03-payment-outage.md'})
    SET d3.title = 'Payment Service Outage — March 2024', d3.doc_type = 'postmortem', d3.layer = 'knowledge'

    MERGE (d4:Document {path: 'docs/standards/api-versioning.md'})
    SET d4.title = 'API Versioning Standard', d4.doc_type = 'standard', d4.layer = 'knowledge'

    // Knowledge entities
    MERGE (p1:Pattern {name: 'Circuit Breaker'})
    SET p1.description = 'Wrap external service calls in a circuit breaker to prevent cascade failures. Use Resilience4j for Java services.', p1.tags = ['reliability', 'resilience'], p1.layer = 'knowledge'

    MERGE (p2:Pattern {name: 'Saga Orchestration'})
    SET p2.description = 'Use orchestration-based saga pattern for distributed transactions across order, payment, and inventory services.', p2.tags = ['distributed-transactions', 'consistency'], p2.layer = 'knowledge'

    MERGE (dec1:Decision {id: 'adr-001'})
    SET dec1.name = 'Use Kafka for Event-Driven Communication', dec1.description = 'All inter-service async communication must use Kafka topics. Direct HTTP calls only for synchronous request-response.', dec1.tags = ['adr', 'accepted'], dec1.layer = 'knowledge'

    MERGE (les1:Lesson {id: 'lesson-001'})
    SET les1.name = 'Payment timeout must have fallback', les1.description = 'During March 2024 outage, payment service timeouts cascaded to order service. Always implement circuit breaker with fallback for payment calls.', les1.tags = ['postmortem', 'lesson'], les1.layer = 'knowledge'

    MERGE (std1:Standard {name: 'API Versioning'})
    SET std1.description = 'All REST APIs must use URI versioning (e.g. /v1/orders). Breaking changes require a new version.', std1.tags = ['standard', 'api'], std1.layer = 'knowledge'

    // Document → Entity
    MERGE (d1)-[:DOCUMENTS]->(dec1)
    MERGE (d2)-[:DOCUMENTS]->(p1)
    MERGE (d3)-[:DOCUMENTS]->(les1)
    MERGE (d4)-[:DOCUMENTS]->(std1)

    // Cross-layer: Knowledge → Code
    WITH 1 AS dummy
    MATCH (p1:Pattern {name: 'Circuit Breaker'}), (ps:CodeEntity {name: 'PaymentService'})
    MERGE (p1)-[:APPLIES_TO]->(ps)

    WITH 1 AS dummy
    MATCH (p2:Pattern {name: 'Saga Orchestration'}), (os:CodeEntity {name: 'OrderService'})
    MERGE (p2)-[:APPLIES_TO]->(os)

    WITH 1 AS dummy
    MATCH (les1:Lesson {id: 'lesson-001'}), (ps:CodeEntity {name: 'PaymentService'})
    MERGE (les1)-[:APPLIES_TO]->(ps)

    WITH 1 AS dummy
    MATCH (std1:Standard {name: 'API Versioning'}), (oc:CodeEntity {name: 'OrderController'})
    MERGE (std1)-[:APPLIES_TO]->(oc)

    WITH 1 AS dummy
    MATCH (std1:Standard {name: 'API Versioning'}), (pc:CodeEntity {name: 'PaymentController'})
    MERGE (std1)-[:APPLIES_TO]->(pc)
    """
    with graph.session() as session:
        session.run(cypher)


def main():
    config = load_config("config/settings.yaml")
    graph = GraphManager(config.neo4j)

    if not graph.verify_connectivity():
        print("ERROR: Cannot connect to Neo4j")
        sys.exit(1)

    print("Setting up schema...")
    graph.setup_schema()

    print("\nSeeding demo data across all layers...")
    seed_static_layer(graph)
    seed_runtime_layer(graph)
    seed_infra_layer(graph)
    seed_knowledge_layer(graph)

    stats = graph.get_stats()
    total_nodes = sum(stats["nodes"].values()) if stats["nodes"] else 0
    total_rels = sum(stats["relationships"].values()) if stats["relationships"] else 0
    print(f"\n✓ Demo seeded: {total_nodes} nodes, {total_rels} relationships")
    print("  Open Neo4j Browser: http://localhost:7474")
    print("  Try: MATCH (n) RETURN n LIMIT 50")

    graph.close()


if __name__ == "__main__":
    main()
