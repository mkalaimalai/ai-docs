#!/usr/bin/env bash
# Wait for Neo4j to be ready before running ingestion
set -e

NEO4J_URI="${NEO4J_URI:-bolt://localhost:7687}"
MAX_RETRIES=30
RETRY_INTERVAL=3

echo "Waiting for Neo4j at ${NEO4J_URI}..."

for i in $(seq 1 $MAX_RETRIES); do
    if python3 -c "
from neo4j import GraphDatabase
try:
    d = GraphDatabase.driver('${NEO4J_URI}', auth=('${NEO4J_USER:-neo4j}', '${NEO4J_PASSWORD:-changeme}'))
    d.verify_connectivity()
    d.close()
    print('Connected!')
    exit(0)
except:
    exit(1)
" 2>/dev/null; then
        echo "Neo4j is ready!"
        exit 0
    fi
    echo "  Attempt $i/$MAX_RETRIES — retrying in ${RETRY_INTERVAL}s..."
    sleep $RETRY_INTERVAL
done

echo "ERROR: Neo4j did not become ready in time"
exit 1
