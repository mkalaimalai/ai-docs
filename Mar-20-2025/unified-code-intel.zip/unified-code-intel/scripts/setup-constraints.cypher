// ── Unified Code Intelligence Platform ──
// Neo4j Schema: Constraints + Indexes
// Run: cat setup-constraints.cypher | cypher-shell -u neo4j -p changeme

// ━━━ Static Layer ━━━
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Module) REQUIRE n.qualified_name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Class) REQUIRE n.qualified_name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Method) REQUIRE n.qualified_name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Function) REQUIRE n.qualified_name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:File) REQUIRE n.path IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Interface) REQUIRE n.qualified_name IS UNIQUE;

CREATE INDEX IF NOT EXISTS FOR (n:Class) ON (n.name);
CREATE INDEX IF NOT EXISTS FOR (n:Method) ON (n.name);
CREATE INDEX IF NOT EXISTS FOR (n:Function) ON (n.name);
CREATE INDEX IF NOT EXISTS FOR (n:CodeEntity) ON (n.name);
CREATE INDEX IF NOT EXISTS FOR (n:CodeEntity) ON (n.language);

// ━━━ Runtime Layer ━━━
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Service) REQUIRE n.name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Trace) REQUIRE n.trace_id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Span) REQUIRE n.span_id IS UNIQUE;

CREATE INDEX IF NOT EXISTS FOR (n:Span) ON (n.operation_name);
CREATE INDEX IF NOT EXISTS FOR (n:Span) ON (n.service_name);
CREATE INDEX IF NOT EXISTS FOR (n:Span) ON (n.status);
CREATE INDEX IF NOT EXISTS FOR (n:LogEntry) ON (n.level);
CREATE INDEX IF NOT EXISTS FOR (n:LogEntry) ON (n.service_name);

// ━━━ Infrastructure Layer ━━━
CREATE CONSTRAINT IF NOT EXISTS FOR (n:TerraformResource) REQUIRE n.address IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:K8sDeployment) REQUIRE n.qualified_name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:K8sService) REQUIRE n.qualified_name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:K8sPod) REQUIRE n.qualified_name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:K8sIngress) REQUIRE n.qualified_name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:K8sConfigMap) REQUIRE n.qualified_name IS UNIQUE;

CREATE INDEX IF NOT EXISTS FOR (n:TerraformResource) ON (n.type);
CREATE INDEX IF NOT EXISTS FOR (n:TerraformResource) ON (n.provider);

// ━━━ Knowledge Layer ━━━
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Pattern) REQUIRE n.name IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Decision) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Document) REQUIRE n.path IS UNIQUE;

CREATE INDEX IF NOT EXISTS FOR (n:Pattern) ON (n.name);
CREATE INDEX IF NOT EXISTS FOR (n:Standard) ON (n.name);
CREATE INDEX IF NOT EXISTS FOR (n:Lesson) ON (n.name);

// ━━━ Full-text search ━━━
CREATE FULLTEXT INDEX search_code IF NOT EXISTS
  FOR (n:Class|Method|Function|Interface)
  ON EACH [n.name, n.qualified_name];

CREATE FULLTEXT INDEX search_knowledge IF NOT EXISTS
  FOR (n:Pattern|Standard|Decision|Lesson)
  ON EACH [n.name, n.description];

// ━━━ Layer index ━━━
CREATE INDEX IF NOT EXISTS FOR (n:CodeEntity) ON (n.layer);
