"""Query Engine: Cypher-based and hybrid search across the unified graph."""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.table import Table

from src.graph import GraphManager
from src.utils.embeddings import embed_text

console = Console()


# ── Pre-built query templates ────────────────────────────────────────────────

QUERY_TEMPLATES = {
    "service_dependencies": {
        "description": "Find all services that a given service depends on (runtime)",
        "cypher": """
            MATCH (s:Service {name: $service_name})-[:PRODUCES_SPAN]->(span:Span)-[:CHILD_OF*]->(parent:Span)<-[:PRODUCES_SPAN]-(dep:Service)
            WHERE s <> dep
            RETURN DISTINCT dep.name AS dependency, count(span) AS call_count
            ORDER BY call_count DESC
        """,
        "params": ["service_name"],
    },

    "hot_paths": {
        "description": "Find the hottest code paths by runtime call frequency",
        "cypher": """
            MATCH (sp:Span)-[:INVOKED_AT_RUNTIME]->(code:CodeEntity)
            RETURN code.qualified_name AS code_path, code.name AS name,
                   count(sp) AS invocation_count,
                   avg(sp.duration_ms) AS avg_latency_ms,
                   max(sp.duration_ms) AS max_latency_ms
            ORDER BY invocation_count DESC
            LIMIT $limit
        """,
        "params": ["limit"],
    },

    "dead_code": {
        "description": "Find code entities with no runtime invocations (potential dead code)",
        "cypher": """
            MATCH (code:CodeEntity)
            WHERE code.language IS NOT NULL
              AND NOT EXISTS { (sp:Span)-[:INVOKED_AT_RUNTIME]->(code) }
              AND code:Method OR code:Function
            RETURN code.qualified_name AS code_path, code.language AS language,
                   code.file_path AS file
            ORDER BY code.file_path
            LIMIT $limit
        """,
        "params": ["limit"],
    },

    "blast_radius": {
        "description": "Determine blast radius: what depends on a given code entity",
        "cypher": """
            MATCH (target:CodeEntity {name: $entity_name})
            OPTIONAL MATCH (caller)-[:CALLS]->(target)
            OPTIONAL MATCH (sp:Span)-[:INVOKED_AT_RUNTIME]->(target)
            OPTIONAL MATCH (sp)<-[:PRODUCES_SPAN]-(svc:Service)
            OPTIONAL MATCH (dep:K8sDeployment)-[:DEPLOYS]->(svc)
            RETURN target.qualified_name AS target,
                   collect(DISTINCT caller.qualified_name) AS static_callers,
                   collect(DISTINCT svc.name) AS runtime_services,
                   collect(DISTINCT dep.qualified_name) AS k8s_deployments
        """,
        "params": ["entity_name"],
    },

    "pattern_violations": {
        "description": "Find code entities that should follow a pattern but might not",
        "cypher": """
            MATCH (p:Pattern)-[:APPLIES_TO]->(code:CodeEntity)
            RETURN p.name AS pattern, p.description AS description,
                   collect(code.qualified_name) AS affected_code
            ORDER BY p.name
        """,
        "params": [],
    },

    "infra_to_code": {
        "description": "Trace from infrastructure resource to the code that runs on it",
        "cypher": """
            MATCH (dep:K8sDeployment)-[:DEPLOYS]->(svc:Service)-[:PRODUCES_SPAN]->(sp:Span)-[:INVOKED_AT_RUNTIME]->(code:CodeEntity)
            WHERE dep.name CONTAINS $search_term OR svc.name CONTAINS $search_term
            RETURN DISTINCT dep.qualified_name AS deployment,
                   svc.name AS service,
                   code.qualified_name AS code_path,
                   count(sp) AS runtime_calls
            ORDER BY runtime_calls DESC
            LIMIT 20
        """,
        "params": ["search_term"],
    },

    "error_paths": {
        "description": "Find code paths with the highest error rates",
        "cypher": """
            MATCH (sp:Span)-[:INVOKED_AT_RUNTIME]->(code:CodeEntity)
            WITH code,
                 count(sp) AS total_calls,
                 count(CASE WHEN sp.status = 'ERROR' THEN 1 END) AS error_calls
            WHERE total_calls > 5
            RETURN code.qualified_name AS code_path,
                   total_calls,
                   error_calls,
                   round(toFloat(error_calls) / total_calls * 100, 2) AS error_rate_pct
            ORDER BY error_rate_pct DESC
            LIMIT $limit
        """,
        "params": ["limit"],
    },

    "cross_layer_overview": {
        "description": "Get a full cross-layer view for a service",
        "cypher": """
            MATCH (svc:Service {name: $service_name})
            OPTIONAL MATCH (svc)-[:PRODUCES_SPAN]->(sp:Span)-[:INVOKED_AT_RUNTIME]->(code:CodeEntity)
            OPTIONAL MATCH (dep:K8sDeployment)-[:DEPLOYS]->(svc)
            OPTIONAL MATCH (tf:TerraformResource)
            WHERE tf.name CONTAINS $service_name
            OPTIONAL MATCH (pattern)-[:APPLIES_TO]->(code)
            WHERE pattern.layer = 'knowledge'
            RETURN svc.name AS service,
                   collect(DISTINCT code.qualified_name)[..10] AS code_entities,
                   collect(DISTINCT dep.qualified_name) AS k8s_deployments,
                   collect(DISTINCT tf.address) AS terraform_resources,
                   collect(DISTINCT pattern.name) AS applied_patterns,
                   count(DISTINCT sp) AS total_spans
        """,
        "params": ["service_name"],
    },
}


class QueryEngine:
    """Executes queries against the unified code graph."""

    def __init__(self, graph: GraphManager, embedding_model: str = "all-MiniLM-L6-v2"):
        self.graph = graph
        self.embedding_model = embedding_model

    def run_template(self, template_name: str, params: dict[str, Any] | None = None) -> list[dict]:
        """Run a pre-built query template."""
        template = QUERY_TEMPLATES.get(template_name)
        if not template:
            available = ", ".join(QUERY_TEMPLATES.keys())
            console.print(f"[red]Unknown template: {template_name}[/red]\nAvailable: {available}")
            return []

        query_params = params or {}
        # Set defaults
        if "limit" in template["params"] and "limit" not in query_params:
            query_params["limit"] = 25

        results = self.graph.run_query(template["cypher"], query_params)
        return results

    def natural_language_query(self, question: str) -> list[dict]:
        """Convert a natural language question to Cypher and execute.
        
        Uses pattern matching to route to the right template.
        For production, this would use an LLM for text2cypher.
        """
        q = question.lower()

        if "depend" in q or "calls" in q or "uses" in q:
            # Extract service/entity name from question
            name = self._extract_entity_name(question)
            if name:
                return self.run_template("service_dependencies", {"service_name": name})

        if "hot" in q or "frequent" in q or "most called" in q:
            return self.run_template("hot_paths", {"limit": 20})

        if "dead" in q or "unused" in q or "never called" in q:
            return self.run_template("dead_code", {"limit": 30})

        if "blast" in q or "impact" in q or "affect" in q:
            name = self._extract_entity_name(question)
            if name:
                return self.run_template("blast_radius", {"entity_name": name})

        if "error" in q or "fail" in q or "broken" in q:
            return self.run_template("error_paths", {"limit": 20})

        if "pattern" in q or "violation" in q or "standard" in q:
            return self.run_template("pattern_violations")

        if "infra" in q or "deploy" in q or "kubernetes" in q or "terraform" in q:
            name = self._extract_entity_name(question)
            if name:
                return self.run_template("infra_to_code", {"search_term": name})

        # Fallback: full-text search
        return self._fulltext_search(question)

    def _extract_entity_name(self, question: str) -> str | None:
        """Extract a likely entity name from a question."""
        import re
        # Look for PascalCase or quoted terms
        matches = re.findall(r'"([^"]+)"|\'([^\']+)\'|`([^`]+)`', question)
        if matches:
            return next(m for group in matches for m in group if m)

        # Look for PascalCase words
        pascal = re.findall(r"\b([A-Z][a-z]+(?:[A-Z][a-z]+)+)\b", question)
        if pascal:
            return pascal[0]

        return None

    def _fulltext_search(self, query: str) -> list[dict]:
        """Fall back to full-text search across code entities."""
        cypher = """
        CALL db.index.fulltext.queryNodes('search_code', $query)
        YIELD node, score
        RETURN node.qualified_name AS entity, labels(node) AS types,
               node.language AS language, score
        ORDER BY score DESC
        LIMIT 20
        """
        try:
            return self.graph.run_query(cypher, {"query": query})
        except Exception:
            return []

    def display_results(self, results: list[dict], title: str = "Query Results"):
        """Pretty-print query results using Rich tables."""
        if not results:
            console.print("[yellow]No results found.[/yellow]")
            return

        table = Table(title=title, show_lines=True)
        # Auto-detect columns from first result
        for key in results[0].keys():
            table.add_column(key, overflow="fold")

        for row in results:
            table.add_row(*[str(v) for v in row.values()])

        console.print(table)
