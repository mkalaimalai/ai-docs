"""Main CLI entry point for the Unified Code Intelligence Platform."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console

from src.graph import GraphManager
from src.utils.config import load_config

console = Console()


@click.group()
@click.option("--config", "-c", default="config/settings.yaml", help="Path to config file")
@click.pass_context
def cli(ctx, config):
    """Unified Code Intelligence Platform — multi-layer code graph for LLM agents."""
    ctx.ensure_object(dict)
    ctx.obj["config"] = load_config(config)


@cli.command()
@click.option("--repo", "-r", type=click.Path(exists=True), help="Repository path to analyze")
@click.option("--traces", "-t", type=click.Path(), help="Directory with OTel trace JSON files")
@click.option("--logs", "-l", type=click.Path(), help="Directory with structured log files (.jsonl)")
@click.option("--terraform", type=click.Path(), help="Directory with Terraform .tf files")
@click.option("--kubernetes", "-k", type=click.Path(), help="Directory with K8s YAML manifests")
@click.option("--docs", "-d", type=click.Path(), help="Directory with knowledge docs (ADRs, patterns, etc.)")
@click.pass_context
def ingest(ctx, repo, traces, logs, terraform, kubernetes, docs):
    """Run the ingestion pipeline across all layers."""
    from src.ingestion.pipeline import IngestionPipeline

    config = ctx.obj["config"]
    graph = GraphManager(config.neo4j)

    if not graph.verify_connectivity():
        raise click.Abort()

    pipeline = IngestionPipeline(config, graph)
    pipeline.run(
        repo_path=repo,
        traces_dir=traces,
        logs_dir=logs,
        terraform_dir=terraform,
        kubernetes_dir=kubernetes,
        docs_dir=docs,
    )
    graph.close()


@cli.command()
@click.argument("question")
@click.pass_context
def query(ctx, question):
    """Query the code graph using natural language."""
    from src.query.engine import QueryEngine

    config = ctx.obj["config"]
    graph = GraphManager(config.neo4j)

    if not graph.verify_connectivity():
        raise click.Abort()

    engine = QueryEngine(graph, config.embedding.model)
    results = engine.natural_language_query(question)
    engine.display_results(results, title=question)
    graph.close()


@cli.command("run-query")
@click.argument("template_name")
@click.option("--param", "-p", multiple=True, help="Parameters as key=value pairs")
@click.pass_context
def run_query(ctx, template_name, param):
    """Run a pre-built query template."""
    from src.query.engine import QueryEngine, QUERY_TEMPLATES

    config = ctx.obj["config"]
    graph = GraphManager(config.neo4j)

    if not graph.verify_connectivity():
        raise click.Abort()

    # Parse params
    params = {}
    for p in param:
        key, _, value = p.partition("=")
        try:
            params[key] = int(value)
        except ValueError:
            params[key] = value

    engine = QueryEngine(graph, config.embedding.model)

    if template_name == "list":
        console.print("[bold]Available query templates:[/bold]")
        for name, tmpl in QUERY_TEMPLATES.items():
            console.print(f"  [cyan]{name}[/cyan] — {tmpl['description']}")
            if tmpl["params"]:
                console.print(f"    Params: {', '.join(tmpl['params'])}")
        graph.close()
        return

    results = engine.run_template(template_name, params)
    engine.display_results(results, title=template_name)
    graph.close()


@cli.command("mcp-server")
@click.option("--host", default="0.0.0.0", help="Host to bind")
@click.option("--port", default=8100, type=int, help="Port to bind")
@click.option("--stdio", is_flag=True, help="Run in stdio mode (for Claude Code)")
@click.pass_context
def mcp_server(ctx, host, port, stdio):
    """Start the MCP server for LLM agent integration."""
    from src.agents.mcp_server import run_http_server, run_stdio_server

    config = ctx.obj["config"]

    if stdio:
        run_stdio_server(config)
    else:
        run_http_server(config, host, port)


@cli.command()
@click.pass_context
def stats(ctx):
    """Show graph statistics."""
    config = ctx.obj["config"]
    graph = GraphManager(config.neo4j)

    if not graph.verify_connectivity():
        raise click.Abort()

    s = graph.get_stats()
    console.print("[bold]Graph Statistics[/bold]")
    if s["nodes"]:
        console.print("\n[cyan]Nodes:[/cyan]")
        for label, count in s["nodes"].items():
            console.print(f"  {label}: {count:,}")
    if s["relationships"]:
        console.print("\n[cyan]Relationships:[/cyan]")
        for rtype, count in s["relationships"].items():
            console.print(f"  {rtype}: {count:,}")

    total_nodes = sum(s["nodes"].values()) if s["nodes"] else 0
    total_rels = sum(s["relationships"].values()) if s["relationships"] else 0
    console.print(f"\n[bold]Total: {total_nodes:,} nodes, {total_rels:,} relationships[/bold]")
    graph.close()


@cli.command("setup-schema")
@click.pass_context
def setup_schema(ctx):
    """Initialize Neo4j constraints and indexes."""
    config = ctx.obj["config"]
    graph = GraphManager(config.neo4j)

    if not graph.verify_connectivity():
        raise click.Abort()

    graph.setup_schema()
    graph.close()


if __name__ == "__main__":
    cli()
