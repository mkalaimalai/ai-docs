"""Infrastructure Layer: Parse Terraform HCL and Kubernetes YAML into Neo4j.

Creates: TerraformResource, K8sDeployment, K8sService, K8sPod, K8sConfigMap nodes
Relationships: DEPENDS_ON, DEPLOYED_ON, EXPOSES, ROUTES_TO, USES_CONFIG
Cross-layer: DEPLOYS (K8sDeployment → Service from Runtime Layer)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml
from rich.console import Console
from rich.progress import track

from src.graph import GraphManager

console = Console()


class TerraformParser:
    """Parses Terraform HCL files using python-hcl2."""

    def parse_directory(self, tf_dir: Path) -> list[dict[str, Any]]:
        """Parse all .tf files in a directory and extract resources."""
        resources = []
        tf_files = list(tf_dir.rglob("*.tf"))

        if not tf_files:
            return resources

        for tf_file in tf_files:
            try:
                import hcl2
                with open(tf_file) as f:
                    parsed = hcl2.load(f)
            except Exception as e:
                console.print(f"[yellow]⚠[/yellow] Failed to parse {tf_file}: {e}")
                continue

            # Extract resource blocks
            for resource_block in parsed.get("resource", []):
                for resource_type, instances in resource_block.items():
                    for instance in instances:
                        for name, config in instance.items():
                            address = f"{resource_type}.{name}"
                            resources.append({
                                "address": address,
                                "type": resource_type,
                                "name": name,
                                "file": str(tf_file.relative_to(tf_dir)),
                                "provider": resource_type.split("_")[0],
                                "config": {
                                    k: str(v) if not isinstance(v, (str, int, float, bool)) else v
                                    for k, v in (config if isinstance(config, dict) else {}).items()
                                    if k not in ("depends_on", "lifecycle", "provisioner")
                                },
                                "depends_on": config.get("depends_on", []) if isinstance(config, dict) else [],
                            })

            # Extract data blocks
            for data_block in parsed.get("data", []):
                for data_type, instances in data_block.items():
                    for instance in instances:
                        for name, config in instance.items():
                            address = f"data.{data_type}.{name}"
                            resources.append({
                                "address": address,
                                "type": f"data.{data_type}",
                                "name": name,
                                "file": str(tf_file.relative_to(tf_dir)),
                                "provider": data_type.split("_")[0],
                                "config": {},
                                "depends_on": [],
                            })

        return resources

    def parse_tfstate(self, state_file: Path) -> list[dict[str, Any]]:
        """Parse a terraform.tfstate file for actual deployed resources."""
        resources = []
        try:
            state = json.loads(state_file.read_text())
        except Exception:
            return resources

        for res in state.get("resources", []):
            res_type = res.get("type", "")
            res_name = res.get("name", "")
            for instance in res.get("instances", []):
                attrs = instance.get("attributes", {})
                resources.append({
                    "address": f"{res_type}.{res_name}",
                    "type": res_type,
                    "name": res_name,
                    "provider": res.get("provider", ""),
                    "state": "deployed",
                    "arn": attrs.get("arn", ""),
                    "id": attrs.get("id", ""),
                    "tags": attrs.get("tags", {}),
                })

        return resources


class KubernetesParser:
    """Parses Kubernetes YAML manifests."""

    def parse_directory(self, k8s_dir: Path) -> list[dict[str, Any]]:
        """Parse all YAML files and extract K8s resource definitions."""
        k8s_resources = []
        yaml_files = list(k8s_dir.rglob("*.yaml")) + list(k8s_dir.rglob("*.yml"))

        for yf in yaml_files:
            try:
                with open(yf) as f:
                    docs = list(yaml.safe_load_all(f))
            except Exception:
                continue

            for doc in docs:
                if not isinstance(doc, dict) or "kind" not in doc:
                    continue

                metadata = doc.get("metadata", {})
                kind = doc["kind"]
                name = metadata.get("name", "unknown")
                namespace = metadata.get("namespace", "default")
                labels = metadata.get("labels", {})

                resource = {
                    "kind": kind,
                    "name": name,
                    "namespace": namespace,
                    "qualified_name": f"{namespace}/{kind}/{name}",
                    "file": str(yf),
                    "labels": labels,
                    "annotations": metadata.get("annotations", {}),
                }

                # Extract kind-specific info
                spec = doc.get("spec", {})
                if kind == "Deployment":
                    containers = []
                    template_spec = spec.get("template", {}).get("spec", {})
                    for c in template_spec.get("containers", []):
                        containers.append({
                            "name": c.get("name"),
                            "image": c.get("image"),
                            "ports": [p.get("containerPort") for p in c.get("ports", [])],
                        })
                    resource["replicas"] = spec.get("replicas", 1)
                    resource["containers"] = containers
                    resource["selector"] = spec.get("selector", {}).get("matchLabels", {})

                elif kind == "Service":
                    resource["service_type"] = spec.get("type", "ClusterIP")
                    resource["ports"] = [
                        {"port": p.get("port"), "target_port": p.get("targetPort"), "protocol": p.get("protocol", "TCP")}
                        for p in spec.get("ports", [])
                    ]
                    resource["selector"] = spec.get("selector", {})

                elif kind == "Ingress":
                    rules = []
                    for rule in spec.get("rules", []):
                        host = rule.get("host", "*")
                        for path in rule.get("http", {}).get("paths", []):
                            backend = path.get("backend", {})
                            svc = backend.get("service", {})
                            rules.append({
                                "host": host,
                                "path": path.get("path", "/"),
                                "service": svc.get("name"),
                                "port": svc.get("port", {}).get("number"),
                            })
                    resource["rules"] = rules

                elif kind == "ConfigMap":
                    resource["data_keys"] = list(doc.get("data", {}).keys())

                k8s_resources.append(resource)

        return k8s_resources


class InfraLayerIngester:
    """Writes infrastructure layer data into Neo4j."""

    def __init__(self, graph: GraphManager):
        self.graph = graph
        self.tf_parser = TerraformParser()
        self.k8s_parser = KubernetesParser()

    def ingest_terraform(self, tf_dir: str | Path):
        """Ingest Terraform definitions."""
        tf_path = Path(tf_dir)
        if not tf_path.exists():
            console.print(f"[yellow]⚠[/yellow] Terraform directory not found: {tf_path}")
            return

        resources = self.tf_parser.parse_directory(tf_path)

        # Also try to parse tfstate
        state_files = list(tf_path.rglob("terraform.tfstate")) + list(tf_path.rglob("*.tfstate"))
        for sf in state_files:
            resources.extend(self.tf_parser.parse_tfstate(sf))

        console.print(f"  Found {len(resources)} Terraform resources")

        if resources:
            self._write_tf_resources(resources)

        console.print("[green]✓[/green] Terraform ingestion complete")

    def ingest_kubernetes(self, k8s_dir: str | Path):
        """Ingest Kubernetes manifests."""
        k8s_path = Path(k8s_dir)
        if not k8s_path.exists():
            console.print(f"[yellow]⚠[/yellow] Kubernetes directory not found: {k8s_path}")
            return

        resources = self.k8s_parser.parse_directory(k8s_path)
        console.print(f"  Found {len(resources)} Kubernetes resources")

        if resources:
            self._write_k8s_resources(resources)

        console.print("[green]✓[/green] Kubernetes ingestion complete")

    def _write_tf_resources(self, resources: list[dict]):
        """Write Terraform resources to Neo4j."""
        cypher = """
        UNWIND $resources AS r
        MERGE (n:TerraformResource {address: r.address})
        SET n.type = r.type,
            n.name = r.name,
            n.provider = r.provider,
            n.file = r.file,
            n.layer = 'infrastructure'
        """
        with self.graph.session() as session:
            session.run(cypher, {"resources": resources})

        # Write DEPENDS_ON relationships
        dep_cypher = """
        UNWIND $deps AS d
        MATCH (a:TerraformResource {address: d.from_addr})
        MATCH (b:TerraformResource {address: d.to_addr})
        MERGE (a)-[:DEPENDS_ON]->(b)
        """
        deps = []
        for r in resources:
            for dep in r.get("depends_on", []):
                deps.append({"from_addr": r["address"], "to_addr": dep})
        if deps:
            with self.graph.session() as session:
                try:
                    session.run(dep_cypher, {"deps": deps})
                except Exception:
                    pass

    def _write_k8s_resources(self, resources: list[dict]):
        """Write Kubernetes resources to Neo4j and create relationships."""
        for r in resources:
            kind = r["kind"]
            label = f"K8s{kind}"
            qn = r["qualified_name"]

            # Write node
            cypher = f"""
            MERGE (n:{label} {{qualified_name: $qn}})
            SET n.name = $name,
                n.namespace = $namespace,
                n.kind = $kind,
                n.layer = 'infrastructure'
            """
            with self.graph.session() as session:
                session.run(cypher, {
                    "qn": qn, "name": r["name"],
                    "namespace": r["namespace"], "kind": kind,
                })

            # Link Deployments to Services via selector matching
            if kind == "Deployment":
                self._link_deployment_to_runtime(r)

        # Link K8s Services to Deployments via label selectors
        self._link_k8s_services_to_deployments(resources)

    def _link_deployment_to_runtime(self, deployment: dict):
        """Cross-layer: link K8s Deployment → Runtime Service by name matching."""
        dep_name = deployment["name"]
        cypher = """
        MATCH (dep:K8sDeployment {name: $name})
        MATCH (svc:Service {name: $name})
        MERGE (dep)-[:DEPLOYS]->(svc)
        """
        with self.graph.session() as session:
            try:
                session.run(cypher, {"name": dep_name})
            except Exception:
                pass

    def _link_k8s_services_to_deployments(self, resources: list[dict]):
        """Link K8s Services to matching Deployments via selectors."""
        services = [r for r in resources if r["kind"] == "Service"]
        deployments = [r for r in resources if r["kind"] == "Deployment"]

        for svc in services:
            selector = svc.get("selector", {})
            if not selector:
                continue
            for dep in deployments:
                dep_labels = dep.get("labels", {})
                if all(dep_labels.get(k) == v for k, v in selector.items()):
                    cypher = """
                    MATCH (s:K8sService {qualified_name: $svc_qn})
                    MATCH (d:K8sDeployment {qualified_name: $dep_qn})
                    MERGE (s)-[:ROUTES_TO]->(d)
                    """
                    with self.graph.session() as session:
                        try:
                            session.run(cypher, {"svc_qn": svc["qualified_name"], "dep_qn": dep["qualified_name"]})
                        except Exception:
                            pass
