"""Runtime Layer: Ingest OpenTelemetry traces and structured logs into Neo4j.

Creates: Service, Trace, Span, LogEntry nodes
Relationships: HAS_SPAN, CHILD_OF, TRIGGERED_BY, LOGGED_BY
Cross-layer: INVOKED_AT_RUNTIME (Span → Method/Function from Static Layer)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.progress import track

from src.graph import GraphManager

console = Console()


@dataclass
class SpanData:
    """Parsed OpenTelemetry span."""
    trace_id: str
    span_id: str
    parent_span_id: str | None
    operation_name: str
    service_name: str
    start_time: str
    duration_ms: float
    status: str
    attributes: dict[str, Any] = field(default_factory=dict)
    events: list[dict] = field(default_factory=list)


@dataclass
class LogEntryData:
    """Parsed structured log entry."""
    timestamp: str
    level: str
    message: str
    service_name: str
    trace_id: str | None = None
    span_id: str | None = None
    attributes: dict[str, Any] = field(default_factory=dict)


class TraceParser:
    """Parses OpenTelemetry JSON trace exports."""

    def parse_otlp_json(self, file_path: Path) -> list[SpanData]:
        """Parse an OTLP JSON export file into SpanData objects."""
        spans = []
        try:
            data = json.loads(file_path.read_text())
        except Exception as e:
            console.print(f"[yellow]⚠[/yellow] Failed to read {file_path}: {e}")
            return spans

        # Handle OTLP JSON format (resourceSpans → scopeSpans → spans)
        resource_spans = data.get("resourceSpans", data.get("data", []))
        if isinstance(resource_spans, dict):
            resource_spans = [resource_spans]

        for rs in resource_spans:
            # Extract service name from resource attributes
            service_name = "unknown"
            resource = rs.get("resource", {})
            for attr in resource.get("attributes", []):
                if attr.get("key") == "service.name":
                    service_name = attr.get("value", {}).get("stringValue", "unknown")

            for scope_span in rs.get("scopeSpans", rs.get("instrumentationLibrarySpans", [])):
                for span in scope_span.get("spans", []):
                    attrs = {}
                    for attr in span.get("attributes", []):
                        key = attr.get("key", "")
                        val = attr.get("value", {})
                        attrs[key] = (
                            val.get("stringValue")
                            or val.get("intValue")
                            or val.get("doubleValue")
                            or val.get("boolValue")
                            or str(val)
                        )

                    start_ns = int(span.get("startTimeUnixNano", 0))
                    end_ns = int(span.get("endTimeUnixNano", 0))
                    duration_ms = (end_ns - start_ns) / 1_000_000

                    status = span.get("status", {}).get("code", "UNSET")
                    if isinstance(status, int):
                        status = {0: "UNSET", 1: "OK", 2: "ERROR"}.get(status, str(status))

                    spans.append(SpanData(
                        trace_id=span.get("traceId", ""),
                        span_id=span.get("spanId", ""),
                        parent_span_id=span.get("parentSpanId") or None,
                        operation_name=span.get("name", "unknown"),
                        service_name=service_name,
                        start_time=datetime.fromtimestamp(start_ns / 1e9).isoformat() if start_ns else "",
                        duration_ms=round(duration_ms, 2),
                        status=status,
                        attributes=attrs,
                        events=span.get("events", []),
                    ))

        return spans

    def parse_jaeger_json(self, file_path: Path) -> list[SpanData]:
        """Parse a Jaeger JSON export."""
        spans = []
        try:
            data = json.loads(file_path.read_text())
        except Exception:
            return spans

        for trace in data.get("data", []):
            processes = trace.get("processes", {})
            for span in trace.get("spans", []):
                process_id = span.get("processID", "")
                service_name = processes.get(process_id, {}).get("serviceName", "unknown")

                attrs = {}
                for tag in span.get("tags", []):
                    attrs[tag["key"]] = tag.get("value")

                duration_us = span.get("duration", 0)
                start_us = span.get("startTime", 0)

                refs = span.get("references", [])
                parent_id = None
                for ref in refs:
                    if ref.get("refType") == "CHILD_OF":
                        parent_id = ref.get("spanID")

                spans.append(SpanData(
                    trace_id=span.get("traceID", ""),
                    span_id=span.get("spanID", ""),
                    parent_span_id=parent_id,
                    operation_name=span.get("operationName", "unknown"),
                    service_name=service_name,
                    start_time=datetime.fromtimestamp(start_us / 1e6).isoformat() if start_us else "",
                    duration_ms=round(duration_us / 1000, 2),
                    status=attrs.get("otel.status_code", "UNSET"),
                    attributes=attrs,
                ))

        return spans


class LogParser:
    """Parses structured JSON log files."""

    def parse_jsonl(self, file_path: Path) -> list[LogEntryData]:
        """Parse a JSON Lines log file."""
        entries = []
        try:
            with open(file_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    entries.append(LogEntryData(
                        timestamp=record.get("timestamp", record.get("@timestamp", "")),
                        level=record.get("level", record.get("severity", "INFO")).upper(),
                        message=record.get("message", record.get("msg", "")),
                        service_name=record.get("service", record.get("service.name", "unknown")),
                        trace_id=record.get("trace_id", record.get("traceId")),
                        span_id=record.get("span_id", record.get("spanId")),
                        attributes={
                            k: v for k, v in record.items()
                            if k not in ("timestamp", "@timestamp", "level", "severity", "message", "msg",
                                         "service", "service.name", "trace_id", "traceId", "span_id", "spanId")
                        },
                    ))
        except Exception as e:
            console.print(f"[yellow]⚠[/yellow] Failed to parse logs {file_path}: {e}")

        return entries


class RuntimeLayerIngester:
    """Writes runtime traces and logs into Neo4j."""

    def __init__(self, graph: GraphManager):
        self.graph = graph
        self.trace_parser = TraceParser()
        self.log_parser = LogParser()

    def ingest_traces(self, traces_dir: str | Path):
        """Ingest all trace files from a directory."""
        traces_path = Path(traces_dir)
        if not traces_path.exists():
            console.print(f"[yellow]⚠[/yellow] Traces directory not found: {traces_path}")
            return

        json_files = list(traces_path.glob("*.json"))
        if not json_files:
            console.print(f"[yellow]⚠[/yellow] No JSON trace files found in {traces_path}")
            return

        all_spans: list[SpanData] = []
        for f in track(json_files, description="  Parsing traces"):
            # Try OTLP format first, fall back to Jaeger
            spans = self.trace_parser.parse_otlp_json(f)
            if not spans:
                spans = self.trace_parser.parse_jaeger_json(f)
            all_spans.extend(spans)

        console.print(f"  Found {len(all_spans)} spans across {len(json_files)} files")

        if all_spans:
            self._write_spans(all_spans)
            self._link_spans_to_code(all_spans)

        console.print("[green]✓[/green] Runtime trace ingestion complete")

    def ingest_logs(self, logs_dir: str | Path):
        """Ingest structured log files from a directory."""
        logs_path = Path(logs_dir)
        if not logs_path.exists():
            console.print(f"[yellow]⚠[/yellow] Logs directory not found: {logs_path}")
            return

        log_files = list(logs_path.glob("*.jsonl")) + list(logs_path.glob("*.ndjson"))
        if not log_files:
            return

        all_entries: list[LogEntryData] = []
        for f in track(log_files, description="  Parsing logs"):
            all_entries.extend(self.log_parser.parse_jsonl(f))

        console.print(f"  Found {len(all_entries)} log entries")

        if all_entries:
            self._write_log_entries(all_entries)

        console.print("[green]✓[/green] Runtime log ingestion complete")

    def _write_spans(self, spans: list[SpanData]):
        """Batch write spans and their relationships to Neo4j."""
        # Write Service + Trace + Span nodes
        cypher = """
        UNWIND $spans AS s
        MERGE (svc:Service {name: s.service_name})
        SET svc.layer = 'runtime'
        MERGE (t:Trace {trace_id: s.trace_id})
        SET t.layer = 'runtime'
        MERGE (sp:Span {span_id: s.span_id})
        SET sp.trace_id = s.trace_id,
            sp.operation_name = s.operation_name,
            sp.service_name = s.service_name,
            sp.start_time = s.start_time,
            sp.duration_ms = s.duration_ms,
            sp.status = s.status,
            sp.code_function = s.code_function,
            sp.code_namespace = s.code_namespace,
            sp.http_method = s.http_method,
            sp.http_route = s.http_route,
            sp.layer = 'runtime'
        MERGE (svc)-[:EMITS]->(t)
        MERGE (t)-[:HAS_SPAN]->(sp)
        MERGE (svc)-[:PRODUCES_SPAN]->(sp)
        """
        rows = [
            {
                "trace_id": s.trace_id,
                "span_id": s.span_id,
                "operation_name": s.operation_name,
                "service_name": s.service_name,
                "start_time": s.start_time,
                "duration_ms": s.duration_ms,
                "status": s.status,
                "code_function": s.attributes.get("code.function", ""),
                "code_namespace": s.attributes.get("code.namespace", ""),
                "http_method": s.attributes.get("http.method", ""),
                "http_route": s.attributes.get("http.route", s.attributes.get("http.target", "")),
            }
            for s in spans
        ]

        with self.graph.session() as session:
            session.run(cypher, {"spans": rows})

        # Write parent-child span relationships
        parent_cypher = """
        UNWIND $pairs AS p
        MATCH (parent:Span {span_id: p.parent_id})
        MATCH (child:Span {span_id: p.child_id})
        MERGE (child)-[:CHILD_OF]->(parent)
        """
        pairs = [
            {"parent_id": s.parent_span_id, "child_id": s.span_id}
            for s in spans if s.parent_span_id
        ]
        if pairs:
            with self.graph.session() as session:
                session.run(parent_cypher, {"pairs": pairs})

    def _link_spans_to_code(self, spans: list[SpanData]):
        """Create cross-layer edges from Span → static code entities."""
        cypher = """
        UNWIND $links AS l
        MATCH (sp:Span {span_id: l.span_id})
        MATCH (code:CodeEntity)
        WHERE code.name = l.function_name
          AND (code.qualified_name CONTAINS l.namespace OR l.namespace = '')
        MERGE (sp)-[:INVOKED_AT_RUNTIME]->(code)
        """
        links = [
            {
                "span_id": s.span_id,
                "function_name": s.attributes.get("code.function", ""),
                "namespace": s.attributes.get("code.namespace", ""),
            }
            for s in spans
            if s.attributes.get("code.function")
        ]
        if links:
            with self.graph.session() as session:
                try:
                    session.run(cypher, {"links": links})
                except Exception:
                    pass  # Best-effort cross-layer linking

    def _write_log_entries(self, entries: list[LogEntryData]):
        """Write log entries and link to traces/services."""
        cypher = """
        UNWIND $entries AS e
        MERGE (svc:Service {name: e.service_name})
        CREATE (log:LogEntry {
            timestamp: e.timestamp,
            level: e.level,
            message: e.message,
            service_name: e.service_name,
            layer: 'runtime'
        })
        MERGE (svc)-[:LOGGED]->(log)
        WITH log, e
        WHERE e.trace_id IS NOT NULL AND e.trace_id <> ''
        MATCH (t:Trace {trace_id: e.trace_id})
        MERGE (log)-[:CORRELATED_WITH]->(t)
        """
        rows = [
            {
                "timestamp": e.timestamp,
                "level": e.level,
                "message": e.message[:500],  # Truncate long messages
                "service_name": e.service_name,
                "trace_id": e.trace_id or "",
            }
            for e in entries
        ]

        # Batch in chunks
        chunk_size = 1000
        for i in range(0, len(rows), chunk_size):
            chunk = rows[i:i + chunk_size]
            with self.graph.session() as session:
                session.run(cypher, {"entries": chunk})
