"""Static Layer: Parse source code using Tree-sitter and write structural graph to Neo4j.

Extracts: Classes, Methods, Functions, Modules, Imports
Relationships: CONTAINS, CALLS, IMPORTS, IMPLEMENTS, EXTENDS
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.progress import track

from src.graph import GraphManager

console = Console()

# Language file extension mapping
LANG_EXTENSIONS: dict[str, list[str]] = {
    "python": [".py"],
    "javascript": [".js", ".jsx"],
    "typescript": [".ts", ".tsx"],
    "java": [".java"],
}


@dataclass
class CodeEntity:
    """Represents a parsed code entity (class, method, function, etc.)."""
    kind: str                    # Class, Method, Function, Module
    name: str
    qualified_name: str
    file_path: str
    start_line: int
    end_line: int
    language: str
    properties: dict[str, Any] = field(default_factory=dict)


@dataclass
class CodeRelationship:
    """Represents a relationship between code entities."""
    from_qn: str
    from_kind: str
    to_qn: str
    to_kind: str
    rel_type: str                # CALLS, IMPORTS, CONTAINS, EXTENDS, IMPLEMENTS
    properties: dict[str, Any] = field(default_factory=dict)


class StaticLayerParser:
    """Parses source code files using Tree-sitter and extracts structural information."""

    def __init__(self, languages: list[str] | None = None):
        self.languages = languages or ["python", "javascript", "java", "typescript"]
        self._parsers: dict[str, Any] = {}

    def _get_parser(self, language: str):
        """Lazy-load Tree-sitter parser for a language."""
        if language not in self._parsers:
            try:
                import tree_sitter
                if language == "python":
                    import tree_sitter_python as tsp
                    lang = tree_sitter.Language(tsp.language())
                elif language == "javascript":
                    import tree_sitter_javascript as tsjs
                    lang = tree_sitter.Language(tsjs.language())
                elif language == "java":
                    import tree_sitter_java as tsj
                    lang = tree_sitter.Language(tsj.language())
                elif language == "typescript":
                    import tree_sitter_typescript as tsts
                    lang = tree_sitter.Language(tsts.language_typescript())
                else:
                    return None

                parser = tree_sitter.Parser(lang)
                self._parsers[language] = parser
            except ImportError:
                console.print(f"[yellow]⚠[/yellow] tree-sitter-{language} not installed, skipping")
                return None
        return self._parsers.get(language)

    def discover_files(self, repo_path: str | Path, language: str) -> list[Path]:
        """Find all source files for a given language in a repository."""
        repo = Path(repo_path)
        extensions = LANG_EXTENSIONS.get(language, [])
        files = []
        for ext in extensions:
            files.extend(repo.rglob(f"*{ext}"))
        # Filter out common non-source directories
        skip_dirs = {"node_modules", ".git", "__pycache__", "venv", ".venv", "dist", "build", "target"}
        return [f for f in files if not any(d in f.parts for d in skip_dirs)]

    def parse_file(self, file_path: Path, language: str, repo_root: Path) -> tuple[list[CodeEntity], list[CodeRelationship]]:
        """Parse a single source file and extract entities + relationships."""
        parser = self._get_parser(language)
        if not parser:
            return [], []

        try:
            source = file_path.read_bytes()
            tree = parser.parse(source)
        except Exception as e:
            console.print(f"[yellow]⚠[/yellow] Failed to parse {file_path}: {e}")
            return [], []

        rel_path = str(file_path.relative_to(repo_root))
        entities: list[CodeEntity] = []
        relationships: list[CodeRelationship] = []

        # Create File node
        file_entity = CodeEntity(
            kind="File",
            name=file_path.name,
            qualified_name=rel_path,
            file_path=rel_path,
            start_line=1,
            end_line=source.count(b"\n") + 1,
            language=language,
        )
        entities.append(file_entity)

        # Walk AST and extract entities
        self._walk_tree(tree.root_node, source, rel_path, language, entities, relationships)

        return entities, relationships

    def _walk_tree(
        self,
        node,
        source: bytes,
        file_path: str,
        language: str,
        entities: list[CodeEntity],
        relationships: list[CodeRelationship],
        parent_qn: str | None = None,
    ):
        """Recursively walk the AST and extract code entities."""
        kind = self._classify_node(node, language)

        if kind:
            name = self._extract_name(node, source, language)
            if name:
                qn = f"{file_path}::{name}" if not parent_qn else f"{parent_qn}.{name}"

                entity = CodeEntity(
                    kind=kind,
                    name=name,
                    qualified_name=qn,
                    file_path=file_path,
                    start_line=node.start_point[0] + 1,
                    end_line=node.end_point[0] + 1,
                    language=language,
                    properties={
                        "byte_size": node.end_byte - node.start_byte,
                        "node_type": node.type,
                    },
                )
                entities.append(entity)

                # CONTAINS relationship from file or parent
                container = parent_qn or file_path
                container_kind = "File" if not parent_qn else self._parent_kind(parent_qn, entities)
                relationships.append(CodeRelationship(
                    from_qn=container,
                    from_kind=container_kind or "File",
                    to_qn=qn,
                    to_kind=kind,
                    rel_type="CONTAINS",
                ))

                # Extract call relationships
                self._extract_calls(node, source, qn, kind, language, relationships)

                # Recurse with updated parent
                for child in node.children:
                    self._walk_tree(child, source, file_path, language, entities, relationships, qn)
                return

        for child in node.children:
            self._walk_tree(child, source, file_path, language, entities, relationships, parent_qn)

    def _classify_node(self, node, language: str) -> str | None:
        """Classify a tree-sitter node into a code entity kind."""
        type_map = {
            "class_definition": "Class",
            "class_declaration": "Class",
            "function_definition": "Function",
            "function_declaration": "Function",
            "method_definition": "Method",
            "method_declaration": "Method",
            "interface_declaration": "Interface",
            "arrow_function": None,  # skip anonymous
            "import_statement": None,  # handled separately
        }
        return type_map.get(node.type)

    def _extract_name(self, node, source: bytes, language: str) -> str | None:
        """Extract the name identifier from a node."""
        for child in node.children:
            if child.type in ("identifier", "property_identifier", "type_identifier"):
                return source[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
        return None

    def _extract_calls(self, node, source: bytes, caller_qn: str, caller_kind: str, language: str, relationships: list[CodeRelationship]):
        """Extract method/function call relationships from a node's subtree."""
        if node.type == "call_expression" or node.type == "method_invocation":
            callee_name = None
            for child in node.children:
                if child.type in ("identifier", "member_expression", "field_access"):
                    callee_name = source[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
                    break
            if callee_name:
                relationships.append(CodeRelationship(
                    from_qn=caller_qn,
                    from_kind=caller_kind,
                    to_qn=callee_name,  # Unresolved — linked during post-processing
                    to_kind="Function",
                    rel_type="CALLS",
                    properties={"resolved": False},
                ))

        for child in node.children:
            self._extract_calls(child, source, caller_qn, caller_kind, language, relationships)

    def _parent_kind(self, parent_qn: str, entities: list[CodeEntity]) -> str | None:
        for e in entities:
            if e.qualified_name == parent_qn:
                return e.kind
        return None


class StaticLayerIngester:
    """Writes static layer parse results into Neo4j."""

    def __init__(self, graph: GraphManager):
        self.graph = graph
        self.parser = StaticLayerParser()

    def ingest_repository(self, repo_path: str | Path, languages: list[str] | None = None):
        """Parse and ingest an entire repository."""
        repo = Path(repo_path)
        if not repo.exists():
            console.print(f"[red]✗[/red] Repository path not found: {repo}")
            return

        langs = languages or self.parser.languages
        all_entities: list[CodeEntity] = []
        all_rels: list[CodeRelationship] = []

        for lang in langs:
            files = self.parser.discover_files(repo, lang)
            if not files:
                continue

            console.print(f"  [cyan]●[/cyan] Parsing {len(files)} {lang} files...")
            for f in track(files, description=f"  {lang}", transient=True):
                entities, rels = self.parser.parse_file(f, lang, repo)
                all_entities.extend(entities)
                all_rels.extend(rels)

        console.print(f"  Found {len(all_entities)} entities, {len(all_rels)} relationships")

        # Write to Neo4j in batch
        self._write_entities(all_entities)
        self._write_relationships(all_rels)

        console.print("[green]✓[/green] Static layer ingestion complete")

    def _write_entities(self, entities: list[CodeEntity]):
        """Batch write entities to Neo4j."""
        cypher = """
        UNWIND $entities AS e
        CALL {
            WITH e
            MERGE (n:CodeEntity {qualified_name: e.qualified_name})
            SET n.name = e.name,
                n.file_path = e.file_path,
                n.start_line = e.start_line,
                n.end_line = e.end_line,
                n.language = e.language,
                n.byte_size = e.byte_size,
                n.layer = 'static'
            WITH n, e
            CALL apoc.create.addLabels(n, [e.kind]) YIELD node
            RETURN node
        } IN TRANSACTIONS OF 500 ROWS
        """
        rows = [
            {
                "qualified_name": e.qualified_name,
                "name": e.name,
                "kind": e.kind,
                "file_path": e.file_path,
                "start_line": e.start_line,
                "end_line": e.end_line,
                "language": e.language,
                "byte_size": e.properties.get("byte_size", 0),
            }
            for e in entities
        ]
        with self.graph.session() as session:
            session.run(cypher, {"entities": rows})

    def _write_relationships(self, rels: list[CodeRelationship]):
        """Batch write relationships to Neo4j."""
        cypher = """
        UNWIND $rels AS r
        CALL {
            WITH r
            MATCH (a {qualified_name: r.from_qn})
            MATCH (b {qualified_name: r.to_qn})
            CALL apoc.merge.relationship(a, r.rel_type, {}, r.props, b) YIELD rel
            RETURN rel
        } IN TRANSACTIONS OF 500 ROWS
        """
        rows = [
            {
                "from_qn": r.from_qn,
                "to_qn": r.to_qn,
                "rel_type": r.rel_type,
                "props": r.properties,
            }
            for r in rels
        ]
        with self.graph.session() as session:
            try:
                session.run(cypher, {"rels": rows})
            except Exception as e:
                console.print(f"[yellow]⚠[/yellow] Some relationships skipped (unresolved refs): {e}")
