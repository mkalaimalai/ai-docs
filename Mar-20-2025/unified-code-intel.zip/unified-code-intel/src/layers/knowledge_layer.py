"""Knowledge Layer: Ingest organizational knowledge (ADRs, patterns, docs) into Neo4j.

Creates: Document, Pattern, Standard, Decision, Lesson nodes
Relationships: DOCUMENTS, RECOMMENDS, SUPERSEDES, RELATES_TO
Cross-layer: APPLIES_TO (Pattern → Class/Service from other layers)
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.progress import track

from src.graph import GraphManager
from src.utils.embeddings import embed_text, embed_batch

console = Console()


@dataclass
class DocumentData:
    """Parsed document."""
    path: str
    title: str
    content: str
    doc_type: str  # adr, postmortem, runbook, pattern, standard, guide
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class KnowledgeEntity:
    """Extracted knowledge entity from a document."""
    name: str
    kind: str  # Pattern, Standard, Decision, Lesson, BestPractice
    description: str
    source_doc: str
    tags: list[str] = field(default_factory=list)
    related_code: list[str] = field(default_factory=list)  # service/class names


class DocumentParser:
    """Parses markdown and text documents for knowledge extraction."""

    ADR_PATTERN = re.compile(r"^#\s*(?:ADR[-\s]*)?(\d+)[\s:.-]*(.+)", re.MULTILINE)
    STATUS_PATTERN = re.compile(r"\*?\*?Status\*?\*?:\s*(.+)", re.IGNORECASE)
    PATTERN_MARKERS = ["## Pattern", "## Best Practice", "## Convention", "## Standard", "## Rule"]

    def parse_directory(self, docs_dir: Path) -> list[DocumentData]:
        """Parse all markdown/text files in a directory."""
        documents = []
        md_files = list(docs_dir.rglob("*.md")) + list(docs_dir.rglob("*.txt"))

        for f in md_files:
            try:
                content = f.read_text(errors="replace")
            except Exception:
                continue

            title = self._extract_title(content, f.stem)
            doc_type = self._classify_document(f, content)

            documents.append(DocumentData(
                path=str(f),
                title=title,
                content=content,
                doc_type=doc_type,
                metadata=self._extract_metadata(content),
            ))

        return documents

    def _extract_title(self, content: str, fallback: str) -> str:
        """Extract title from first heading or use filename."""
        match = re.match(r"^#\s+(.+)", content)
        if match:
            return match.group(1).strip()
        return fallback.replace("-", " ").replace("_", " ").title()

    def _classify_document(self, path: Path, content: str) -> str:
        """Classify document type based on path and content."""
        path_lower = str(path).lower()
        content_lower = content.lower()

        if "adr" in path_lower or "decision" in path_lower:
            return "adr"
        elif "postmortem" in path_lower or "incident" in path_lower or "rca" in path_lower:
            return "postmortem"
        elif "runbook" in path_lower or "playbook" in path_lower:
            return "runbook"
        elif "pattern" in path_lower or "best-practice" in path_lower:
            return "pattern"
        elif "standard" in path_lower or "convention" in path_lower:
            return "standard"
        elif any(marker.lower() in content_lower for marker in self.PATTERN_MARKERS):
            return "pattern"
        elif "## status" in content_lower and ("accepted" in content_lower or "proposed" in content_lower):
            return "adr"
        return "guide"

    def _extract_metadata(self, content: str) -> dict[str, Any]:
        """Extract metadata fields from document content."""
        metadata = {}

        # YAML frontmatter
        if content.startswith("---"):
            end = content.find("---", 3)
            if end > 0:
                try:
                    import yaml
                    metadata = yaml.safe_load(content[3:end]) or {}
                except Exception:
                    pass

        # Status field
        status_match = self.STATUS_PATTERN.search(content)
        if status_match:
            metadata["status"] = status_match.group(1).strip()

        return metadata

    def extract_entities(self, doc: DocumentData) -> list[KnowledgeEntity]:
        """Extract knowledge entities from a document using rule-based extraction."""
        entities = []

        if doc.doc_type == "adr":
            entities.extend(self._extract_adr_entities(doc))
        elif doc.doc_type == "postmortem":
            entities.extend(self._extract_postmortem_entities(doc))
        elif doc.doc_type in ("pattern", "standard"):
            entities.extend(self._extract_pattern_entities(doc))

        # Always create a document-level entity
        if not entities:
            entities.append(KnowledgeEntity(
                name=doc.title,
                kind="Document",
                description=doc.content[:500],
                source_doc=doc.path,
                tags=[doc.doc_type],
            ))

        # Extract referenced service/class names
        code_refs = self._find_code_references(doc.content)
        for entity in entities:
            entity.related_code.extend(code_refs)

        return entities

    def _extract_adr_entities(self, doc: DocumentData) -> list[KnowledgeEntity]:
        """Extract decisions from an ADR document."""
        entities = []
        sections = re.split(r"\n##\s+", doc.content)

        decision_text = ""
        for section in sections:
            if section.lower().startswith("decision"):
                decision_text = section.split("\n", 1)[-1].strip()

        entities.append(KnowledgeEntity(
            name=doc.title,
            kind="Decision",
            description=decision_text[:500] if decision_text else doc.content[:500],
            source_doc=doc.path,
            tags=["adr", doc.metadata.get("status", "proposed")],
        ))

        return entities

    def _extract_postmortem_entities(self, doc: DocumentData) -> list[KnowledgeEntity]:
        """Extract lessons from a post-mortem document."""
        entities = []
        sections = re.split(r"\n##\s+", doc.content)

        for section in sections:
            header = section.split("\n", 1)[0].lower()
            body = section.split("\n", 1)[-1].strip() if "\n" in section else ""

            if any(k in header for k in ["lesson", "action", "takeaway", "improvement"]):
                items = re.findall(r"[-*]\s+(.+)", body)
                for item in items:
                    entities.append(KnowledgeEntity(
                        name=item[:100],
                        kind="Lesson",
                        description=item,
                        source_doc=doc.path,
                        tags=["postmortem", "lesson"],
                    ))

        if not entities:
            entities.append(KnowledgeEntity(
                name=doc.title,
                kind="Lesson",
                description=doc.content[:500],
                source_doc=doc.path,
                tags=["postmortem"],
            ))

        return entities

    def _extract_pattern_entities(self, doc: DocumentData) -> list[KnowledgeEntity]:
        """Extract patterns/standards from a pattern document."""
        entities = []
        sections = re.split(r"\n##\s+", doc.content)

        for section in sections:
            header = section.split("\n", 1)[0].strip()
            body = section.split("\n", 1)[-1].strip() if "\n" in section else ""

            if any(marker.replace("## ", "").lower() in header.lower() for marker in self.PATTERN_MARKERS):
                entities.append(KnowledgeEntity(
                    name=header,
                    kind="Pattern",
                    description=body[:500],
                    source_doc=doc.path,
                    tags=["pattern"],
                ))

        if not entities:
            entities.append(KnowledgeEntity(
                name=doc.title,
                kind="Standard" if doc.doc_type == "standard" else "Pattern",
                description=doc.content[:500],
                source_doc=doc.path,
                tags=[doc.doc_type],
            ))

        return entities

    def _find_code_references(self, content: str) -> list[str]:
        """Find likely code entity references in document text."""
        # Match PascalCase class names and service-like names
        class_refs = re.findall(r"\b([A-Z][a-z]+(?:[A-Z][a-z]+)+)\b", content)
        # Match backtick-quoted identifiers
        code_refs = re.findall(r"`([a-zA-Z_][\w.]+)`", content)
        # Deduplicate
        return list(set(class_refs + code_refs))[:20]


class KnowledgeLayerIngester:
    """Writes knowledge layer data into Neo4j with embeddings."""

    def __init__(self, graph: GraphManager, embedding_model: str = "all-MiniLM-L6-v2"):
        self.graph = graph
        self.parser = DocumentParser()
        self.embedding_model = embedding_model

    def ingest_documents(self, docs_dir: str | Path):
        """Ingest all documents from a directory."""
        docs_path = Path(docs_dir)
        if not docs_path.exists():
            console.print(f"[yellow]⚠[/yellow] Documents directory not found: {docs_path}")
            return

        documents = self.parser.parse_directory(docs_path)
        console.print(f"  Found {len(documents)} documents")

        all_entities: list[KnowledgeEntity] = []
        for doc in track(documents, description="  Extracting knowledge"):
            entities = self.parser.extract_entities(doc)
            all_entities.extend(entities)

        console.print(f"  Extracted {len(all_entities)} knowledge entities")

        if all_entities:
            self._write_documents(documents)
            self._write_entities(all_entities)
            self._link_to_code(all_entities)

        console.print("[green]✓[/green] Knowledge layer ingestion complete")

    def _write_documents(self, documents: list[DocumentData]):
        """Write document nodes."""
        cypher = """
        UNWIND $docs AS d
        MERGE (n:Document {path: d.path})
        SET n.title = d.title,
            n.doc_type = d.doc_type,
            n.layer = 'knowledge'
        """
        rows = [{"path": d.path, "title": d.title, "doc_type": d.doc_type} for d in documents]
        with self.graph.session() as session:
            session.run(cypher, {"docs": rows})

    def _write_entities(self, entities: list[KnowledgeEntity]):
        """Write knowledge entities with embeddings."""
        # Generate embeddings for all entities
        descriptions = [e.description for e in entities]
        try:
            embeddings = embed_batch(descriptions, self.embedding_model)
        except Exception:
            embeddings = [[] for _ in entities]
            console.print("[yellow]⚠[/yellow] Embedding generation failed, writing without vectors")

        for entity, embedding in zip(entities, embeddings):
            entity_id = hashlib.md5(f"{entity.name}:{entity.source_doc}".encode()).hexdigest()

            cypher = f"""
            MERGE (n:{entity.kind} {{id: $id}})
            SET n.name = $name,
                n.description = $description,
                n.tags = $tags,
                n.layer = 'knowledge'
            WITH n
            MATCH (d:Document {{path: $source_doc}})
            MERGE (d)-[:DOCUMENTS]->(n)
            """
            params = {
                "id": entity_id,
                "name": entity.name,
                "description": entity.description,
                "tags": entity.tags,
                "source_doc": entity.source_doc,
            }

            with self.graph.session() as session:
                try:
                    session.run(cypher, params)
                except Exception as e:
                    console.print(f"[yellow]⚠[/yellow] Failed to write entity {entity.name}: {e}")

    def _link_to_code(self, entities: list[KnowledgeEntity]):
        """Cross-layer: link knowledge entities to code entities by name matching."""
        cypher = """
        UNWIND $links AS l
        MATCH (k {name: l.knowledge_name})
        WHERE k.layer = 'knowledge'
        MATCH (c:CodeEntity)
        WHERE c.name = l.code_ref OR c.qualified_name CONTAINS l.code_ref
        MERGE (k)-[:APPLIES_TO]->(c)
        """
        links = []
        for entity in entities:
            for ref in entity.related_code:
                links.append({"knowledge_name": entity.name, "code_ref": ref})

        if links:
            with self.graph.session() as session:
                try:
                    session.run(cypher, {"links": links[:200]})  # Limit to avoid explosion
                except Exception:
                    pass
