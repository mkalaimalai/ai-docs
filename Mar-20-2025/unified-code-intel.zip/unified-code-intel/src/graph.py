"""Neo4j connection manager and graph operations."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator

from neo4j import GraphDatabase, Driver, Session
from rich.console import Console

from src.utils.config import Neo4jConfig

console = Console()


class GraphManager:
    """Manages Neo4j connections and provides graph operation helpers."""

    def __init__(self, config: Neo4jConfig):
        self.config = config
        self._driver: Driver | None = None

    @property
    def driver(self) -> Driver:
        if self._driver is None:
            self._driver = GraphDatabase.driver(
                self.config.uri,
                auth=(self.config.user, self.config.password),
            )
        return self._driver

    def close(self):
        if self._driver:
            self._driver.close()
            self._driver = None

    @contextmanager
    def session(self) -> Generator[Session, None, None]:
        """Context manager for Neo4j sessions."""
        session = self.driver.session(database=self.config.database)
        try:
            yield session
        finally:
            session.close()

    def verify_connectivity(self) -> bool:
        """Test that Neo4j is reachable."""
        try:
            self.driver.verify_connectivity()
            console.print("[green]✓[/green] Neo4j connected")
            return True
        except Exception as e:
            console.print(f"[red]✗[/red] Neo4j connection failed: {e}")
            return False

    def setup_schema(self):
        """Create constraints and indexes for the unified graph schema."""
        constraints = [
            # Static Layer
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Module) REQUIRE n.qualified_name IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Class) REQUIRE n.qualified_name IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Method) REQUIRE n.qualified_name IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Function) REQUIRE n.qualified_name IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:File) REQUIRE n.path IS UNIQUE",
            # Runtime Layer
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Service) REQUIRE n.name IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Trace) REQUIRE n.trace_id IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Span) REQUIRE n.span_id IS UNIQUE",
            # Infrastructure Layer
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:TerraformResource) REQUIRE n.address IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:K8sDeployment) REQUIRE n.qualified_name IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:K8sService) REQUIRE n.qualified_name IS UNIQUE",
            # Knowledge Layer
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Pattern) REQUIRE n.name IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Decision) REQUIRE n.id IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Document) REQUIRE n.path IS UNIQUE",
        ]

        indexes = [
            "CREATE INDEX IF NOT EXISTS FOR (n:Class) ON (n.name)",
            "CREATE INDEX IF NOT EXISTS FOR (n:Method) ON (n.name)",
            "CREATE INDEX IF NOT EXISTS FOR (n:Service) ON (n.name)",
            "CREATE INDEX IF NOT EXISTS FOR (n:Span) ON (n.operation_name)",
            "CREATE INDEX IF NOT EXISTS FOR (n:TerraformResource) ON (n.type)",
            "CREATE FULLTEXT INDEX search_code IF NOT EXISTS FOR (n:Class|Method|Function) ON EACH [n.name, n.qualified_name]",
        ]

        with self.session() as session:
            for stmt in constraints + indexes:
                try:
                    session.run(stmt)
                except Exception as e:
                    console.print(f"[yellow]⚠[/yellow] Schema: {e}")

        console.print("[green]✓[/green] Graph schema initialized")

    def run_query(self, cypher: str, params: dict[str, Any] | None = None) -> list[dict]:
        """Execute a Cypher query and return results as dicts."""
        with self.session() as session:
            result = session.run(cypher, params or {})
            return [record.data() for record in result]

    def merge_node(self, label: str, key_prop: str, key_val: Any, properties: dict[str, Any] | None = None):
        """MERGE a node with given label and key, setting additional properties."""
        props = properties or {}
        set_clause = ", ".join(f"n.{k} = ${k}" for k in props.keys())
        cypher = f"MERGE (n:{label} {{{key_prop}: $key_val}})"
        if set_clause:
            cypher += f" SET {set_clause}"

        params = {"key_val": key_val, **props}
        with self.session() as session:
            session.run(cypher, params)

    def merge_relationship(
        self,
        from_label: str, from_key: str, from_val: Any,
        to_label: str, to_key: str, to_val: Any,
        rel_type: str, properties: dict[str, Any] | None = None,
    ):
        """MERGE a relationship between two nodes."""
        props = properties or {}
        set_clause = ""
        if props:
            set_clause = " SET " + ", ".join(f"r.{k} = ${k}" for k in props.keys())

        cypher = (
            f"MATCH (a:{from_label} {{{from_key}: $from_val}}) "
            f"MATCH (b:{to_label} {{{to_key}: $to_val}}) "
            f"MERGE (a)-[r:{rel_type}]->(b)"
            f"{set_clause}"
        )
        params = {"from_val": from_val, "to_val": to_val, **props}
        with self.session() as session:
            session.run(cypher, params)

    def get_stats(self) -> dict[str, int]:
        """Get node and relationship counts by label/type."""
        node_counts = self.run_query(
            "CALL db.labels() YIELD label "
            "CALL { WITH label MATCH (n) WHERE label IN labels(n) RETURN count(n) AS cnt } "
            "RETURN label, cnt ORDER BY cnt DESC"
        )
        rel_counts = self.run_query(
            "CALL db.relationshipTypes() YIELD relationshipType AS type "
            "CALL { WITH type MATCH ()-[r]->() WHERE type(r) = type RETURN count(r) AS cnt } "
            "RETURN type, cnt ORDER BY cnt DESC"
        )
        return {
            "nodes": {r["label"]: r["cnt"] for r in node_counts},
            "relationships": {r["type"]: r["cnt"] for r in rel_counts},
        }
