"""MCP Server: Exposes the unified code graph to LLM agents via Model Context Protocol.

Tools provided:
  - query_code_graph: Run natural language queries against the graph
  - run_cypher: Execute raw Cypher queries
  - get_blast_radius: Determine impact of changing an entity
  - find_hot_paths: Find most frequently invoked code paths
  - find_dead_code: Identify unused code
  - find_patterns: Get relevant patterns/standards for a code entity
  - get_service_overview: Cross-layer view of a service
  - get_graph_stats: Current graph statistics
"""

from __future__ import annotations

import json
from typing import Any

from src.graph import GraphManager
from src.query.engine import QueryEngine, QUERY_TEMPLATES
from src.utils.config import AppConfig, load_config


def create_mcp_tools(config: AppConfig) -> list[dict]:
    """Define MCP tool schemas."""
    return [
        {
            "name": "query_code_graph",
            "description": (
                "Query the unified code intelligence graph using natural language. "
                "The graph contains static code structure (classes, methods, calls), "
                "runtime behavior (traces, latency, error rates), "
                "infrastructure topology (Terraform, Kubernetes), "
                "and organizational knowledge (patterns, ADRs, post-mortems). "
                "Ask questions like: 'What services depend on PaymentService?' or "
                "'Find dead code in the order module' or 'What's the blast radius of UserController?'"
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "question": {
                        "type": "string",
                        "description": "Natural language question about the codebase"
                    }
                },
                "required": ["question"]
            },
        },
        {
            "name": "run_cypher",
            "description": "Execute a raw Cypher query against the Neo4j code graph. Use for precise graph traversals.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "cypher": {"type": "string", "description": "Cypher query to execute"},
                    "params": {"type": "object", "description": "Query parameters", "default": {}},
                },
                "required": ["cypher"]
            },
        },
        {
            "name": "get_blast_radius",
            "description": "Determine the blast radius of changing a code entity. Shows static callers, runtime services, and K8s deployments affected.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "entity_name": {"type": "string", "description": "Name of the class, method, or function"},
                },
                "required": ["entity_name"]
            },
        },
        {
            "name": "find_hot_paths",
            "description": "Find the most frequently invoked code paths based on runtime traces.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "description": "Max results", "default": 20},
                },
            },
        },
        {
            "name": "find_dead_code",
            "description": "Find methods and functions that exist in the codebase but have never been invoked at runtime.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "description": "Max results", "default": 30},
                },
            },
        },
        {
            "name": "find_patterns",
            "description": "Find organizational patterns, standards, and ADRs relevant to the codebase.",
            "inputSchema": {"type": "object", "properties": {}},
        },
        {
            "name": "get_service_overview",
            "description": "Get a complete cross-layer overview of a service: code entities, K8s deployments, Terraform resources, applied patterns, and runtime stats.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "service_name": {"type": "string", "description": "Service name"},
                },
                "required": ["service_name"]
            },
        },
        {
            "name": "get_graph_stats",
            "description": "Get current statistics of the unified code graph (node counts, relationship counts by type).",
            "inputSchema": {"type": "object", "properties": {}},
        },
    ]


class MCPHandler:
    """Handles MCP tool calls against the code graph."""

    def __init__(self, config: AppConfig):
        self.config = config
        self.graph = GraphManager(config.neo4j)
        self.engine = QueryEngine(self.graph, config.embedding.model)

    def handle_tool_call(self, tool_name: str, arguments: dict[str, Any]) -> str:
        """Dispatch a tool call and return JSON result."""
        handlers = {
            "query_code_graph": self._handle_query,
            "run_cypher": self._handle_cypher,
            "get_blast_radius": self._handle_blast_radius,
            "find_hot_paths": self._handle_hot_paths,
            "find_dead_code": self._handle_dead_code,
            "find_patterns": self._handle_patterns,
            "get_service_overview": self._handle_service_overview,
            "get_graph_stats": self._handle_stats,
        }

        handler = handlers.get(tool_name)
        if not handler:
            return json.dumps({"error": f"Unknown tool: {tool_name}"})

        try:
            result = handler(arguments)
            return json.dumps(result, default=str, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})

    def _handle_query(self, args: dict) -> Any:
        return self.engine.natural_language_query(args["question"])

    def _handle_cypher(self, args: dict) -> Any:
        return self.graph.run_query(args["cypher"], args.get("params", {}))

    def _handle_blast_radius(self, args: dict) -> Any:
        return self.engine.run_template("blast_radius", {"entity_name": args["entity_name"]})

    def _handle_hot_paths(self, args: dict) -> Any:
        return self.engine.run_template("hot_paths", {"limit": args.get("limit", 20)})

    def _handle_dead_code(self, args: dict) -> Any:
        return self.engine.run_template("dead_code", {"limit": args.get("limit", 30)})

    def _handle_patterns(self, args: dict) -> Any:
        return self.engine.run_template("pattern_violations")

    def _handle_service_overview(self, args: dict) -> Any:
        return self.engine.run_template("cross_layer_overview", {"service_name": args["service_name"]})

    def _handle_stats(self, args: dict) -> Any:
        return self.graph.get_stats()

    def close(self):
        self.graph.close()


def run_stdio_server(config: AppConfig):
    """Run MCP server over stdio (for Claude Code integration)."""
    import sys

    handler = MCPHandler(config)
    tools = create_mcp_tools(config)

    # Simple JSON-RPC over stdio implementation
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            request = json.loads(line)
        except json.JSONDecodeError:
            continue

        method = request.get("method", "")
        req_id = request.get("id")

        if method == "tools/list":
            response = {"id": req_id, "result": {"tools": tools}}
        elif method == "tools/call":
            tool_name = request.get("params", {}).get("name", "")
            arguments = request.get("params", {}).get("arguments", {})
            result_text = handler.handle_tool_call(tool_name, arguments)
            response = {
                "id": req_id,
                "result": {"content": [{"type": "text", "text": result_text}]},
            }
        else:
            response = {"id": req_id, "result": {}}

        sys.stdout.write(json.dumps(response) + "\n")
        sys.stdout.flush()


def run_http_server(config: AppConfig, host: str = "0.0.0.0", port: int = 8100):
    """Run MCP server over HTTP (for remote access)."""
    from http.server import HTTPServer, BaseHTTPRequestHandler

    handler_instance = MCPHandler(config)
    tools = create_mcp_tools(config)

    class MCPHTTPHandler(BaseHTTPRequestHandler):
        def do_POST(self):
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length)

            try:
                request = json.loads(body)
            except json.JSONDecodeError:
                self.send_error(400, "Invalid JSON")
                return

            method = request.get("method", "")
            req_id = request.get("id")

            if method == "tools/list":
                response = {"id": req_id, "result": {"tools": tools}}
            elif method == "tools/call":
                tool_name = request.get("params", {}).get("name", "")
                arguments = request.get("params", {}).get("arguments", {})
                result_text = handler_instance.handle_tool_call(tool_name, arguments)
                response = {
                    "id": req_id,
                    "result": {"content": [{"type": "text", "text": result_text}]},
                }
            else:
                response = {"id": req_id, "result": {}}

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(response).encode())

        def log_message(self, format, *args):
            pass  # Suppress default logging

    from rich.console import Console
    console = Console()
    console.print(f"[bold cyan]MCP Server[/bold cyan] listening on {host}:{port}")
    console.print(f"  Tools: {len(tools)}")
    console.print(f"  Neo4j: {config.neo4j.uri}")

    server = HTTPServer((host, port), MCPHTTPHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        handler_instance.close()
        server.shutdown()
