"""Ingestion Pipeline: Orchestrates all layers to build the unified code graph."""

from __future__ import annotations

from pathlib import Path

from rich.console import Console
from rich.panel import Panel

from src.graph import GraphManager
from src.layers.static_layer import StaticLayerIngester
from src.layers.runtime_layer import RuntimeLayerIngester
from src.layers.infra_layer import InfraLayerIngester
from src.layers.knowledge_layer import KnowledgeLayerIngester
from src.utils.config import AppConfig

console = Console()


class IngestionPipeline:
    """Orchestrates the full ingestion across all layers."""

    def __init__(self, config: AppConfig, graph: GraphManager):
        self.config = config
        self.graph = graph

    def run(
        self,
        repo_path: str | Path | None = None,
        traces_dir: str | Path | None = None,
        logs_dir: str | Path | None = None,
        terraform_dir: str | Path | None = None,
        kubernetes_dir: str | Path | None = None,
        docs_dir: str | Path | None = None,
    ):
        """Run the full ingestion pipeline."""
        console.print(Panel.fit(
            "[bold cyan]Unified Code Intelligence Platform[/bold cyan]\n"
            "Building multi-layer code graph...",
            border_style="cyan",
        ))

        # 1. Initialize schema
        console.print("\n[bold]Setting up graph schema...[/bold]")
        self.graph.setup_schema()

        # 2. Static Layer
        if self.config.ingestion.static and repo_path:
            console.print("\n[bold blue]━━━ Static Layer ━━━[/bold blue]")
            ingester = StaticLayerIngester(self.graph)
            ingester.ingest_repository(repo_path, self.config.ingestion.languages)

        # 3. Runtime Layer
        if self.config.ingestion.runtime:
            console.print("\n[bold green]━━━ Runtime Layer ━━━[/bold green]")
            runtime = RuntimeLayerIngester(self.graph)
            if traces_dir:
                runtime.ingest_traces(traces_dir)
            if logs_dir:
                runtime.ingest_logs(logs_dir)

        # 4. Infrastructure Layer
        if self.config.ingestion.infra:
            console.print("\n[bold yellow]━━━ Infrastructure Layer ━━━[/bold yellow]")
            infra = InfraLayerIngester(self.graph)
            if terraform_dir:
                infra.ingest_terraform(terraform_dir)
            if kubernetes_dir:
                infra.ingest_kubernetes(kubernetes_dir)

        # 5. Knowledge Layer
        if self.config.ingestion.knowledge and docs_dir:
            console.print("\n[bold magenta]━━━ Knowledge Layer ━━━[/bold magenta]")
            knowledge = KnowledgeLayerIngester(self.graph, self.config.embedding.model)
            knowledge.ingest_documents(docs_dir)

        # 6. Report stats
        console.print("\n[bold]━━━ Graph Statistics ━━━[/bold]")
        stats = self.graph.get_stats()
        if stats["nodes"]:
            console.print("  [cyan]Nodes:[/cyan]")
            for label, count in stats["nodes"].items():
                console.print(f"    {label}: {count}")
        if stats["relationships"]:
            console.print("  [cyan]Relationships:[/cyan]")
            for rtype, count in stats["relationships"].items():
                console.print(f"    {rtype}: {count}")

        console.print(Panel.fit(
            "[bold green]✓ Ingestion complete[/bold green]\n"
            f"Open Neo4j Browser at http://localhost:7474",
            border_style="green",
        ))
