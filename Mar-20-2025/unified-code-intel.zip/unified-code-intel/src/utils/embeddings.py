"""Text embedding utilities using sentence-transformers."""

from __future__ import annotations

from functools import lru_cache

import numpy as np


@lru_cache(maxsize=1)
def get_embedding_model(model_name: str = "all-MiniLM-L6-v2"):
    """Lazy-load the embedding model (cached singleton)."""
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(model_name)


def embed_text(text: str, model_name: str = "all-MiniLM-L6-v2") -> list[float]:
    """Embed a single text string."""
    model = get_embedding_model(model_name)
    embedding = model.encode(text, normalize_embeddings=True)
    return embedding.tolist()


def embed_batch(texts: list[str], model_name: str = "all-MiniLM-L6-v2", batch_size: int = 64) -> list[list[float]]:
    """Embed a batch of text strings."""
    model = get_embedding_model(model_name)
    embeddings = model.encode(texts, normalize_embeddings=True, batch_size=batch_size)
    return [e.tolist() for e in embeddings]


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two embedding vectors."""
    a_arr = np.array(a)
    b_arr = np.array(b)
    return float(np.dot(a_arr, b_arr) / (np.linalg.norm(a_arr) * np.linalg.norm(b_arr)))
