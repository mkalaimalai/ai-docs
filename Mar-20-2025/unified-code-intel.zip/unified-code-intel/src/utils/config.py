"""Configuration management for the Unified Code Intelligence Platform."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class Neo4jConfig:
    uri: str = "bolt://localhost:7687"
    user: str = "neo4j"
    password: str = "changeme"
    database: str = "neo4j"


@dataclass
class EmbeddingConfig:
    model: str = "all-MiniLM-L6-v2"
    dimension: int = 384
    batch_size: int = 64


@dataclass
class LLMConfig:
    provider: str = "anthropic"
    model: str = "claude-sonnet-4-20250514"
    api_key: str = ""
    max_tokens: int = 4096


@dataclass
class IngestionConfig:
    """Controls what layers to run during ingestion."""
    static: bool = True
    runtime: bool = True
    infra: bool = True
    knowledge: bool = True
    languages: list[str] = field(default_factory=lambda: ["python", "javascript", "java", "typescript"])


@dataclass
class AppConfig:
    neo4j: Neo4jConfig = field(default_factory=Neo4jConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    ingestion: IngestionConfig = field(default_factory=IngestionConfig)


def load_config(config_path: str | Path | None = None) -> AppConfig:
    """Load configuration from YAML file with environment variable overrides."""
    config = AppConfig()

    # Load from YAML if exists
    if config_path and Path(config_path).exists():
        with open(config_path) as f:
            raw = yaml.safe_load(f) or {}

        if "neo4j" in raw:
            for k, v in raw["neo4j"].items():
                if hasattr(config.neo4j, k):
                    setattr(config.neo4j, k, v)
        if "embedding" in raw:
            for k, v in raw["embedding"].items():
                if hasattr(config.embedding, k):
                    setattr(config.embedding, k, v)
        if "llm" in raw:
            for k, v in raw["llm"].items():
                if hasattr(config.llm, k):
                    setattr(config.llm, k, v)
        if "ingestion" in raw:
            for k, v in raw["ingestion"].items():
                if hasattr(config.ingestion, k):
                    setattr(config.ingestion, k, v)

    # Environment variable overrides (highest priority)
    config.neo4j.uri = os.getenv("NEO4J_URI", config.neo4j.uri)
    config.neo4j.user = os.getenv("NEO4J_USER", config.neo4j.user)
    config.neo4j.password = os.getenv("NEO4J_PASSWORD", config.neo4j.password)
    config.llm.api_key = os.getenv("ANTHROPIC_API_KEY", "") or os.getenv("OPENAI_API_KEY", "")
    config.embedding.model = os.getenv("EMBEDDING_MODEL", config.embedding.model)

    return config
