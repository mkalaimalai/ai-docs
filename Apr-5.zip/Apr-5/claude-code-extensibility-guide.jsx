import { useState } from "react";

const data = {
  concepts: [
    {
      id: "skills",
      name: "Skills",
      icon: "📖",
      kitchen: "Recipes",
      kitchenEmoji: "📜",
      color: "#E8B931",
      colorLight: "#FDF6E3",
      tagline: "Knowledge that teaches Claude HOW to do something",
      kitchenAnalogy:
        "A recipe card pinned to the kitchen wall. It tells the chef exactly how to make Beef Wellington — the steps, the timing, the plating. The chef reads it when the dish is ordered and follows the instructions. The recipe doesn't cook anything itself.",
      whatItIs:
        "A SKILL.md markdown file with instructions, optional scripts, templates, and reference docs. Claude reads it on-demand and follows the workflow.",
      howItWorks: [
        "Claude scans skill descriptions at session start (~30-50 tokens each)",
        "When your request matches a description, full instructions load",
        "Scripts execute via bash — only output enters context, not code",
        "Supporting files load progressively, only when needed",
      ],
      sdlcUse:
        "Coding standards, PR review checklists, deployment runbooks, architecture patterns, test strategies",
      invocation: "Auto-triggered by context OR manual via /skill-name",
      fileStructure: `.claude/skills/code-review/
├── SKILL.md          # Instructions
├── scripts/
│   └── lint-check.sh
└── references/
    └── owasp-top10.md`,
    },
    {
      id: "tools",
      name: "Tools (MCP)",
      icon: "🔧",
      kitchen: "Kitchen Equipment",
      kitchenEmoji: "🍳",
      color: "#4A90D9",
      colorLight: "#EBF2FA",
      tagline: "External connections that give Claude new CAPABILITIES",
      kitchenAnalogy:
        "The oven, the blender, the sous vide machine. These are physical tools the chef uses to execute the recipe. The chef can't bake without an oven. MCP servers are equipment that connects Claude to external systems — GitHub, Jira, databases, browsers.",
      whatItIs:
        "MCP (Model Context Protocol) servers that expose external tools to Claude. Each server provides a set of callable functions (create PR, query DB, send Slack message).",
      howItWorks: [
        "MCP servers run as local processes or remote services",
        "Tool definitions load into context at session start",
        "Claude decides which tool to call based on the task",
        "Each server can consume significant context (~5K-55K tokens)",
      ],
      sdlcUse:
        "GitHub PRs, Jira tickets, database queries, browser testing, Slack notifications",
      invocation: "Claude auto-selects tools based on task needs",
      fileStructure: `# .claude/.mcp.json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"]
    }
  }
}`,
      noMcpAlternative:
        "Use bash scripts + CLI tools (gh, jira-cli, curl) inside Skills instead. Same result, zero MCP overhead.",
    },
    {
      id: "subagents",
      name: "Sub-Agents",
      icon: "👨‍🍳",
      kitchen: "Specialist Chefs",
      kitchenEmoji: "👩‍🍳",
      color: "#7B61FF",
      colorLight: "#F0ECFF",
      tagline: "Specialists that handle tasks in their own context",
      kitchenAnalogy:
        "The pastry chef, the sushi chef, the grill master. The head chef (Claude) delegates specific tasks to specialists who work independently in their own station with their own tools, then bring back the finished dish. They don't clutter the head chef's workspace.",
      whatItIs:
        "An AGENT.md file that creates a specialized AI assistant with its own context window, system prompt, tool permissions, and optionally a different model.",
      howItWorks: [
        "Each sub-agent runs in an isolated context window",
        "Has its own system prompt and restricted tool access",
        "Claude delegates automatically based on description matching",
        "Can use cheaper/faster models (e.g., Haiku for exploration)",
      ],
      sdlcUse:
        "Code reviewer agent, security auditor, test writer, documentation generator, debugger",
      invocation: "Auto-delegated by Claude OR explicit via @agent-name",
      fileStructure: `.claude/agents/security-reviewer/
└── AGENT.md
---
name: security-reviewer
description: Reviews code for security vulnerabilities
tools: Read, Grep, Glob, Bash
model: sonnet
---
You are a senior security engineer...`,
    },
    {
      id: "hooks",
      name: "Hooks",
      icon: "⚡",
      kitchen: "Kitchen Rules & Timers",
      kitchenEmoji: "⏰",
      color: "#E05252",
      colorLight: "#FDECEC",
      tagline: "Deterministic actions that ALWAYS fire at lifecycle events",
      kitchenAnalogy:
        "The kitchen rules: 'ALWAYS wash hands before touching food.' 'ALWAYS set a timer when something goes in the oven.' 'NEVER serve without a taste test.' These aren't suggestions — they're enforced policies. The chef doesn't choose whether to follow them. They fire automatically.",
      whatItIs:
        "Shell commands configured in settings.json that execute deterministically at specific lifecycle points — before/after tool calls, on file edits, on session start, on compaction, etc.",
      howItWorks: [
        "Configured in settings.json under the 'hooks' key",
        "Fire at lifecycle events: PreToolUse, PostToolUse, Notification, PostCompact, etc.",
        "Can block actions (exit code 2 = reject the tool call)",
        "Run deterministically — not dependent on LLM judgment",
      ],
      sdlcUse:
        "Auto-format on save, block edits to protected files, lint after every change, notify on completion, re-inject context after compaction",
      invocation: "Automatic — fires at configured lifecycle events",
      fileStructure: `// ~/.claude/settings.json
{
  "hooks": {
    "PostToolUse": [{
      "matcher": "Write|Edit",
      "hooks": [{
        "type": "command",
        "command": "prettier --write $CLAUDE_FILE_PATH"
      }]
    }]
  }
}`,
    },
    {
      id: "plugins",
      name: "Plugins",
      icon: "📦",
      kitchen: "Franchise Kit",
      kitchenEmoji: "🏪",
      color: "#2EAD6D",
      colorLight: "#E8F8F0",
      tagline: "Packaged bundles that distribute everything together",
      kitchenAnalogy:
        "A franchise starter kit. When you open a new McDonald's, you get the recipes, the equipment list, the kitchen rules, and the specialist training manuals — all in one box. A Plugin bundles Skills + Agents + Hooks + MCP configs into a single installable package that teams can share.",
      whatItIs:
        "A directory with a .claude-plugin/plugin.json manifest that bundles skills, agents, hooks, and MCP server configs into a distributable unit.",
      howItWorks: [
        "Install via /plugin install from a marketplace or local path",
        "All components are namespaced: /plugin-name:skill-name",
        "Versioned with semantic versioning",
        "Distributed via Git repos or private marketplace catalogs",
      ],
      sdlcUse:
        "Org-wide SDLC kit, team-specific dev workflows, framework-specific toolkits, CI/CD automation packs",
      invocation: "/plugin install plugin-name@marketplace-name",
      fileStructure: `my-sdlc-plugin/
├── .claude-plugin/
│   └── plugin.json     # Manifest
├── skills/
│   ├── code-review/SKILL.md
│   └── deploy/SKILL.md
├── agents/
│   └── security-auditor/AGENT.md
└── hooks.json`,
    },
  ],
  hierarchy: [
    {
      level: "Enterprise / Org",
      icon: "🏢",
      color: "#1a1a2e",
      path: "Managed settings (admin-controlled)",
      description:
        "Global policies, security guardrails, approved tool lists, compliance rules",
      examples: [
        "OWASP security review skill",
        "Approved deployment targets",
        "Hook: block rm -rf and force-push globally",
        "Org-wide coding standards",
        "Approved MCP servers whitelist (or CLI alternatives)",
      ],
      marketplace: "Internal Git repo → org-marketplace",
      whoManages: "Platform / Architecture team (you)",
    },
    {
      level: "Line of Business",
      icon: "🏛️",
      color: "#16213e",
      path: "LOB-level Git marketplace repo",
      description:
        "Business-unit specific patterns, domain models, regulatory requirements",
      examples: [
        "AWM-specific data handling patterns",
        "Regulatory compliance checklists",
        "Domain-specific ADR templates",
        "LOB API conventions and schemas",
      ],
      marketplace: "Git repo → awm-claude-plugins",
      whoManages: "LOB Architecture leads",
    },
    {
      level: "Team",
      icon: "👥",
      color: "#0f3460",
      path: ".claude/ in team's shared repo",
      description:
        "Team conventions, sprint workflows, shared agents",
      examples: [
        "Sprint review summary skill",
        "Team PR template + reviewer agent",
        "Harness pipeline trigger scripts",
        "Team-specific test coverage thresholds",
      ],
      marketplace: "Git repo → team-plugins OR project .claude/",
      whoManages: "Tech leads / Senior engineers",
    },
    {
      level: "Project",
      icon: "📁",
      color: "#533483",
      path: ".claude/skills/ & .claude/agents/ in project root",
      description:
        "Project-specific build commands, architecture decisions, domain context",
      examples: [
        "CLAUDE.md with project architecture",
        "Project-specific DDD bounded context skill",
        "Microservice interaction patterns",
        "Project test fixtures and factories",
      ],
      marketplace: "Committed in project repo .claude/",
      whoManages: "Project developers",
    },
    {
      level: "Developer",
      icon: "🧑‍💻",
      color: "#e94560",
      path: "~/.claude/skills/ & ~/.claude/settings.json",
      description:
        "Personal preferences, productivity shortcuts, editor integrations",
      examples: [
        "Personal code style preferences",
        "Quick-commit skill",
        "Notification hooks (desktop alerts)",
        "Personal explore/debug agents",
      ],
      marketplace: "Personal ~/.claude/ directory",
      whoManages: "Individual developer",
    },
  ],
};

const KitchenScene = () => (
  <svg viewBox="0 0 800 200" style={{ width: "100%", height: "auto", marginBottom: 24 }}>
    <defs>
      <linearGradient id="counter" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#8B7355" />
        <stop offset="100%" stopColor="#6B5340" />
      </linearGradient>
      <linearGradient id="wall" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#F5F0E8" />
        <stop offset="100%" stopColor="#E8E0D4" />
      </linearGradient>
    </defs>
    <rect x="0" y="0" width="800" height="130" fill="url(#wall)" rx="4" />
    <rect x="0" y="130" width="800" height="70" fill="url(#counter)" rx="4" />
    
    {/* Recipe card (Skills) */}
    <rect x="30" y="15" width="90" height="110" fill="#FDF6E3" stroke="#E8B931" strokeWidth="2" rx="6" />
    <text x="75" y="45" textAnchor="middle" fill="#B8860B" fontSize="24">📜</text>
    <text x="75" y="68" textAnchor="middle" fill="#8B6914" fontSize="9" fontWeight="bold">RECIPES</text>
    <text x="75" y="82" textAnchor="middle" fill="#8B6914" fontSize="7">Skills</text>
    <line x1="45" y1="92" x2="105" y2="92" stroke="#E8B931" strokeWidth="1" />
    <line x1="45" y1="100" x2="95" y2="100" stroke="#E8B931" strokeWidth="1" />
    <line x1="45" y1="108" x2="100" y2="108" stroke="#E8B931" strokeWidth="1" />

    {/* Oven (Tools/MCP) */}
    <rect x="170" y="40" width="110" height="85" fill="#D0D0D0" stroke="#4A90D9" strokeWidth="2" rx="6" />
    <rect x="180" y="55" width="90" height="45" fill="#1a1a1a" rx="3" />
    <circle cx="225" cy="115" r="5" fill="#4A90D9" />
    <text x="225" y="82" textAnchor="middle" fill="#4A90D9" fontSize="20">🍳</text>
    <text x="225" y="138" textAnchor="middle" fill="#4A90D9" fontSize="9" fontWeight="bold">EQUIPMENT</text>
    <text x="225" y="150" textAnchor="middle" fill="#4A90D9" fontSize="7">Tools / MCP</text>

    {/* Specialist chef (Sub-agents) */}
    <text x="375" y="80" textAnchor="middle" fontSize="48">👨‍🍳</text>
    <rect x="340" y="95" width="70" height="30" fill="#F0ECFF" stroke="#7B61FF" strokeWidth="1.5" rx="4" />
    <text x="375" y="114" textAnchor="middle" fill="#7B61FF" fontSize="8" fontWeight="bold">SPECIALIST</text>
    <text x="375" y="138" textAnchor="middle" fill="#7B61FF" fontSize="9" fontWeight="bold">SOUS CHEFS</text>
    <text x="375" y="150" textAnchor="middle" fill="#7B61FF" fontSize="7">Sub-Agents</text>

    {/* Timer (Hooks) */}
    <circle cx="510" cy="70" r="35" fill="#FDECEC" stroke="#E05252" strokeWidth="2" />
    <text x="510" y="78" textAnchor="middle" fontSize="28">⏰</text>
    <text x="510" y="138" textAnchor="middle" fill="#E05252" fontSize="9" fontWeight="bold">KITCHEN RULES</text>
    <text x="510" y="150" textAnchor="middle" fill="#E05252" fontSize="7">Hooks</text>

    {/* Franchise box (Plugins) */}
    <rect x="600" y="25" width="120" height="100" fill="#E8F8F0" stroke="#2EAD6D" strokeWidth="2" rx="6" />
    <text x="660" y="65" textAnchor="middle" fontSize="28">📦</text>
    <text x="660" y="88" textAnchor="middle" fill="#2EAD6D" fontSize="8" fontWeight="bold">FRANCHISE KIT</text>
    <text x="660" y="100" textAnchor="middle" fill="#1a8a52" fontSize="6">Recipes + Equipment</text>
    <text x="660" y="110" textAnchor="middle" fill="#1a8a52" fontSize="6">+ Rules + Staff Guide</text>
    <text x="660" y="138" textAnchor="middle" fill="#2EAD6D" fontSize="9" fontWeight="bold">STARTER KIT</text>
    <text x="660" y="150" textAnchor="middle" fill="#2EAD6D" fontSize="7">Plugins</text>
    
    {/* Head chef */}
    <text x="400" y="188" textAnchor="middle" fill="#333" fontSize="10" fontWeight="bold">
      🧠 HEAD CHEF = Claude Code (orchestrates everything)
    </text>
  </svg>
);

const ConceptCard = ({ concept, isExpanded, onToggle }) => (
  <div
    onClick={onToggle}
    style={{
      background: isExpanded ? concept.colorLight : "#fff",
      border: `2px solid ${isExpanded ? concept.color : "#e0e0e0"}`,
      borderRadius: 12,
      padding: "16px 18px",
      marginBottom: 12,
      cursor: "pointer",
      transition: "all 0.25s ease",
      boxShadow: isExpanded ? `0 4px 20px ${concept.color}22` : "0 1px 3px rgba(0,0,0,0.06)",
    }}
  >
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ fontSize: 22 }}>{concept.icon}</span>
        <div>
          <div style={{ fontWeight: 700, fontSize: 16, color: "#1a1a1a", fontFamily: "'DM Sans', sans-serif" }}>{concept.name}</div>
          <div style={{ fontSize: 12, color: "#666", fontFamily: "'IBM Plex Mono', monospace" }}>
            = {concept.kitchenEmoji} {concept.kitchen}
          </div>
        </div>
      </div>
      <span style={{ fontSize: 18, color: concept.color, transform: isExpanded ? "rotate(180deg)" : "rotate(0)", transition: "transform 0.2s" }}>▾</span>
    </div>
    <div style={{ fontSize: 13, color: "#555", marginTop: 6, fontStyle: "italic", fontFamily: "'DM Sans', sans-serif" }}>
      {concept.tagline}
    </div>

    {isExpanded && (
      <div style={{ marginTop: 16 }}>
        {/* Kitchen analogy */}
        <div style={{
          background: `${concept.color}11`,
          borderLeft: `4px solid ${concept.color}`,
          padding: "12px 14px",
          borderRadius: "0 8px 8px 0",
          marginBottom: 14,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: concept.color, textTransform: "uppercase", letterSpacing: 1, marginBottom: 4, fontFamily: "'IBM Plex Mono', monospace" }}>
            {concept.kitchenEmoji} Kitchen Analogy
          </div>
          <div style={{ fontSize: 13, color: "#333", lineHeight: 1.6, fontFamily: "'DM Sans', sans-serif" }}>
            {concept.kitchenAnalogy}
          </div>
        </div>

        {/* What it actually is */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#888", textTransform: "uppercase", letterSpacing: 1, marginBottom: 4, fontFamily: "'IBM Plex Mono', monospace" }}>What it is</div>
          <div style={{ fontSize: 13, color: "#333", lineHeight: 1.5, fontFamily: "'DM Sans', sans-serif" }}>{concept.whatItIs}</div>
        </div>

        {/* How it works */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#888", textTransform: "uppercase", letterSpacing: 1, marginBottom: 6, fontFamily: "'IBM Plex Mono', monospace" }}>How it works</div>
          {concept.howItWorks.map((item, i) => (
            <div key={i} style={{ fontSize: 12, color: "#444", padding: "3px 0", display: "flex", gap: 6, fontFamily: "'DM Sans', sans-serif" }}>
              <span style={{ color: concept.color, fontWeight: 700 }}>{i + 1}.</span> {item}
            </div>
          ))}
        </div>

        {/* Invocation */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#888", textTransform: "uppercase", letterSpacing: 1, marginBottom: 4, fontFamily: "'IBM Plex Mono', monospace" }}>Invocation</div>
          <div style={{ fontSize: 12, color: "#333", fontFamily: "'IBM Plex Mono', monospace", background: "#f5f5f5", padding: "6px 10px", borderRadius: 6 }}>{concept.invocation}</div>
        </div>

        {/* SDLC use */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#888", textTransform: "uppercase", letterSpacing: 1, marginBottom: 4, fontFamily: "'IBM Plex Mono', monospace" }}>Your SDLC use cases</div>
          <div style={{ fontSize: 12, color: "#555", fontFamily: "'DM Sans', sans-serif" }}>{concept.sdlcUse}</div>
        </div>

        {/* File structure */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#888", textTransform: "uppercase", letterSpacing: 1, marginBottom: 4, fontFamily: "'IBM Plex Mono', monospace" }}>File structure</div>
          <pre style={{
            fontSize: 11,
            background: "#1a1a2e",
            color: "#a8e6cf",
            padding: "12px 14px",
            borderRadius: 8,
            overflow: "auto",
            lineHeight: 1.5,
            fontFamily: "'IBM Plex Mono', monospace",
          }}>
            {concept.fileStructure}
          </pre>
        </div>

        {/* No-MCP alternative if present */}
        {concept.noMcpAlternative && (
          <div style={{
            marginTop: 12,
            background: "#FFF8E1",
            border: "1px solid #FFD54F",
            borderRadius: 8,
            padding: "10px 14px",
          }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#F57F17", marginBottom: 4, fontFamily: "'IBM Plex Mono', monospace" }}>
              ⚠️ NO MCP? NO PROBLEM
            </div>
            <div style={{ fontSize: 12, color: "#5D4037", fontFamily: "'DM Sans', sans-serif" }}>
              {concept.noMcpAlternative}
            </div>
          </div>
        )}
      </div>
    )}
  </div>
);

const HierarchyRow = ({ item, index }) => (
  <div style={{
    display: "flex",
    gap: 0,
    marginBottom: 2,
    position: "relative",
  }}>
    {/* Colored sidebar */}
    <div style={{
      width: 6,
      background: item.color,
      borderRadius: index === 0 ? "6px 0 0 0" : index === 4 ? "0 0 0 6px" : 0,
      flexShrink: 0,
    }} />
    <div style={{
      flex: 1,
      background: "#fff",
      padding: "14px 16px",
      borderBottom: index < 4 ? "1px solid #eee" : "none",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
        <span style={{ fontSize: 18 }}>{item.icon}</span>
        <span style={{ fontWeight: 700, fontSize: 14, color: item.color, fontFamily: "'DM Sans', sans-serif" }}>{item.level}</span>
      </div>
      <div style={{ fontSize: 12, color: "#555", marginBottom: 6, fontFamily: "'DM Sans', sans-serif" }}>{item.description}</div>
      
      <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 6 }}>
        {item.examples.map((ex, i) => (
          <span key={i} style={{
            fontSize: 10,
            background: `${item.color}15`,
            color: item.color,
            padding: "3px 8px",
            borderRadius: 99,
            fontFamily: "'IBM Plex Mono', monospace",
          }}>
            {ex}
          </span>
        ))}
      </div>

      <div style={{ display: "flex", gap: 12, fontSize: 10, color: "#888", fontFamily: "'IBM Plex Mono', monospace" }}>
        <span>📍 {item.path}</span>
        <span>👤 {item.whoManages}</span>
      </div>
    </div>
  </div>
);

const MarketplaceArchitecture = () => (
  <div style={{
    background: "#f9f9fb",
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  }}>
    <div style={{ fontSize: 13, fontWeight: 700, color: "#1a1a1a", marginBottom: 12, fontFamily: "'DM Sans', sans-serif" }}>
      🏗️ Marketplace Inheritance Model
    </div>
    <pre style={{
      fontSize: 10,
      fontFamily: "'IBM Plex Mono', monospace",
      color: "#333",
      lineHeight: 1.7,
      overflow: "auto",
      background: "#fff",
      padding: 14,
      borderRadius: 8,
      border: "1px solid #e0e0e0",
    }}>{`🏢 org-marketplace (Git repo)          ← Admin-managed
│   marketplace.json                   ← Catalog of all org plugins
│   plugins/
│     security-guardrails/             ← Org-wide: OWASP, secrets scanning
│     coding-standards/                ← Org-wide: naming, patterns, DDD
│     approved-cli-tools/              ← Org-wide: approved bash wrappers
│
├── 🏛️ awm-marketplace (Git repo)     ← LOB Architecture leads
│     marketplace.json
│     plugins/
│       awm-compliance/                ← Regulatory checks
│       awm-data-patterns/             ← AWM domain models
│       awm-api-conventions/           ← LOB API standards
│
├── 👥 team-alpha-plugins (Git repo)   ← Tech Lead managed
│     marketplace.json
│     plugins/
│       harness-cicd/                  ← CI/CD skills + scripts
│       sprint-workflows/              ← Agile ceremony skills
│       neo4j-queries/                 ← SCG query patterns
│
├── 📁 project/.claude/ (in repo)      ← Committed by devs
│     skills/
│       project-architecture/SKILL.md  ← This project's patterns
│     agents/
│       project-reviewer/AGENT.md      ← Project-specific agent
│     CLAUDE.md                        ← Project context
│
└── 🧑‍💻 ~/.claude/ (local)             ← Personal
      skills/
        my-shortcuts/SKILL.md          ← Personal productivity
      settings.json                    ← Personal hooks & prefs`}
    </pre>

    <div style={{
      marginTop: 12,
      background: "#E8F8F0",
      border: "1px solid #2EAD6D",
      borderRadius: 8,
      padding: "10px 14px",
    }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: "#2EAD6D", marginBottom: 4, fontFamily: "'IBM Plex Mono', monospace" }}>
        HOW DEVELOPERS INSTALL
      </div>
      <pre style={{ fontSize: 10, fontFamily: "'IBM Plex Mono', monospace", color: "#333", lineHeight: 1.8, margin: 0 }}>{`# One-time setup per developer
/plugin marketplace add yourorg/org-marketplace
/plugin marketplace add yourorg/awm-marketplace
/plugin marketplace add yourorg/team-alpha-plugins

# Install what you need
/plugin install security-guardrails@org-marketplace
/plugin install awm-compliance@awm-marketplace
/plugin install harness-cicd@team-alpha-plugins`}
      </pre>
    </div>
  </div>
);

export default function App() {
  const [expanded, setExpanded] = useState(null);
  const [activeTab, setActiveTab] = useState("concepts");

  const tabs = [
    { id: "concepts", label: "🧩 Concepts", sublabel: "What's what" },
    { id: "kitchen", label: "👨‍🍳 Kitchen", sublabel: "The analogy" },
    { id: "hierarchy", label: "🏢 Hierarchy", sublabel: "Marketplace" },
  ];

  return (
    <div style={{
      fontFamily: "'DM Sans', sans-serif",
      background: "#FAFAF8",
      minHeight: "100vh",
      padding: "0",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=IBM+Plex+Mono:wght@400;600&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet" />

      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
        padding: "28px 20px 20px",
        color: "#fff",
      }}>
        <div style={{
          fontSize: 11,
          letterSpacing: 3,
          textTransform: "uppercase",
          color: "#E8B931",
          fontFamily: "'IBM Plex Mono', monospace",
          marginBottom: 6,
        }}>
          Claude Code Extensibility
        </div>
        <div style={{
          fontSize: 26,
          fontWeight: 900,
          fontFamily: "'Playfair Display', serif",
          lineHeight: 1.15,
          marginBottom: 6,
        }}>
          The Complete Kitchen Guide
        </div>
        <div style={{ fontSize: 12, color: "#aaa", fontFamily: "'IBM Plex Mono', monospace" }}>
          Skills · Tools · Sub-Agents · Hooks · Plugins
        </div>
      </div>

      {/* Tab bar */}
      <div style={{
        display: "flex",
        gap: 0,
        background: "#fff",
        borderBottom: "2px solid #eee",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              flex: 1,
              padding: "10px 8px 8px",
              border: "none",
              borderBottom: activeTab === tab.id ? "3px solid #E8B931" : "3px solid transparent",
              background: activeTab === tab.id ? "#FAFAF8" : "#fff",
              cursor: "pointer",
              textAlign: "center",
              transition: "all 0.2s",
            }}
          >
            <div style={{ fontSize: 14 }}>{tab.label}</div>
            <div style={{ fontSize: 9, color: "#999", fontFamily: "'IBM Plex Mono', monospace" }}>{tab.sublabel}</div>
          </button>
        ))}
      </div>

      <div style={{ padding: "16px 16px 40px" }}>
        {/* CONCEPTS TAB */}
        {activeTab === "concepts" && (
          <div>
            <div style={{ fontSize: 12, color: "#888", marginBottom: 14, fontFamily: "'IBM Plex Mono', monospace" }}>
              Tap any card to expand full details
            </div>
            {data.concepts.map((c) => (
              <ConceptCard
                key={c.id}
                concept={c}
                isExpanded={expanded === c.id}
                onToggle={() => setExpanded(expanded === c.id ? null : c.id)}
              />
            ))}

            {/* Quick comparison */}
            <div style={{
              marginTop: 20,
              background: "#fff",
              border: "1px solid #e0e0e0",
              borderRadius: 12,
              overflow: "hidden",
            }}>
              <div style={{
                background: "#1a1a2e",
                color: "#fff",
                padding: "10px 16px",
                fontSize: 13,
                fontWeight: 700,
                fontFamily: "'DM Sans', sans-serif",
              }}>
                ⚡ Quick Decision Matrix
              </div>
              {[
                { q: "I want Claude to KNOW something", a: "Skill", color: "#E8B931" },
                { q: "I want Claude to ACCESS something external", a: "Tool (MCP) or Bash script in Skill", color: "#4A90D9" },
                { q: "I want a SPECIALIST for a task", a: "Sub-Agent", color: "#7B61FF" },
                { q: "I want something to ALWAYS happen", a: "Hook", color: "#E05252" },
                { q: "I want to DISTRIBUTE all of the above", a: "Plugin", color: "#2EAD6D" },
              ].map((item, i) => (
                <div key={i} style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  padding: "10px 16px",
                  borderBottom: i < 4 ? "1px solid #f0f0f0" : "none",
                  fontSize: 12,
                }}>
                  <span style={{ color: "#555", flex: 1, fontFamily: "'DM Sans', sans-serif" }}>{item.q}</span>
                  <span style={{
                    color: item.color,
                    fontWeight: 700,
                    fontSize: 11,
                    fontFamily: "'IBM Plex Mono', monospace",
                    textAlign: "right",
                    flexShrink: 0,
                    marginLeft: 8,
                  }}>
                    → {item.a}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* KITCHEN TAB */}
        {activeTab === "kitchen" && (
          <div>
            <div style={{
              fontSize: 14,
              fontWeight: 700,
              color: "#1a1a1a",
              marginBottom: 4,
              fontFamily: "'Playfair Display', serif",
            }}>
              The Restaurant Kitchen
            </div>
            <div style={{ fontSize: 12, color: "#666", marginBottom: 16, lineHeight: 1.6, fontFamily: "'DM Sans', sans-serif" }}>
              Claude Code is a <strong>head chef</strong> running a professional kitchen. Everything it needs to cook great software falls into five categories:
            </div>

            <KitchenScene />

            {/* Story flow */}
            <div style={{
              background: "#fff",
              borderRadius: 12,
              border: "1px solid #e0e0e0",
              overflow: "hidden",
            }}>
              <div style={{
                background: "linear-gradient(135deg, #1a1a2e, #0f3460)",
                color: "#fff",
                padding: "12px 16px",
                fontSize: 13,
                fontWeight: 700,
              }}>
                🍽️ A Day in Claude's Kitchen
              </div>

              {[
                {
                  time: "Order comes in",
                  emoji: "📋",
                  color: "#E8B931",
                  story: "\"Deploy the payment service.\" Claude checks the recipe wall (Skills) and finds the deploy-payment SKILL.md with step-by-step instructions, scripts, and your org's deployment checklist.",
                },
                {
                  time: "Prep the station",
                  emoji: "🔧",
                  color: "#4A90D9",
                  story: "The recipe calls for tools: run tests (bash), check Harness pipeline status (curl script), verify health endpoints. Without MCP, these are bash scripts bundled in the skill — same result, no extra infrastructure.",
                },
                {
                  time: "Delegate to specialists",
                  emoji: "👨‍🍳",
                  color: "#7B61FF",
                  story: "The head chef delegates: \"Security Reviewer, scan this code.\" The security sub-agent works in its own station (context window), runs OWASP checks, and reports back. Main chef's workspace stays clean.",
                },
                {
                  time: "Kitchen rules fire",
                  emoji: "⚡",
                  color: "#E05252",
                  story: "Every time code is written, the auto-format hook fires (Prettier). When a protected file is touched, the block hook rejects the change. These rules always execute — no exceptions, no LLM judgment needed.",
                },
                {
                  time: "New kitchen opens",
                  emoji: "📦",
                  color: "#2EAD6D",
                  story: "A new team joins. They install the org plugin: all recipes, equipment configs, specialist training, and kitchen rules arrive in one package. `/plugin install sdlc-kit@org-marketplace` and they're cooking.",
                },
              ].map((step, i) => (
                <div key={i} style={{
                  padding: "14px 16px",
                  borderBottom: i < 4 ? "1px solid #f0f0f0" : "none",
                  display: "flex",
                  gap: 12,
                }}>
                  <div style={{
                    width: 36,
                    height: 36,
                    borderRadius: "50%",
                    background: `${step.color}18`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 18,
                    flexShrink: 0,
                  }}>
                    {step.emoji}
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: step.color, marginBottom: 2, fontFamily: "'IBM Plex Mono', monospace" }}>
                      {step.time}
                    </div>
                    <div style={{ fontSize: 12, color: "#444", lineHeight: 1.6, fontFamily: "'DM Sans', sans-serif" }}>
                      {step.story}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div style={{
              marginTop: 16,
              background: "#FFF8E1",
              border: "1px solid #FFD54F",
              borderRadius: 8,
              padding: "12px 14px",
              fontSize: 12,
              lineHeight: 1.6,
              color: "#5D4037",
              fontFamily: "'DM Sans', sans-serif",
            }}>
              <strong>Key insight:</strong> Skills (recipes) are the workhorse. They can call bash scripts that do everything MCP does — query APIs, trigger pipelines, interact with databases — without needing MCP enabled. Your org's MCP restriction is a non-issue if you build good skills with bundled scripts.
            </div>
          </div>
        )}

        {/* HIERARCHY TAB */}
        {activeTab === "hierarchy" && (
          <div>
            <div style={{
              fontSize: 14,
              fontWeight: 700,
              color: "#1a1a1a",
              marginBottom: 4,
              fontFamily: "'Playfair Display', serif",
            }}>
              5-Level Marketplace Architecture
            </div>
            <div style={{ fontSize: 12, color: "#666", marginBottom: 16, lineHeight: 1.6, fontFamily: "'DM Sans', sans-serif" }}>
              Higher levels override lower. Enterprise policies can't be bypassed by project or developer settings.
            </div>

            <div style={{
              borderRadius: 12,
              overflow: "hidden",
              border: "1px solid #e0e0e0",
            }}>
              {data.hierarchy.map((item, i) => (
                <HierarchyRow key={i} item={item} index={i} />
              ))}
            </div>

            {/* Inheritance arrow */}
            <div style={{
              textAlign: "center",
              padding: "12px 0",
              fontSize: 11,
              color: "#999",
              fontFamily: "'IBM Plex Mono', monospace",
            }}>
              ↑ Higher priority overrides lower ↑
            </div>

            <MarketplaceArchitecture />

            {/* Implementation steps */}
            <div style={{
              marginTop: 16,
              background: "#fff",
              borderRadius: 12,
              border: "1px solid #e0e0e0",
              overflow: "hidden",
            }}>
              <div style={{
                background: "#1a1a2e",
                color: "#fff",
                padding: "10px 16px",
                fontSize: 13,
                fontWeight: 700,
              }}>
                🚀 Implementation Roadmap
              </div>
              {[
                { phase: "Week 1-2", task: "Create org-marketplace Git repo with security-guardrails + coding-standards plugins" },
                { phase: "Week 3-4", task: "Build AWM LOB plugins: compliance checks, domain patterns, API conventions" },
                { phase: "Week 5-6", task: "Create team-level plugins: Harness CI/CD scripts, sprint workflows, Neo4j query skills" },
                { phase: "Week 7-8", task: "Write CLAUDE.md templates for project-level context, test with pilot teams" },
                { phase: "Ongoing", task: "Developer adoption: onboarding guide, personal skill examples, feedback loops" },
              ].map((item, i) => (
                <div key={i} style={{
                  padding: "10px 16px",
                  borderBottom: i < 4 ? "1px solid #f0f0f0" : "none",
                  display: "flex",
                  gap: 12,
                  alignItems: "flex-start",
                  fontSize: 12,
                }}>
                  <span style={{
                    fontWeight: 700,
                    color: "#E8B931",
                    fontFamily: "'IBM Plex Mono', monospace",
                    whiteSpace: "nowrap",
                    fontSize: 11,
                  }}>
                    {item.phase}
                  </span>
                  <span style={{ color: "#444", fontFamily: "'DM Sans', sans-serif" }}>{item.task}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
