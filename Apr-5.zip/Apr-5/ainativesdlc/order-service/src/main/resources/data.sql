-- Customers (one per tier + one extra STANDARD)
INSERT INTO customer (id, email, first_name, last_name, tier, credit_limit, street, city, state, zip_code, country, created_at) VALUES
(1, 'john.doe@example.com', 'John', 'Doe', 'STANDARD', 5000.00, '123 Main St', 'Springfield', 'IL', '62701', 'US', '2024-01-15T10:00:00'),
(2, 'jane.smith@example.com', 'Jane', 'Smith', 'SILVER', 10000.00, '456 Oak Ave', 'Portland', 'OR', '97201', 'US', '2024-02-20T14:30:00'),
(3, 'bob.wilson@example.com', 'Bob', 'Wilson', 'GOLD', 25000.00, '789 Pine Rd', 'Austin', 'TX', '73301', 'US', '2023-11-05T09:15:00'),
(4, 'alice.johnson@example.com', 'Alice', 'Johnson', 'PLATINUM', 50000.00, '321 Elm Blvd', 'Seattle', 'WA', '98101', 'US', '2023-06-10T16:45:00'),
(5, 'charlie.brown@example.com', 'Charlie', 'Brown', 'STANDARD', 3000.00, '654 Maple Dr', 'Denver', 'CO', '80201', 'US', '2024-03-01T11:00:00');

-- Products
INSERT INTO product (id, name, description, category, base_price, stock_quantity, active) VALUES
(1, 'Wireless Keyboard', 'Ergonomic wireless keyboard with backlight', 'Electronics', 79.99, 150, true),
(2, 'USB-C Hub', '7-port USB-C hub with HDMI output', 'Electronics', 49.99, 200, true),
(3, 'Standing Desk', 'Electric adjustable standing desk', 'Furniture', 599.99, 30, true),
(4, 'Monitor Arm', 'Dual monitor arm mount', 'Furniture', 129.99, 75, true),
(5, 'Noise-Canceling Headphones', 'Over-ear wireless noise-canceling headphones', 'Electronics', 299.99, 100, true),
(6, 'Webcam 4K', 'Ultra HD webcam with autofocus', 'Electronics', 149.99, 120, true),
(7, 'Desk Lamp', 'LED desk lamp with adjustable brightness', 'Accessories', 39.99, 250, true),
(8, 'Mouse Pad XL', 'Extended mouse pad with wrist rest', 'Accessories', 24.99, 300, true),
(9, 'Laptop Stand', 'Aluminum laptop stand with cooling', 'Accessories', 59.99, 180, true),
(10, 'Cable Management Kit', 'Complete cable organization system', 'Accessories', 19.99, 400, true);

-- Sample Orders
INSERT INTO orders (id, customer_id, status, total_amount, tax_amount, discount_amount, created_at, updated_at, notes) VALUES
(1, 1, 'DELIVERED', 173.07, 13.60, 0.00, '2024-03-15T10:30:00', '2024-03-20T14:00:00', 'First order'),
(2, 3, 'PAID', 647.99, 50.93, 64.80, '2024-03-20T11:00:00', '2024-03-20T15:00:00', 'Gold member order'),
(3, 4, 'CONFIRMED', 254.98, 18.40, 38.25, '2024-03-25T09:00:00', NULL, 'Platinum discount applied');

-- Order Line Items
INSERT INTO order_line_item (id, order_id, product_id, quantity, unit_price, line_total) VALUES
(1, 1, 1, 1, 79.99, 79.99),
(2, 1, 2, 1, 49.99, 49.99),
(3, 1, 7, 1, 39.99, 39.99),
(4, 2, 3, 1, 599.99, 599.99),
(5, 2, 8, 2, 24.99, 49.98),
(6, 3, 5, 1, 299.99, 299.99);
