package com.demo.orderservice.client;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Slf4j
@Service
public class InventorySystemClient {

    public boolean checkAvailability(Long productId, Integer quantity) {
        log.info("Checking availability for product {} with quantity {}", productId, quantity);
        return true;
    }

    public String reserve(Long productId, Integer quantity) {
        log.info("Reserving {} units of product {}", quantity, productId);
        return "RES-" + UUID.randomUUID();
    }

    public void release(String reservationId) {
        log.info("Releasing reservation: {}", reservationId);
    }
}
