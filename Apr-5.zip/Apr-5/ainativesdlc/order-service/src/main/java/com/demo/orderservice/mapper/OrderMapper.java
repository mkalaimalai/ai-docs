package com.demo.orderservice.mapper;

import com.demo.orderservice.dto.CreateOrderRequest;
import com.demo.orderservice.dto.OrderResponse;
import com.demo.orderservice.entity.Customer;
import com.demo.orderservice.entity.Order;
import com.demo.orderservice.entity.OrderLineItem;
import com.demo.orderservice.entity.Product;
import com.demo.orderservice.enums.OrderStatus;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class OrderMapper {

    public OrderResponse toResponse(Order order) {
        OrderResponse response = new OrderResponse();
        response.setId(order.getId());
        response.setStatus(order.getStatus());
        response.setTotalAmount(order.getTotalAmount());
        response.setTaxAmount(order.getTaxAmount());
        response.setDiscountAmount(order.getDiscountAmount());
        response.setCreatedAt(order.getCreatedAt());
        response.setUpdatedAt(order.getUpdatedAt());

        if (order.getCustomer() != null) {
            response.setCustomerId(order.getCustomer().getId());
            response.setCustomerName(
                order.getCustomer().getFirstName() + " " + order.getCustomer().getLastName());
        }

        if (order.getItems() != null) {
            List<OrderResponse.OrderItemResponse> itemResponses = order.getItems().stream()
                .map(this::toItemResponse)
                .collect(Collectors.toList());
            response.setItems(itemResponses);
        }

        return response;
    }

    public Order toEntity(CreateOrderRequest request, Customer customer, List<Product> products) {
        Map<Long, Product> productMap = products.stream()
            .collect(Collectors.toMap(Product::getId, p -> p));

        Order order = new Order();
        order.setCustomer(customer);
        order.setStatus(OrderStatus.DRAFT);
        order.setCreatedAt(LocalDateTime.now());

        List<OrderLineItem> items = new ArrayList<>();
        for (CreateOrderRequest.OrderItemRequest itemRequest : request.getItems()) {
            Product product = productMap.get(itemRequest.getProductId());
            OrderLineItem lineItem = new OrderLineItem();
            lineItem.setOrder(order);
            lineItem.setProduct(product);
            lineItem.setQuantity(itemRequest.getQuantity());
            lineItem.setUnitPrice(product.getBasePrice());
            lineItem.setLineTotal(product.getBasePrice().multiply(
                BigDecimal.valueOf(itemRequest.getQuantity())));
            items.add(lineItem);
        }
        order.setItems(items);

        return order;
    }

    private OrderResponse.OrderItemResponse toItemResponse(OrderLineItem item) {
        OrderResponse.OrderItemResponse response = new OrderResponse.OrderItemResponse();
        response.setProductId(item.getProduct() != null ? item.getProduct().getId() : null);
        response.setProductName(item.getProduct() != null ? item.getProduct().getName() : null);
        response.setQuantity(item.getQuantity());
        response.setUnitPrice(item.getUnitPrice());
        response.setLineTotal(item.getLineTotal());
        return response;
    }
}
