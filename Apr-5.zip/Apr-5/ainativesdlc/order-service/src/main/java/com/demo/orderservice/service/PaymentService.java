package com.demo.orderservice.service;

import com.demo.orderservice.client.PaymentGatewayClient;
import com.demo.orderservice.dto.PaymentRequest;
import com.demo.orderservice.dto.PaymentResponse;
import com.demo.orderservice.entity.Order;
import com.demo.orderservice.entity.Payment;
import com.demo.orderservice.enums.OrderStatus;
import com.demo.orderservice.enums.PaymentStatus;
import com.demo.orderservice.event.PaymentCompletedEvent;
import com.demo.orderservice.exception.OrderNotFoundException;
import com.demo.orderservice.exception.PaymentDeclinedException;
import com.demo.orderservice.repository.OrderRepository;
import com.demo.orderservice.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;
    private final PaymentGatewayClient paymentGatewayClient;
    private final ApplicationEventPublisher eventPublisher;

    @Transactional
    public PaymentResponse processPayment(PaymentRequest request) {
        Order order = orderRepository.findById(request.getOrderId())
            .orElseThrow(() -> new OrderNotFoundException(request.getOrderId()));

        PaymentGatewayClient.GatewayResponse gatewayResponse =
            paymentGatewayClient.charge(request.getPaymentMethod(), request.getAmount());

        if (!gatewayResponse.isSuccess()) {
            throw new PaymentDeclinedException("Payment declined: " + gatewayResponse.getMessage());
        }

        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setAmount(request.getAmount());
        payment.setStatus(PaymentStatus.CAPTURED);
        payment.setGatewayReference(gatewayResponse.getReference());
        payment.setPaymentMethod(request.getPaymentMethod());
        payment.setProcessedAt(LocalDateTime.now());
        paymentRepository.save(payment);

        order.setStatus(OrderStatus.PAID);
        order.setUpdatedAt(LocalDateTime.now());
        orderRepository.save(order);

        eventPublisher.publishEvent(new PaymentCompletedEvent(payment, LocalDateTime.now()));
        log.info("Payment processed: {} for order {}", payment.getId(), order.getId());

        return toPaymentResponse(payment);
    }

    @Transactional
    public PaymentResponse refundPayment(Long paymentId) {
        Payment payment = paymentRepository.findById(paymentId)
            .orElseThrow(() -> new RuntimeException("Payment not found: " + paymentId));

        paymentGatewayClient.refund(payment.getGatewayReference());

        payment.setStatus(PaymentStatus.REFUNDED);
        payment.setProcessedAt(LocalDateTime.now());
        paymentRepository.save(payment);

        log.info("Payment refunded: {}", paymentId);
        return toPaymentResponse(payment);
    }

    public List<PaymentResponse> getPaymentsForOrder(Long orderId) {
        return paymentRepository.findByOrderId(orderId).stream()
            .map(this::toPaymentResponse)
            .collect(Collectors.toList());
    }

    private PaymentResponse toPaymentResponse(Payment payment) {
        return PaymentResponse.builder()
            .id(payment.getId())
            .orderId(payment.getOrder().getId())
            .amount(payment.getAmount())
            .status(payment.getStatus())
            .gatewayReference(payment.getGatewayReference())
            .processedAt(payment.getProcessedAt())
            .build();
    }
}
