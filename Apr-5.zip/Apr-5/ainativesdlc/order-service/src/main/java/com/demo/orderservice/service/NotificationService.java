package com.demo.orderservice.service;

import com.demo.orderservice.entity.Order;
import com.demo.orderservice.entity.Payment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class NotificationService {

    // DEMO BUG #5: @Async methods intentionally have NO error handling / no try-catch
    @Async
    public void sendOrderConfirmation(Order order) {
        log.info("Sending order confirmation email for order {}", order.getId());
        // Simulated email sending — no error handling (intentional demo bug)
        simulateEmailSend("Order Confirmation", order.getCustomer().getEmail());
    }

    @Async
    public void sendPaymentReceipt(Payment payment) {
        log.info("Sending payment receipt for payment {}", payment.getId());
        // Simulated email sending — no error handling (intentional demo bug)
        simulateEmailSend("Payment Receipt", payment.getOrder().getCustomer().getEmail());
    }

    @Async
    public void sendCancellationNotice(Order order) {
        log.info("Sending cancellation notice for order {}", order.getId());
        // Simulated email sending — no error handling (intentional demo bug)
        simulateEmailSend("Order Cancellation", order.getCustomer().getEmail());
    }

    private void simulateEmailSend(String subject, String to) {
        log.info("Simulating email: subject='{}', to='{}'", subject, to);
    }
}
