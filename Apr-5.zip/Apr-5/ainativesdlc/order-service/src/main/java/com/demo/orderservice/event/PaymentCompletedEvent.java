package com.demo.orderservice.event;

import com.demo.orderservice.entity.Payment;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
public class PaymentCompletedEvent {

    private final Payment payment;
    private final LocalDateTime timestamp;
}
