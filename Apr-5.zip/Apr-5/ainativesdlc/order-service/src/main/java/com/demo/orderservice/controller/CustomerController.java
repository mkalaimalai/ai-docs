package com.demo.orderservice.controller;

import com.demo.orderservice.dto.CustomerProfileResponse;
import com.demo.orderservice.dto.OrderResponse;
import com.demo.orderservice.mapper.OrderMapper;
import com.demo.orderservice.repository.OrderRepository;
import com.demo.orderservice.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/customers")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;
    private final OrderRepository orderRepository;
    private final OrderMapper orderMapper;

    @GetMapping("/{id}")
    public ResponseEntity<CustomerProfileResponse> getCustomer(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.getCustomerProfile(id));
    }

    @GetMapping("/{id}/orders")
    public ResponseEntity<List<OrderResponse>> getCustomerOrders(@PathVariable Long id) {
        List<OrderResponse> orders = orderRepository.findByCustomerId(id).stream()
            .map(orderMapper::toResponse)
            .collect(Collectors.toList());
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/{id}/history")
    public ResponseEntity<CustomerProfileResponse> getCustomerHistory(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.getCustomerProfile(id));
    }
}
