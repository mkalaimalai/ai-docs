package com.demo.orderservice.client;

import com.demo.orderservice.enums.CustomerTier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Slf4j
@Service
public class CrmClient {

    public CrmCustomerDTO getCustomerProfile(String email) {
        log.info("Fetching CRM customer profile for email: {}", email);
        return CrmCustomerDTO.builder()
                .loyaltyPoints(1500)
                .lifetimeValue(new BigDecimal("25000.00"))
                .segment("Premium")
                .lastInteraction(LocalDateTime.now().minusDays(7))
                .build();
    }

    public void updateCustomerTier(Long customerId, CustomerTier newTier) {
        log.info("Updating customer {} tier to {} in CRM", customerId, newTier);
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CrmCustomerDTO {
        private Integer loyaltyPoints;
        private BigDecimal lifetimeValue;
        private String segment;
        private LocalDateTime lastInteraction;
    }
}
