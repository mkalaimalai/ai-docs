package com.demo.orderservice.event;

import com.demo.orderservice.service.InventoryService;
import com.demo.orderservice.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

@Slf4j
@Component
@RequiredArgsConstructor
public class OrderEventListener {

    private final NotificationService notificationService;
    private final InventoryService inventoryService;

    @TransactionalEventListener
    public void handleOrderCreated(OrderCreatedEvent event) {
        log.info("Handling OrderCreatedEvent for order: {}", event.getOrder().getId());
        notificationService.sendOrderConfirmation(event.getOrder());
    }

    @EventListener
    public void handleOrderCancelled(OrderCancelledEvent event) {
        log.info("Handling OrderCancelledEvent for order: {}, reason: {}",
                event.getOrder().getId(), event.getReason());
        inventoryService.releaseReservation(event.getOrder().getItems());
        notificationService.sendCancellationNotice(event.getOrder());
    }

    @EventListener
    public void handlePaymentCompleted(PaymentCompletedEvent event) {
        log.info("Handling PaymentCompletedEvent for payment: {}", event.getPayment().getId());
        notificationService.sendPaymentReceipt(event.getPayment());
    }
}
