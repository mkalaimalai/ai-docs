package com.demo.orderservice.event;

import com.demo.orderservice.entity.Order;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
public class OrderCreatedEvent {

    private final Order order;
    private final LocalDateTime timestamp;
}
