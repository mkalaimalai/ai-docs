package com.demo.orderservice.validation;

import com.demo.orderservice.entity.Customer;
import com.demo.orderservice.exception.CreditLimitExceededException;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class CreditCheckValidator {

    public void validate(Customer customer, BigDecimal orderTotal) {
        if (orderTotal.compareTo(customer.getCreditLimit()) > 0) {
            throw new CreditLimitExceededException(
                    "Order total " + orderTotal + " exceeds credit limit " + customer.getCreditLimit()
                            + " for customer " + customer.getId());
        }
    }
}
