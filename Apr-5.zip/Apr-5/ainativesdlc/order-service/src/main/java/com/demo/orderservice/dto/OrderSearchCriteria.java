package com.demo.orderservice.dto;

import com.demo.orderservice.enums.OrderStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderSearchCriteria {

    private Long customerId;
    private OrderStatus status;
    private LocalDate fromDate;
    private LocalDate toDate;
    private int page = 0;
    private int size = 20;
}
