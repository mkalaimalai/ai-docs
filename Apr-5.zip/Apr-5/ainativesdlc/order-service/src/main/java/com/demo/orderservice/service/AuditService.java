package com.demo.orderservice.service;

import com.demo.orderservice.entity.AuditLog;
import com.demo.orderservice.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    public void logAction(String action, String entityType, Long entityId, String actor) {
        AuditLog auditLog = new AuditLog();
        auditLog.setAction(action);
        auditLog.setEntityType(entityType);
        auditLog.setEntityId(entityId);
        auditLog.setActor(actor);
        auditLog.setTimestamp(LocalDateTime.now());
        auditLog.setDetails(action + " on " + entityType + " " + entityId);
        auditLogRepository.save(auditLog);
        log.info("Audit: {} {} {} by {}", action, entityType, entityId, actor);
    }
}
