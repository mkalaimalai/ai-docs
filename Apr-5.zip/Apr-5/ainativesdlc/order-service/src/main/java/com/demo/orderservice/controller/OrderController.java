package com.demo.orderservice.controller;

import com.demo.orderservice.dto.CreateOrderRequest;
import com.demo.orderservice.dto.OrderResponse;
import com.demo.orderservice.dto.OrderSearchCriteria;
import com.demo.orderservice.enums.OrderStatus;
import com.demo.orderservice.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@Valid @RequestBody CreateOrderRequest request) {
        OrderResponse response = orderService.createOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderResponse> getOrder(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.getOrder(id));
    }

    @GetMapping
    public ResponseEntity<Page<OrderResponse>> searchOrders(@ModelAttribute OrderSearchCriteria criteria) {
        return ResponseEntity.ok(orderService.searchOrders(criteria));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<OrderResponse> updateOrderStatus(
            @PathVariable Long id,
            @RequestParam OrderStatus status) {
        return ResponseEntity.ok(orderService.updateOrderStatus(id, status));
    }

    @PostMapping("/bulk")
    public ResponseEntity<List<OrderResponse>> createBulkOrders(
            @Valid @RequestBody List<CreateOrderRequest> requests) {
        return ResponseEntity.status(HttpStatus.CREATED).body(orderService.createBulkOrders(requests));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancelOrder(@PathVariable Long id) {
        orderService.cancelOrder(id);
        return ResponseEntity.noContent().build();
    }
}
