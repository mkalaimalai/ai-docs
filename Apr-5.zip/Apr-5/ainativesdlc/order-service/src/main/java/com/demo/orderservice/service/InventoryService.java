package com.demo.orderservice.service;

import com.demo.orderservice.client.InventorySystemClient;
import com.demo.orderservice.entity.OrderLineItem;
import com.demo.orderservice.exception.InsufficientStockException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class InventoryService {

    private final InventorySystemClient inventorySystemClient;
    private final Map<Long, String> reservations = new HashMap<>();

    public void validateAndReserveStock(List<OrderLineItem> items) {
        for (OrderLineItem item : items) {
            boolean available = inventorySystemClient.checkAvailability(
                item.getProduct().getId(), item.getQuantity());
            if (!available) {
                throw new InsufficientStockException(
                    "Insufficient stock for product: " + item.getProduct().getName());
            }
            String reservationId = inventorySystemClient.reserve(
                item.getProduct().getId(), item.getQuantity());
            reservations.put(item.getProduct().getId(), reservationId);
            log.info("Reserved stock for product {}: {}", item.getProduct().getId(), reservationId);
        }
    }

    public void releaseReservation(List<OrderLineItem> items) {
        for (OrderLineItem item : items) {
            String reservationId = reservations.get(item.getProduct().getId());
            if (reservationId != null) {
                inventorySystemClient.release(reservationId);
                reservations.remove(item.getProduct().getId());
                log.info("Released reservation {} for product {}", reservationId, item.getProduct().getId());
            }
        }
    }
}
