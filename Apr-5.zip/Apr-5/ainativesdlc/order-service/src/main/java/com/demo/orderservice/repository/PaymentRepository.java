package com.demo.orderservice.repository;

import com.demo.orderservice.entity.Payment;
import com.demo.orderservice.enums.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    List<Payment> findByOrderId(Long orderId);

    List<Payment> findByStatus(PaymentStatus status);

    @Query(value = "SELECT * FROM payment WHERE status = 'PENDING' AND processed_at < :cutoff", nativeQuery = true)
    List<Payment> findPendingOlderThan(@Param("cutoff") LocalDateTime cutoff);
}
