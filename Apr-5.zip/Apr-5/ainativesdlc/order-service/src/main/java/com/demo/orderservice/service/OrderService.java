package com.demo.orderservice.service;

import com.demo.orderservice.dto.CreateOrderRequest;
import com.demo.orderservice.dto.OrderResponse;
import com.demo.orderservice.dto.OrderSearchCriteria;
import com.demo.orderservice.entity.Customer;
import com.demo.orderservice.entity.Order;
import com.demo.orderservice.entity.OrderLineItem;
import com.demo.orderservice.entity.Product;
import com.demo.orderservice.enums.OrderStatus;
import com.demo.orderservice.event.OrderCancelledEvent;
import com.demo.orderservice.event.OrderCreatedEvent;
import com.demo.orderservice.mapper.OrderMapper;
import com.demo.orderservice.repository.OrderRepository;
import com.demo.orderservice.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

    // DEMO BUG #7: 6 injected dependencies — borderline god class
    private final OrderRepository orderRepository;
    private final CustomerService customerService;
    private final OrderValidationService orderValidationService;
    private final InventoryService inventoryService;
    private final PricingService pricingService;
    private final ApplicationEventPublisher eventPublisher;
    private final AuditService auditService;
    private final OrderMapper orderMapper;
    private final ProductRepository productRepository;

    @Transactional
    public OrderResponse createOrder(CreateOrderRequest request) {
        Customer customer = customerService.getCustomer(request.getCustomerId());
        orderValidationService.validateOrder(request, customer);

        List<Product> products = request.getItems().stream()
            .map(item -> productRepository.findById(item.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found: " + item.getProductId())))
            .collect(Collectors.toList());

        Order order = orderMapper.toEntity(request, customer, products);
        inventoryService.validateAndReserveStock(order.getItems());

        order.setTotalAmount(pricingService.calculateTotal(order.getItems(), customer.getTier()));
        order.setStatus(OrderStatus.DRAFT);
        order = orderRepository.save(order);

        eventPublisher.publishEvent(new OrderCreatedEvent(order, LocalDateTime.now()));
        auditService.logAction("CREATE_ORDER", "Order", order.getId(), "system");

        log.info("Order created: {}", order.getId());
        return orderMapper.toResponse(order);
    }

    @Transactional
    public void cancelOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
            .orElseThrow(() -> new com.demo.orderservice.exception.OrderNotFoundException(orderId));

        order.setStatus(OrderStatus.CANCELLED);
        order.setUpdatedAt(LocalDateTime.now());
        orderRepository.save(order);

        eventPublisher.publishEvent(new OrderCancelledEvent(order, "User requested cancellation", LocalDateTime.now()));
        auditService.logAction("CANCEL_ORDER", "Order", order.getId(), "system");

        log.info("Order cancelled: {}", orderId);
    }

    // DEMO BUG #1: Intentionally MISSING @Transactional but calls OrderRepository.save()
    // DEMO BUG #2: Intentionally NO state transition validation
    // DEMO BUG #3: Does NOT call AuditService (inconsistent with createOrder/cancelOrder)
    public OrderResponse updateOrderStatus(Long orderId, OrderStatus newStatus) {
        Order order = orderRepository.findById(orderId)
            .orElseThrow(() -> new com.demo.orderservice.exception.OrderNotFoundException(orderId));

        // No validation that the state transition is valid (e.g., CONFIRMED -> DRAFT should be rejected)
        order.setStatus(newStatus);
        order.setUpdatedAt(LocalDateTime.now());
        orderRepository.save(order);

        // No audit logging here (inconsistent with createOrder and cancelOrder)

        log.info("Order {} status updated to {}", orderId, newStatus);
        return orderMapper.toResponse(order);
    }

    public OrderResponse getOrder(Long id) {
        Order order = orderRepository.findById(id)
            .orElseThrow(() -> new com.demo.orderservice.exception.OrderNotFoundException(id));
        return orderMapper.toResponse(order);
    }

    public Page<OrderResponse> searchOrders(OrderSearchCriteria criteria) {
        PageRequest pageRequest = PageRequest.of(criteria.getPage(), criteria.getSize());
        return orderRepository.findAll(pageRequest).map(orderMapper::toResponse);
    }

    public List<OrderResponse> createBulkOrders(List<CreateOrderRequest> requests) {
        return requests.stream()
            .map(this::createOrder)
            .collect(Collectors.toList());
    }
}
