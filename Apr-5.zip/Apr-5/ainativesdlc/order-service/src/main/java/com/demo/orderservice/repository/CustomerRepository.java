package com.demo.orderservice.repository;

import com.demo.orderservice.entity.Customer;
import com.demo.orderservice.enums.CustomerTier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    Optional<Customer> findByEmail(String email);

    List<Customer> findByTier(CustomerTier tier);
}
