package com.demo.orderservice.event;

import com.demo.orderservice.entity.Order;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
public class OrderCancelledEvent {

    private final Order order;
    private final String reason;
    private final LocalDateTime timestamp;
}
