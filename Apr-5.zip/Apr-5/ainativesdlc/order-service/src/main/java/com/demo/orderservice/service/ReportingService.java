package com.demo.orderservice.service;

import com.demo.orderservice.dto.OrderSummaryReport;
import com.demo.orderservice.enums.OrderStatus;
import com.demo.orderservice.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReportingService {

    private final OrderRepository orderRepository;

    public OrderSummaryReport getOrderSummary(LocalDate from, LocalDate to) {
        LocalDateTime fromDateTime = from.atStartOfDay();
        LocalDateTime toDateTime = to.atTime(LocalTime.MAX);

        List<Object[]> statusCounts = orderRepository.countByStatusAndDateRange(fromDateTime, toDateTime);
        Map<OrderStatus, Long> orderCountByStatus = new HashMap<>();
        long totalOrders = 0;
        for (Object[] row : statusCounts) {
            OrderStatus status = (OrderStatus) row[0];
            Long count = (Long) row[1];
            orderCountByStatus.put(status, count);
            totalOrders += count;
        }

        BigDecimal totalRevenue = orderRepository.sumRevenueByDateRange(fromDateTime, toDateTime);
        BigDecimal averageOrderValue = totalOrders > 0
            ? totalRevenue.divide(BigDecimal.valueOf(totalOrders), 2, RoundingMode.HALF_UP)
            : BigDecimal.ZERO;

        return OrderSummaryReport.builder()
            .orderCountByStatus(orderCountByStatus)
            .totalRevenue(totalRevenue)
            .averageOrderValue(averageOrderValue)
            .totalOrders((int) totalOrders)
            .fromDate(from)
            .toDate(to)
            .build();
    }

    public Map<String, BigDecimal> getRevenueByPeriod(String period) {
        Map<String, BigDecimal> revenue = new HashMap<>();
        revenue.put("current", BigDecimal.valueOf(15000.00));
        revenue.put("previous", BigDecimal.valueOf(12500.00));
        log.info("Revenue by period '{}': {}", period, revenue);
        return revenue;
    }
}
