package com.demo.orderservice.service;

import com.demo.orderservice.dto.CreateOrderRequest;
import com.demo.orderservice.entity.Customer;
import com.demo.orderservice.validation.CreditCheckValidator;
import com.demo.orderservice.validation.OrderValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class OrderValidationService {

    private final OrderValidator orderValidator;
    private final CreditCheckValidator creditCheckValidator;

    public void validateOrder(CreateOrderRequest request, Customer customer) {
        orderValidator.validateOrder(request);
        creditCheckValidator.validate(customer, BigDecimal.ZERO);
    }
}
