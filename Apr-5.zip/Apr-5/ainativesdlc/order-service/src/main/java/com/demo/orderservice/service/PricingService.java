package com.demo.orderservice.service;

import com.demo.orderservice.entity.OrderLineItem;
import com.demo.orderservice.enums.CustomerTier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
@Slf4j
public class PricingService {

    private static final BigDecimal TAX_RATE = new BigDecimal("0.085");

    public BigDecimal calculateTotal(List<OrderLineItem> items, CustomerTier tier) {
        BigDecimal subtotal = items.stream()
            .map(item -> item.getUnitPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal discount = getDiscountRate(tier);
        BigDecimal discountAmount = subtotal.multiply(discount).setScale(2, RoundingMode.HALF_UP);
        BigDecimal afterDiscount = subtotal.subtract(discountAmount);
        BigDecimal tax = afterDiscount.multiply(TAX_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal total = afterDiscount.add(tax);

        log.info("Pricing: subtotal={}, discount={}%, tax={}, total={}",
            subtotal, discount.multiply(BigDecimal.valueOf(100)), tax, total);
        return total;
    }

    private BigDecimal getDiscountRate(CustomerTier tier) {
        return switch (tier) {
            case STANDARD -> BigDecimal.ZERO;
            case SILVER -> new BigDecimal("0.05");
            case GOLD -> new BigDecimal("0.10");
            case PLATINUM -> new BigDecimal("0.15");
        };
    }
}
