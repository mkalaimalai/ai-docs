package com.demo.orderservice.mapper;

import com.demo.orderservice.dto.CustomerProfileResponse;
import com.demo.orderservice.entity.Customer;
import com.demo.orderservice.entity.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class CustomerMapper {

    public CustomerProfileResponse toProfileResponse(Customer customer, List<Order> orders) {
        CustomerProfileResponse response = new CustomerProfileResponse();
        response.setFullName(customer.getFirstName() + " " + customer.getLastName());
        response.setEmail(customer.getEmail());
        response.setTier(customer.getTier());
        response.setCreditLimit(customer.getCreditLimit());
        response.setMemberSince(customer.getCreatedAt());

        BigDecimal totalSpent = orders.stream()
                .map(Order::getTotalAmount)
                .filter(amount -> amount != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        response.setTotalSpent(totalSpent);
        response.setOrderCount(orders.size());

        return response;
    }
}
