package com.demo.orderservice.entity;

import com.demo.orderservice.enums.CustomerTier;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String email;

    private String firstName;
    private String lastName;

    @Enumerated(EnumType.STRING)
    private CustomerTier tier;

    private BigDecimal creditLimit;

    @Embedded
    private Address address;

    private LocalDateTime createdAt;
}
