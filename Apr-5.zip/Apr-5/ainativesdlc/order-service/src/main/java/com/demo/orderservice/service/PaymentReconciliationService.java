package com.demo.orderservice.service;

import com.demo.orderservice.client.PaymentGatewayClient;
import com.demo.orderservice.entity.Payment;
import com.demo.orderservice.enums.PaymentStatus;
import com.demo.orderservice.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentReconciliationService {

    private final PaymentRepository paymentRepository;
    private final PaymentGatewayClient paymentGatewayClient;

    @Scheduled(cron = "0 0 2 * * *")
    public void reconcilePendingPayments() {
        List<Payment> pendingPayments = paymentRepository.findByStatus(PaymentStatus.PENDING);
        log.info("Reconciling {} pending payments", pendingPayments.size());

        for (Payment payment : pendingPayments) {
            PaymentStatus gatewayStatus = paymentGatewayClient.checkStatus(payment.getGatewayReference());
            if (gatewayStatus != payment.getStatus()) {
                payment.setStatus(gatewayStatus);
                paymentRepository.save(payment);
                log.info("Updated payment {} status to {}", payment.getId(), gatewayStatus);
            }
        }
    }
}
