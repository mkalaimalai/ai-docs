package com.demo.orderservice.client;

import com.demo.orderservice.enums.PaymentStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;

@Slf4j
@Service
public class PaymentGatewayClient {

    public GatewayResponse charge(String paymentMethod, BigDecimal amount) {
        log.info("Charging {} via payment method: {}", amount, paymentMethod);
        String reference = UUID.randomUUID().toString();
        return new GatewayResponse(true, reference, "Payment charged successfully");
    }

    public GatewayResponse refund(String gatewayReference) {
        log.info("Refunding payment with gateway reference: {}", gatewayReference);
        return new GatewayResponse(true, gatewayReference, "Refund processed successfully");
    }

    public PaymentStatus checkStatus(String gatewayReference) {
        log.info("Checking payment status for gateway reference: {}", gatewayReference);
        return PaymentStatus.CAPTURED;
    }

    @Data
    @AllArgsConstructor
    public static class GatewayResponse {
        private boolean success;
        private String reference;
        private String message;
    }
}
