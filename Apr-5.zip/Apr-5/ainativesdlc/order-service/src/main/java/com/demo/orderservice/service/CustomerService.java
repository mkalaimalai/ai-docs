package com.demo.orderservice.service;

import com.demo.orderservice.client.CrmClient;
import com.demo.orderservice.dto.CustomerProfileResponse;
import com.demo.orderservice.entity.Customer;
import com.demo.orderservice.entity.Order;
import com.demo.orderservice.exception.CustomerNotFoundException;
import com.demo.orderservice.mapper.CustomerMapper;
import com.demo.orderservice.repository.CustomerRepository;
import com.demo.orderservice.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final OrderRepository orderRepository;
    private final CrmClient crmClient;
    private final CustomerMapper customerMapper;

    public Customer getCustomer(Long customerId) {
        Customer customer = customerRepository.findById(customerId)
            .orElseThrow(() -> new CustomerNotFoundException(customerId));
        crmClient.getCustomerProfile(customer.getEmail());
        return customer;
    }

    @Cacheable("customers")
    public CustomerProfileResponse getCustomerProfile(Long customerId) {
        Customer customer = getCustomer(customerId);
        List<Order> orders = orderRepository.findByCustomerId(customerId);
        return customerMapper.toProfileResponse(customer, orders);
    }
}
