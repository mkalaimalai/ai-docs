package com.demo.orderservice.validation;

import com.demo.orderservice.dto.CreateOrderRequest;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
public class OrderValidator {

    public void validateOrder(CreateOrderRequest request) {
        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one item");
        }

        Set<Long> productIds = new HashSet<>();
        for (CreateOrderRequest.OrderItemRequest item : request.getItems()) {
            if (item.getQuantity() == null || item.getQuantity() <= 0) {
                throw new IllegalArgumentException("All item quantities must be positive");
            }
            if (!productIds.add(item.getProductId())) {
                throw new IllegalArgumentException("Duplicate product ID: " + item.getProductId());
            }
        }
    }
}
