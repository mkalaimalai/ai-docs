package com.demo.orderservice.enums;

public enum CustomerTier {
    STANDARD,
    SILVER,
    GOLD,
    PLATINUM
}
