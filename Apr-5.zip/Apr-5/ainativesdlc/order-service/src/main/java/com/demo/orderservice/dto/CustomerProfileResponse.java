package com.demo.orderservice.dto;

import com.demo.orderservice.enums.CustomerTier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerProfileResponse {

    private Long id;
    private String fullName;
    private String email;
    private CustomerTier tier;
    private BigDecimal creditLimit;
    private BigDecimal totalSpent;
    private Integer orderCount;
    private LocalDateTime memberSince;
}
