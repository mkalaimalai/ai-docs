package com.demo.orderservice.controller;

import com.demo.orderservice.dto.OrderSummaryReport;
import com.demo.orderservice.service.ReportingService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportingService reportingService;

    // DEMO BUG #6: Missing @PreAuthorize("hasRole('ADMIN')") — inconsistent with getRevenueByPeriod
    @GetMapping("/summary")
    public ResponseEntity<OrderSummaryReport> getOrderSummary(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return ResponseEntity.ok(reportingService.getOrderSummary(from, to));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/revenue")
    public ResponseEntity<Map<String, BigDecimal>> getRevenueByPeriod(@RequestParam String period) {
        return ResponseEntity.ok(reportingService.getRevenueByPeriod(period));
    }
}
