package com.demo.astengine.parser;

import com.demo.astengine.model.AstNode;
import com.demo.astengine.model.AstRelationship;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class ClassVisitor extends VoidVisitorAdapter<Void> {

    @Getter
    private final List<AstNode> nodes = new ArrayList<>();
    @Getter
    private final List<AstRelationship> relationships = new ArrayList<>();

    @Setter
    private String currentPackage = "";

    private final Set<String> createdPackageNodes = new HashSet<>();

    private static final Set<String> SPRING_COMPONENT_ANNOTATIONS = Set.of(
            "RestController", "Service", "Repository", "Entity",
            "Configuration", "Component", "Controller"
    );

    private static final Set<String> DEPENDENCY_INJECTION_ANNOTATIONS = Set.of(
            "Service", "Component", "Controller", "RestController", "Configuration"
    );

    @Override
    public void visit(ClassOrInterfaceDeclaration classDecl, Void arg) {
        try {
            processClassOrInterface(classDecl);
        } catch (Exception e) {
            log.warn("Failed to process class/interface {}: {}", classDecl.getNameAsString(), e.getMessage());
        }
        super.visit(classDecl, arg);
    }

    @Override
    public void visit(EnumDeclaration enumDecl, Void arg) {
        try {
            processEnum(enumDecl);
        } catch (Exception e) {
            log.warn("Failed to process enum {}: {}", enumDecl.getNameAsString(), e.getMessage());
        }
        super.visit(enumDecl, arg);
    }

    private void processClassOrInterface(ClassOrInterfaceDeclaration classDecl) {
        String name = classDecl.getNameAsString();
        String fqn = currentPackage.isEmpty() ? name : currentPackage + "." + name;
        boolean isInterface = classDecl.isInterface();
        List<String> annotations = AnnotationVisitor.extractAnnotations(classDecl);
        List<String> modifiers = classDecl.getModifiers().stream()
                .map(m -> m.getKeyword().asString())
                .collect(Collectors.toList());

        String javadoc = classDecl.getJavadoc()
                .map(jd -> {
                    String desc = jd.getDescription().toText();
                    int newlineIdx = desc.indexOf('\n');
                    return newlineIdx > 0 ? desc.substring(0, newlineIdx).trim() : desc.trim();
                })
                .orElse("");

        Map<String, Object> props = new LinkedHashMap<>();
        props.put("name", name);
        props.put("fqn", fqn);
        props.put("annotations", annotations);
        props.put("modifiers", modifiers);
        props.put("javadoc", javadoc);

        AstNode classNode = AstNode.builder()
                .label(isInterface ? "Interface" : "Class")
                .properties(new HashMap<>(props))
                .build();
        nodes.add(classNode);

        // Package node
        if (!currentPackage.isEmpty()) {
            createPackageNodeIfNeeded(currentPackage, classNode.getId());
        }

        // Build field name -> type map for heuristic call resolution
        Map<String, String> fieldNameToType = new LinkedHashMap<>();
        for (FieldDeclaration field : classDecl.getFields()) {
            String fieldType = field.getElementType().asString();
            for (var variable : field.getVariables()) {
                fieldNameToType.put(variable.getNameAsString(), fieldType);
            }
        }

        // Fields
        for (FieldDeclaration field : classDecl.getFields()) {
            processField(field, classNode.getId());
        }

        // Methods
        for (MethodDeclaration method : classDecl.getMethods()) {
            MethodVisitor mv = new MethodVisitor(classNode.getId(), name, fieldNameToType);
            AstNode methodNode = mv.visitMethod(method);
            nodes.addAll(mv.getNodes());
            relationships.addAll(mv.getRelationships());
            relationships.add(AstRelationship.builder()
                    .sourceId(classNode.getId())
                    .targetId(methodNode.getId())
                    .type("HAS_METHOD")
                    .build());
        }

        // Constructors
        for (ConstructorDeclaration ctor : classDecl.getConstructors()) {
            processConstructor(ctor, classNode.getId());
        }

        // Dependency injection: for @Service/@Component classes, create DEPENDS_ON for fields
        boolean isDependencyInjectionCandidate = annotations.stream()
                .anyMatch(DEPENDENCY_INJECTION_ANNOTATIONS::contains);
        if (isDependencyInjectionCandidate) {
            for (FieldDeclaration field : classDecl.getFields()) {
                String fieldType = field.getElementType().asString();
                for (var variable : field.getVariables()) {
                    relationships.add(AstRelationship.builder()
                            .sourceId(classNode.getId())
                            .targetId(fieldType)
                            .type("DEPENDS_ON")
                            .properties(new HashMap<>(Map.of(
                                    "fieldName", variable.getNameAsString(),
                                    "fieldType", fieldType
                            )))
                            .build());
                }
            }
        }
    }

    private void processEnum(EnumDeclaration enumDecl) {
        String name = enumDecl.getNameAsString();
        String fqn = currentPackage.isEmpty() ? name : currentPackage + "." + name;
        List<String> annotations = AnnotationVisitor.extractAnnotations(enumDecl);

        Map<String, Object> props = new LinkedHashMap<>();
        props.put("name", name);
        props.put("fqn", fqn);
        props.put("annotations", annotations);
        props.put("isEnum", true);

        AstNode enumNode = AstNode.builder()
                .label("Class")
                .properties(new HashMap<>(props))
                .build();
        nodes.add(enumNode);

        // Package node
        if (!currentPackage.isEmpty()) {
            createPackageNodeIfNeeded(currentPackage, enumNode.getId());
        }

        // Enum constants
        for (EnumConstantDeclaration constant : enumDecl.getEntries()) {
            AstNode constantNode = AstNode.builder()
                    .label("EnumConstant")
                    .properties(new HashMap<>(Map.of(
                            "name", constant.getNameAsString(),
                            "parentEnum", fqn
                    )))
                    .build();
            nodes.add(constantNode);
            relationships.add(AstRelationship.builder()
                    .sourceId(enumNode.getId())
                    .targetId(constantNode.getId())
                    .type("HAS_ENUM_CONSTANT")
                    .build());
        }
    }

    private void processField(FieldDeclaration field, String classNodeId) {
        String fieldType = field.getElementType().asString();
        List<String> fieldAnnotations = AnnotationVisitor.extractAnnotations(field);

        for (var variable : field.getVariables()) {
            Map<String, Object> fieldProps = new LinkedHashMap<>();
            fieldProps.put("name", variable.getNameAsString());
            fieldProps.put("type", fieldType);
            fieldProps.put("annotations", fieldAnnotations);

            AstNode fieldNode = AstNode.builder()
                    .label("Field")
                    .properties(new HashMap<>(fieldProps))
                    .build();
            nodes.add(fieldNode);
            relationships.add(AstRelationship.builder()
                    .sourceId(classNodeId)
                    .targetId(fieldNode.getId())
                    .type("HAS_FIELD")
                    .build());
        }
    }

    private void processConstructor(ConstructorDeclaration ctor, String classNodeId) {
        List<String> annotations = AnnotationVisitor.extractAnnotations(ctor);
        List<String> paramTypes = ctor.getParameters().stream()
                .map(p -> p.getTypeAsString())
                .collect(Collectors.toList());

        Map<String, Object> ctorProps = new LinkedHashMap<>();
        ctorProps.put("name", ctor.getNameAsString());
        ctorProps.put("annotations", annotations);
        ctorProps.put("parameterTypes", paramTypes);

        AstNode ctorNode = AstNode.builder()
                .label("Constructor")
                .properties(new HashMap<>(ctorProps))
                .build();
        nodes.add(ctorNode);
        relationships.add(AstRelationship.builder()
                .sourceId(classNodeId)
                .targetId(ctorNode.getId())
                .type("HAS_CONSTRUCTOR")
                .build());
    }

    private void createPackageNodeIfNeeded(String packageName, String classNodeId) {
        String packageNodeId;
        if (!createdPackageNodes.contains(packageName)) {
            AstNode packageNode = AstNode.builder()
                    .label("Package")
                    .properties(new HashMap<>(Map.of("name", packageName)))
                    .build();
            nodes.add(packageNode);
            createdPackageNodes.add(packageName);
            packageNodeId = packageNode.getId();
        } else {
            // Find the existing package node
            packageNodeId = nodes.stream()
                    .filter(n -> "Package".equals(n.getLabel())
                            && packageName.equals(n.getProperty("name")))
                    .map(AstNode::getId)
                    .findFirst()
                    .orElse(packageName);
        }
        relationships.add(AstRelationship.builder()
                .sourceId(packageNodeId)
                .targetId(classNodeId)
                .type("CONTAINS")
                .build());
    }
}
