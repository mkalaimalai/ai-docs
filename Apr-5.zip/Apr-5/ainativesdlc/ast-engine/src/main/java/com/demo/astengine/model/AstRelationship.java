package com.demo.astengine.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AstRelationship {

    private String sourceId;
    private String targetId;
    private String type;
    @Builder.Default
    private Map<String, Object> properties = new HashMap<>();
}
