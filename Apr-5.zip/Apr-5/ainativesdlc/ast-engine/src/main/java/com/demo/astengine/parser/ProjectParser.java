package com.demo.astengine.parser;

import com.demo.astengine.model.AstNode;
import com.demo.astengine.model.AstRelationship;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

@Slf4j
public class ProjectParser {

    private final Path sourceDirectory;
    private final JavaParser javaParser;

    @Getter
    private final List<AstNode> nodes = new ArrayList<>();
    @Getter
    private final List<AstRelationship> relationships = new ArrayList<>();

    public ProjectParser(Path sourceDirectory) {
        this.sourceDirectory = sourceDirectory;

        CombinedTypeSolver typeSolver = new CombinedTypeSolver();
        typeSolver.add(new ReflectionTypeSolver());
        typeSolver.add(new JavaParserTypeSolver(sourceDirectory));

        JavaSymbolSolver symbolSolver = new JavaSymbolSolver(typeSolver);
        ParserConfiguration config = new ParserConfiguration()
                .setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_17)
                .setSymbolResolver(symbolSolver);
        this.javaParser = new JavaParser(config);
    }

    /**
     * Parse all Java files in the source directory, collecting AST nodes and relationships.
     */
    public void parse() {
        try (Stream<Path> paths = Files.walk(sourceDirectory)) {
            paths.filter(p -> p.toString().endsWith(".java"))
                    .filter(Files::isRegularFile)
                    .forEach(this::parseFile);
        } catch (IOException e) {
            log.warn("Failed to walk source directory {}: {}", sourceDirectory, e.getMessage());
        }

        // Post-process: resolve the call graph
        List<AstRelationship> resolvedCalls = CallGraphBuilder.buildCallGraph(nodes, relationships);

        // Remove CALLS_UNRESOLVED and add resolved CALLS
        relationships.removeIf(r -> "CALLS_UNRESOLVED".equals(r.getType()));
        relationships.addAll(resolvedCalls);

        log.info("Parsing complete. Nodes: {}, Relationships: {}", nodes.size(), relationships.size());
    }

    private void parseFile(Path filePath) {
        try {
            var parseResult = javaParser.parse(filePath);
            if (parseResult.isSuccessful() && parseResult.getResult().isPresent()) {
                CompilationUnit cu = parseResult.getResult().get();
                ClassVisitor visitor = new ClassVisitor();

                // Set the current package from the compilation unit
                cu.getPackageDeclaration().ifPresent(pd ->
                        visitor.setCurrentPackage(pd.getNameAsString()));

                cu.accept(visitor, null);

                nodes.addAll(visitor.getNodes());
                relationships.addAll(visitor.getRelationships());
            } else {
                log.warn("Failed to parse file {}: {}", filePath,
                        parseResult.getProblems());
            }
        } catch (IOException e) {
            log.warn("Could not read file {}: {}", filePath, e.getMessage());
        } catch (Exception e) {
            log.warn("Unexpected error parsing file {}: {}", filePath, e.getMessage());
        }
    }
}
