package com.demo.astengine.parser;

import com.demo.astengine.model.AstNode;
import com.demo.astengine.model.AstRelationship;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.resolution.types.ResolvedType;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public class DependencyResolver {

    private DependencyResolver() {
        // utility class
    }

    /**
     * Resolve field types via JavaSymbolSolver and create DEPENDS_ON relationships
     * for project-internal dependencies (types starting with "com.demo").
     */
    public static List<AstRelationship> resolveFieldDependencies(
            ClassOrInterfaceDeclaration classDecl, String classNodeId) {

        List<AstRelationship> resolved = new ArrayList<>();

        for (FieldDeclaration field : classDecl.getFields()) {
            try {
                ResolvedType resolvedType = field.getElementType().resolve();
                if (resolvedType.isReferenceType()) {
                    String qualifiedName = resolvedType.asReferenceType().getQualifiedName();
                    if (qualifiedName.startsWith("com.demo")) {
                        for (var variable : field.getVariables()) {
                            resolved.add(AstRelationship.builder()
                                    .sourceId(classNodeId)
                                    .targetId(qualifiedName)
                                    .type("DEPENDS_ON")
                                    .properties(new HashMap<>(Map.of(
                                            "fieldName", variable.getNameAsString(),
                                            "resolvedType", qualifiedName
                                    )))
                                    .build());
                        }
                    }
                }
            } catch (Exception e) {
                log.warn("Could not resolve field type in {}: {}",
                        classDecl.getNameAsString(), e.getMessage());
            }
        }

        return resolved;
    }

    /**
     * Detect external system integrations by looking for classes whose type name
     * ends with "Client" (e.g., PaymentClient, NotificationClient).
     * Creates ExternalSystem nodes and INTEGRATES_WITH relationships.
     */
    public static List<AstRelationship> resolveExternalSystemIntegrations(
            ClassOrInterfaceDeclaration classDecl, String classNodeId, List<AstNode> nodes) {

        List<AstRelationship> integrations = new ArrayList<>();

        for (FieldDeclaration field : classDecl.getFields()) {
            String fieldTypeName = field.getElementType().asString();
            if (fieldTypeName.endsWith("Client")) {
                String systemName = fieldTypeName.replace("Client", "");

                // Create ExternalSystem node if not already present
                boolean alreadyExists = nodes.stream()
                        .anyMatch(n -> "ExternalSystem".equals(n.getLabel())
                                && systemName.equals(n.getProperty("name")));

                if (!alreadyExists) {
                    AstNode externalSystemNode = AstNode.builder()
                            .label("ExternalSystem")
                            .properties(new HashMap<>(Map.of(
                                    "name", systemName,
                                    "clientClass", fieldTypeName
                            )))
                            .build();
                    nodes.add(externalSystemNode);

                    integrations.add(AstRelationship.builder()
                            .sourceId(classNodeId)
                            .targetId(externalSystemNode.getId())
                            .type("INTEGRATES_WITH")
                            .properties(new HashMap<>(Map.of(
                                    "clientField", fieldTypeName,
                                    "systemName", systemName
                            )))
                            .build());
                } else {
                    // Find existing node and create relationship
                    nodes.stream()
                            .filter(n -> "ExternalSystem".equals(n.getLabel())
                                    && systemName.equals(n.getProperty("name")))
                            .findFirst()
                            .ifPresent(existingNode ->
                                    integrations.add(AstRelationship.builder()
                                            .sourceId(classNodeId)
                                            .targetId(existingNode.getId())
                                            .type("INTEGRATES_WITH")
                                            .properties(new HashMap<>(Map.of(
                                                    "clientField", fieldTypeName,
                                                    "systemName", systemName
                                            )))
                                            .build()));
                }
            }
        }

        return integrations;
    }
}
