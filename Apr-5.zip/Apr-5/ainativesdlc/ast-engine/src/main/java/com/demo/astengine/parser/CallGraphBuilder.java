package com.demo.astengine.parser;

import com.demo.astengine.model.AstNode;
import com.demo.astengine.model.AstRelationship;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class CallGraphBuilder {

    private CallGraphBuilder() {
        // utility class
    }

    /**
     * Resolve CALLS_UNRESOLVED relationships into proper CALLS relationships
     * that point from source method node to target method node.
     *
     * @param nodes         all parsed AST nodes
     * @param relationships all parsed AST relationships (including CALLS_UNRESOLVED)
     * @return new list of resolved CALLS relationships (to replace the unresolved ones)
     */
    public static List<AstRelationship> buildCallGraph(
            List<AstNode> nodes, List<AstRelationship> relationships) {

        // Build className -> list of Method nodes
        // We derive class name from the HAS_METHOD relationships + class node FQN/name
        Map<String, List<AstNode>> classToMethods = buildClassMethodMap(nodes, relationships);

        // Also build a flat map of methodName -> list of Method nodes (for heuristic fallback)
        Map<String, List<AstNode>> methodNameToNodes = nodes.stream()
                .filter(n -> "Method".equals(n.getLabel()))
                .collect(Collectors.groupingBy(n -> (String) n.getProperty("name")));

        List<AstRelationship> resolvedCalls = new ArrayList<>();

        List<AstRelationship> unresolvedRels = relationships.stream()
                .filter(r -> "CALLS_UNRESOLVED".equals(r.getType()))
                .collect(Collectors.toList());

        for (AstRelationship unresolved : unresolvedRels) {
            String calledClass = (String) unresolved.getProperties().get("calledClass");
            String calledMethod = (String) unresolved.getProperties().get("calledMethod");
            Object paramCountObj = unresolved.getProperties().get("paramCount");
            int paramCount = paramCountObj instanceof Number ? ((Number) paramCountObj).intValue() : -1;

            AstNode targetMethod = null;

            // Try exact class match first
            if (calledClass != null) {
                targetMethod = findMethodInClass(classToMethods, calledClass, calledMethod, paramCount);

                // Try simple name match if FQN didn't work
                if (targetMethod == null) {
                    String simpleName = calledClass.contains(".")
                            ? calledClass.substring(calledClass.lastIndexOf('.') + 1)
                            : calledClass;
                    targetMethod = findMethodInClass(classToMethods, simpleName, calledMethod, paramCount);
                }
            }

            // Heuristic fallback: match by method name + parameter count across all classes
            if (targetMethod == null) {
                List<AstNode> candidates = methodNameToNodes.getOrDefault(calledMethod, Collections.emptyList());
                if (candidates.size() == 1) {
                    targetMethod = candidates.get(0);
                } else if (paramCount >= 0) {
                    targetMethod = candidates.stream()
                            .filter(m -> matchesParamCount(m, paramCount, nodes, relationships))
                            .findFirst()
                            .orElse(null);
                }
            }

            if (targetMethod != null) {
                resolvedCalls.add(AstRelationship.builder()
                        .sourceId(unresolved.getSourceId())
                        .targetId(targetMethod.getId())
                        .type("CALLS")
                        .properties(new HashMap<>(Map.of(
                                "calledClass", calledClass != null ? calledClass : "unknown",
                                "calledMethod", calledMethod
                        )))
                        .build());
            } else {
                log.debug("Could not resolve call: {} -> {}.{}",
                        unresolved.getSourceId(), calledClass, calledMethod);
            }
        }

        return resolvedCalls;
    }

    private static Map<String, List<AstNode>> buildClassMethodMap(
            List<AstNode> nodes, List<AstRelationship> relationships) {

        // Map node ID -> node for fast lookup
        Map<String, AstNode> nodeById = nodes.stream()
                .collect(Collectors.toMap(AstNode::getId, n -> n, (a, b) -> a));

        Map<String, List<AstNode>> classToMethods = new HashMap<>();

        // Find HAS_METHOD relationships to link class nodes to method nodes
        for (AstRelationship rel : relationships) {
            if ("HAS_METHOD".equals(rel.getType())) {
                AstNode classNode = nodeById.get(rel.getSourceId());
                AstNode methodNode = nodeById.get(rel.getTargetId());
                if (classNode != null && methodNode != null) {
                    // Index by FQN
                    String fqn = classNode.getStringProperty("fqn");
                    if (fqn != null) {
                        classToMethods.computeIfAbsent(fqn, k -> new ArrayList<>()).add(methodNode);
                    }
                    // Also index by simple name
                    String name = classNode.getStringProperty("name");
                    if (name != null) {
                        classToMethods.computeIfAbsent(name, k -> new ArrayList<>()).add(methodNode);
                    }
                }
            }
        }

        return classToMethods;
    }

    private static AstNode findMethodInClass(
            Map<String, List<AstNode>> classToMethods, String className, String methodName, int paramCount) {

        List<AstNode> methods = classToMethods.get(className);
        if (methods == null) {
            return null;
        }

        // Exact name match
        List<AstNode> nameMatches = methods.stream()
                .filter(m -> methodName.equals(m.getProperty("name")))
                .collect(Collectors.toList());

        if (nameMatches.size() == 1) {
            return nameMatches.get(0);
        }

        // If multiple overloads, no way to disambiguate further here without param count
        // from the caller side — return first match
        return nameMatches.isEmpty() ? null : nameMatches.get(0);
    }

    /**
     * Check if a method node has the expected number of parameters by counting
     * HAS_PARAMETER relationships.
     */
    private static boolean matchesParamCount(
            AstNode methodNode, int expectedCount,
            List<AstNode> nodes, List<AstRelationship> relationships) {

        long actualCount = relationships.stream()
                .filter(r -> "HAS_PARAMETER".equals(r.getType())
                        && r.getSourceId().equals(methodNode.getId()))
                .count();
        return actualCount == expectedCount;
    }
}
