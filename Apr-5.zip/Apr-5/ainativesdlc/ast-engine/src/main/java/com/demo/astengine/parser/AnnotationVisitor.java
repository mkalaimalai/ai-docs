package com.demo.astengine.parser;

import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.nodeTypes.NodeWithAnnotations;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class AnnotationVisitor {

    private AnnotationVisitor() {
        // utility class
    }

    /**
     * Extract simple names of all annotations on a node.
     */
    public static List<String> extractAnnotations(NodeWithAnnotations<?> node) {
        return node.getAnnotations().stream()
                .map(a -> a.getName().getIdentifier())
                .collect(Collectors.toList());
    }

    /**
     * Extract annotation attribute name-value pairs.
     */
    public static Map<String, String> extractAnnotationAttributes(AnnotationExpr annotation) {
        Map<String, String> attributes = new LinkedHashMap<>();
        try {
            if (annotation instanceof NormalAnnotationExpr normalAnnotation) {
                for (MemberValuePair pair : normalAnnotation.getPairs()) {
                    attributes.put(pair.getNameAsString(), pair.getValue().toString());
                }
            } else if (annotation instanceof SingleMemberAnnotationExpr singleMember) {
                attributes.put("value", singleMember.getMemberValue().toString());
            }
            // MarkerAnnotationExpr has no attributes
        } catch (Exception e) {
            log.warn("Failed to extract attributes from annotation {}: {}",
                    annotation.getNameAsString(), e.getMessage());
        }
        return attributes;
    }
}
