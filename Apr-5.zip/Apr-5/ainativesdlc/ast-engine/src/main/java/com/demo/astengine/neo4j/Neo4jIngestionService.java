package com.demo.astengine.neo4j;

import com.demo.astengine.model.AstNode;
import com.demo.astengine.model.AstRelationship;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.*;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
public class Neo4jIngestionService {

    private static final int BATCH_SIZE = 500;

    private final Driver driver;

    public void ingestNodes(List<AstNode> nodes) {
        Map<String, List<AstNode>> nodesByLabel = nodes.stream()
                .collect(Collectors.groupingBy(AstNode::getLabel));

        int totalIngested = 0;

        for (Map.Entry<String, List<AstNode>> entry : nodesByLabel.entrySet()) {
            String label = entry.getKey();
            List<AstNode> labelNodes = entry.getValue();

            String cypher;
            if ("Class".equals(label) || "Interface".equals(label)) {
                cypher = CypherTemplates.mergeClassByFqn();
            } else if ("Package".equals(label)) {
                cypher = CypherTemplates.mergePackageByName();
            } else {
                cypher = CypherTemplates.mergeNodeByLabel(label);
            }

            for (int i = 0; i < labelNodes.size(); i += BATCH_SIZE) {
                List<AstNode> batch = labelNodes.subList(i, Math.min(i + BATCH_SIZE, labelNodes.size()));
                List<Map<String, Object>> paramMaps = batch.stream()
                        .map(this::toParameterMap)
                        .collect(Collectors.toList());

                try (Session session = driver.session()) {
                    session.executeWrite(tx -> {
                        tx.run(cypher, Collections.singletonMap("nodes", paramMaps));
                        return null;
                    });
                } catch (Exception e) {
                    log.error("Failed to ingest batch of {} nodes with label '{}'", batch.size(), label, e);
                }

                totalIngested += batch.size();
            }

            log.info("Ingested {} nodes with label '{}'", labelNodes.size(), label);
        }

        log.info("Total nodes ingested: {}", totalIngested);
    }

    public void ingestRelationships(List<AstRelationship> relationships) {
        Map<String, List<AstRelationship>> relsByType = relationships.stream()
                .collect(Collectors.groupingBy(AstRelationship::getType));

        int totalCreated = 0;

        for (Map.Entry<String, List<AstRelationship>> entry : relsByType.entrySet()) {
            String type = entry.getKey();
            List<AstRelationship> typeRels = entry.getValue();
            String cypher = CypherTemplates.mergeRelationship(type);

            for (int i = 0; i < typeRels.size(); i += BATCH_SIZE) {
                List<AstRelationship> batch = typeRels.subList(i, Math.min(i + BATCH_SIZE, typeRels.size()));
                List<Map<String, Object>> paramMaps = batch.stream()
                        .map(rel -> {
                            Map<String, Object> map = new HashMap<>();
                            map.put("sourceId", rel.getSourceId());
                            map.put("targetId", rel.getTargetId());
                            Map<String, Object> props = new HashMap<>();
                            if (rel.getProperties() != null) {
                                rel.getProperties().forEach((k, v) -> props.put(k, convertValue(v)));
                            }
                            map.put("props", props);
                            return map;
                        })
                        .collect(Collectors.toList());

                try (Session session = driver.session()) {
                    session.executeWrite(tx -> {
                        tx.run(cypher, Collections.singletonMap("rels", paramMaps));
                        return null;
                    });
                } catch (Exception e) {
                    log.error("Failed to ingest batch of {} relationships with type '{}'", batch.size(), type, e);
                }

                totalCreated += batch.size();
            }

            log.info("Ingested {} relationships with type '{}'", typeRels.size(), type);
        }

        log.info("Total relationships created: {}", totalCreated);
    }

    public void clearGraph() {
        log.info("Clearing all nodes and relationships from the graph");
        try (Session session = driver.session()) {
            session.executeWrite(tx -> {
                tx.run(CypherTemplates.deleteAll());
                return null;
            });
            log.info("Graph cleared successfully");
        } catch (Exception e) {
            log.error("Failed to clear graph", e);
            throw e;
        }
    }

    private Map<String, Object> toParameterMap(AstNode node) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", node.getId());

        Map<String, Object> props = new HashMap<>();
        if (node.getProperties() != null) {
            node.getProperties().forEach((key, value) -> props.put(key, convertValue(value)));
        }
        map.put("props", props);

        // Flatten known properties for Class/Interface MERGE queries
        if (node.getProperties() != null) {
            map.put("fqn", node.getProperties().getOrDefault("fqn", node.getId()));
            map.put("name", node.getProperties().getOrDefault("name", ""));
            map.put("annotations", convertValue(node.getProperties().getOrDefault("annotations", "")));
            map.put("modifiers", convertValue(node.getProperties().getOrDefault("modifiers", "")));
            map.put("javadoc", convertValue(node.getProperties().getOrDefault("javadoc", "")));
        }

        return map;
    }

    private Object convertValue(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof List) {
            return ((List<?>) value).stream()
                    .map(Object::toString)
                    .collect(Collectors.joining(", ", "[", "]"));
        }
        if (value.getClass().isArray()) {
            return Arrays.toString((Object[]) value);
        }
        return value;
    }
}
