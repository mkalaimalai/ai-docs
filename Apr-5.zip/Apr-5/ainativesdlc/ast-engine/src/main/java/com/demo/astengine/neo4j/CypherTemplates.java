package com.demo.astengine.neo4j;

public final class CypherTemplates {
    private CypherTemplates() {}

    public static String mergeNodeByLabel(String label) {
        return "UNWIND $nodes AS node MERGE (n:" + label + " {id: node.id}) SET n += node.props";
    }

    public static String mergeClassByFqn() {
        return "UNWIND $nodes AS node MERGE (n:Class {fqn: node.fqn}) SET n.id = node.id, n.name = node.name, n.annotations = node.annotations, n.modifiers = node.modifiers, n.javadoc = node.javadoc";
    }

    public static String mergePackageByName() {
        return "UNWIND $nodes AS node MERGE (n:Package {name: node.props.name}) SET n.id = node.id";
    }

    public static String mergeRelationship(String type) {
        return "UNWIND $rels AS rel MATCH (source {id: rel.sourceId}) MATCH (target {id: rel.targetId}) MERGE (source)-[r:" + type + "]->(target) SET r += rel.props";
    }

    public static String createConstraint(String label, String property) {
        return "CREATE CONSTRAINT " + label + "_" + property + "_unique IF NOT EXISTS FOR (n:" + label + ") REQUIRE n." + property + " IS UNIQUE";
    }

    public static String createIndex(String label, String property) {
        return "CREATE INDEX " + label + "_" + property + "_idx IF NOT EXISTS FOR (n:" + label + ") ON (n." + property + ")";
    }

    public static String deleteAll() {
        return "MATCH (n) DETACH DELETE n";
    }

    public static String countNodes() {
        return "MATCH (n) RETURN labels(n)[0] AS label, count(n) AS count ORDER BY count DESC";
    }

    public static String countRelationships() {
        return "MATCH ()-[r]->() RETURN type(r) AS type, count(r) AS count ORDER BY count DESC";
    }
}
