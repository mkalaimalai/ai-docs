package com.demo.astengine.parser;

import com.demo.astengine.model.AstNode;
import com.demo.astengine.model.AstRelationship;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class MethodVisitor extends VoidVisitorAdapter<Void> {

    private final String ownerClassId;
    private final String ownerClassName;
    private final Map<String, String> fieldNameToType;

    @Getter
    private final List<AstNode> nodes = new ArrayList<>();
    @Getter
    private final List<AstRelationship> relationships = new ArrayList<>();

    private static final Set<String> NOTABLE_ANNOTATIONS = Set.of(
            "Transactional", "Async", "Scheduled",
            "GetMapping", "PostMapping", "PutMapping", "DeleteMapping",
            "PreAuthorize", "Cacheable",
            "EventListener", "TransactionalEventListener"
    );

    public MethodVisitor(String ownerClassId, String ownerClassName) {
        this(ownerClassId, ownerClassName, Collections.emptyMap());
    }

    public MethodVisitor(String ownerClassId, String ownerClassName, Map<String, String> fieldNameToType) {
        this.ownerClassId = ownerClassId;
        this.ownerClassName = ownerClassName;
        this.fieldNameToType = fieldNameToType;
    }

    /**
     * Analyse a method declaration and produce AST nodes/relationships.
     */
    public AstNode visitMethod(MethodDeclaration md) {
        String methodName = md.getNameAsString();
        List<String> annotations = AnnotationVisitor.extractAnnotations(md);
        List<String> modifiers = md.getModifiers().stream()
                .map(m -> m.getKeyword().asString())
                .collect(Collectors.toList());

        String returnType;
        try {
            returnType = md.getTypeAsString();
        } catch (Exception e) {
            returnType = "unknown";
        }

        Map<String, Object> props = new LinkedHashMap<>();
        props.put("name", methodName);
        props.put("returnType", returnType);
        props.put("annotations", annotations);
        props.put("modifiers", modifiers);
        md.getBegin().ifPresent(pos -> props.put("lineStart", pos.line));
        md.getEnd().ifPresent(pos -> props.put("lineEnd", pos.line));

        AstNode methodNode = AstNode.builder()
                .label("Method")
                .properties(new HashMap<>(props))
                .build();
        nodes.add(methodNode);

        // Parameters
        for (Parameter param : md.getParameters()) {
            AstNode paramNode = AstNode.builder()
                    .label("Parameter")
                    .properties(new HashMap<>(Map.of(
                            "name", param.getNameAsString(),
                            "type", param.getTypeAsString(),
                            "annotations", AnnotationVisitor.extractAnnotations(param)
                    )))
                    .build();
            nodes.add(paramNode);
            relationships.add(AstRelationship.builder()
                    .sourceId(methodNode.getId())
                    .targetId(paramNode.getId())
                    .type("HAS_PARAMETER")
                    .build());
        }

        // Thrown exceptions
        for (var thrown : md.getThrownExceptions()) {
            AstNode exceptionNode = AstNode.builder()
                    .label("Exception")
                    .properties(new HashMap<>(Map.of("name", thrown.asString())))
                    .build();
            nodes.add(exceptionNode);
            relationships.add(AstRelationship.builder()
                    .sourceId(methodNode.getId())
                    .targetId(exceptionNode.getId())
                    .type("THROWS")
                    .build());
        }

        // Detect event listener annotations
        if (annotations.contains("EventListener") || annotations.contains("TransactionalEventListener")) {
            for (Parameter param : md.getParameters()) {
                String eventType = param.getTypeAsString();
                relationships.add(AstRelationship.builder()
                        .sourceId(methodNode.getId())
                        .targetId(eventType)
                        .type("LISTENS_TO")
                        .properties(new HashMap<>(Map.of("eventType", eventType)))
                        .build());
            }
        }

        // Walk method body for method calls
        md.getBody().ifPresent(body -> body.findAll(MethodCallExpr.class).forEach(callExpr ->
                processMethodCall(callExpr, methodNode.getId())
        ));

        return methodNode;
    }

    private void processMethodCall(MethodCallExpr callExpr, String sourceMethodId) {
        String calledMethod = callExpr.getNameAsString();

        // Detect ApplicationEventPublisher.publishEvent()
        if ("publishEvent".equals(calledMethod)) {
            callExpr.getScope().ifPresent(scope -> {
                if (scope.toString().contains("eventPublisher") || scope.toString().contains("applicationEventPublisher")) {
                    if (!callExpr.getArguments().isEmpty()) {
                        String eventArg = callExpr.getArgument(0).toString();
                        // Try to extract the class name from "new EventClass(...)" or variable
                        String eventClass = extractEventClassName(eventArg);
                        relationships.add(AstRelationship.builder()
                                .sourceId(sourceMethodId)
                                .targetId(eventClass)
                                .type("PUBLISHES")
                                .properties(new HashMap<>(Map.of("eventType", eventClass)))
                                .build());
                    }
                }
            });
        }

        // Try symbol resolution first
        String resolvedClass = null;
        String resolvedMethod = calledMethod;
        int paramCount = callExpr.getArguments().size();

        try {
            var resolvedCall = callExpr.resolve();
            resolvedClass = resolvedCall.declaringType().getQualifiedName();
        } catch (Exception e) {
            // Symbol resolution failed — use heuristic
            resolvedClass = resolveViaHeuristic(callExpr);
            if (resolvedClass == null) {
                log.debug("Could not resolve method call: {}.{} in {}.{}",
                        callExpr.getScope().map(Object::toString).orElse("this"),
                        calledMethod, ownerClassName, sourceMethodId);
                return;
            }
        }

        Map<String, Object> callProps = new HashMap<>();
        callProps.put("calledClass", resolvedClass);
        callProps.put("calledMethod", resolvedMethod);
        callProps.put("paramCount", paramCount);

        relationships.add(AstRelationship.builder()
                .sourceId(sourceMethodId)
                .targetId(resolvedClass + "#" + resolvedMethod)
                .type("CALLS_UNRESOLVED")
                .properties(callProps)
                .build());
    }

    private String resolveViaHeuristic(MethodCallExpr callExpr) {
        return callExpr.getScope()
                .map(scope -> {
                    String scopeName = scope.toString();
                    // Check if scope matches a known field name
                    String fieldType = fieldNameToType.get(scopeName);
                    if (fieldType != null) {
                        return fieldType;
                    }
                    // If scope looks like a class name (starts uppercase), use it directly
                    if (Character.isUpperCase(scopeName.charAt(0)) && !scopeName.contains("(")) {
                        return scopeName;
                    }
                    return null;
                })
                .orElse(null);
    }

    private String extractEventClassName(String eventArg) {
        // Handle "new SomeEvent(...)"
        if (eventArg.startsWith("new ")) {
            String afterNew = eventArg.substring(4).trim();
            int parenIdx = afterNew.indexOf('(');
            if (parenIdx > 0) {
                return afterNew.substring(0, parenIdx).trim();
            }
        }
        return eventArg;
    }
}
