package com.demo.astengine.neo4j;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.Driver;
import org.neo4j.driver.Session;

@Slf4j
@RequiredArgsConstructor
public class GraphSchemaInitializer {

    private final Driver driver;

    public void initializeSchema() {
        try (Session session = driver.session()) {
            // Uniqueness constraints
            log.info("Creating uniqueness constraint: Class(fqn)");
            session.run(CypherTemplates.createConstraint("Class", "fqn"));

            log.info("Creating uniqueness constraint: Interface(fqn)");
            session.run(CypherTemplates.createConstraint("Interface", "fqn"));

            log.info("Creating uniqueness constraint: Package(name)");
            session.run(CypherTemplates.createConstraint("Package", "name"));

            // Indexes
            log.info("Creating index: Method(name)");
            session.run(CypherTemplates.createIndex("Method", "name"));

            log.info("Creating index: Annotation(name)");
            session.run(CypherTemplates.createIndex("Annotation", "name"));

            log.info("Creating index: Field(name)");
            session.run(CypherTemplates.createIndex("Field", "name"));

            log.info("Creating index: ExternalSystem(name)");
            session.run(CypherTemplates.createIndex("ExternalSystem", "name"));

            log.info("Graph schema initialization complete");
        } catch (Exception e) {
            log.error("Failed to initialize graph schema", e);
            throw e;
        }
    }
}
