package com.demo.astengine;

import com.demo.astengine.model.AstNode;
import com.demo.astengine.model.AstRelationship;
import com.demo.astengine.neo4j.GraphSchemaInitializer;
import com.demo.astengine.neo4j.Neo4jIngestionService;
import com.demo.astengine.parser.ProjectParser;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@SpringBootApplication
@Slf4j
public class AstEngineApplication implements CommandLineRunner {

    @Value("${ast-engine.source-path:../order-service/src/main/java}")
    private String sourcePath;

    @Value("${ast-engine.neo4j.uri:bolt://localhost:7687}")
    private String neo4jUri;

    @Value("${ast-engine.neo4j.user:neo4j}")
    private String neo4jUser;

    @Value("${ast-engine.neo4j.password:password}")
    private String neo4jPassword;

    public static void main(String[] args) {
        SpringApplication.run(AstEngineApplication.class, args);
    }

    @Bean
    public Driver neo4jDriver() {
        return GraphDatabase.driver(neo4jUri, AuthTokens.basic(neo4jUser, neo4jPassword));
    }

    @Override
    public void run(String... args) throws Exception {
        Path sourceDir = Paths.get(sourcePath).toAbsolutePath().normalize();
        log.info("=== AST Engine Starting ===");
        log.info("Source directory: {}", sourceDir);
        log.info("Neo4j URI: {}", neo4jUri);

        Driver driver = neo4jDriver();

        // Step 1: Initialize graph schema
        log.info("--- Step 1: Initializing Neo4j schema ---");
        GraphSchemaInitializer schemaInitializer = new GraphSchemaInitializer(driver);
        schemaInitializer.initializeSchema();

        // Step 2: Clear existing graph for clean re-ingestion
        log.info("--- Step 2: Clearing existing graph ---");
        Neo4jIngestionService ingestionService = new Neo4jIngestionService(driver);
        ingestionService.clearGraph();

        // Step 3: Parse source code
        log.info("--- Step 3: Parsing source code ---");
        ProjectParser parser = new ProjectParser(sourceDir);
        parser.parse();

        List<AstNode> nodes = parser.getNodes();
        List<AstRelationship> relationships = parser.getRelationships();

        log.info("Parsed {} nodes and {} relationships", nodes.size(), relationships.size());

        // Step 4: Ingest into Neo4j
        log.info("--- Step 4: Ingesting into Neo4j ---");
        ingestionService.ingestNodes(nodes);
        ingestionService.ingestRelationships(relationships);

        // Step 5: Print statistics
        log.info("--- Step 5: Statistics ---");
        log.info("Total nodes: {}", nodes.size());
        log.info("Total relationships: {}", relationships.size());

        log.info("=== AST Engine Complete ===");
        driver.close();
    }
}
