package com.demo.intelligence.engine;

import com.demo.intelligence.llm.ClaudeApiClient;
import com.demo.intelligence.llm.ResponseParser;
import com.demo.intelligence.model.CodeReviewResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
@Slf4j
public class CodeReviewEngine {

    private final ClaudeApiClient claudeApiClient;
    private final ResponseParser responseParser;
    private final RestTemplate restTemplate;

    @Value("${intelligence.graph-api-base-url:http://localhost:8081}")
    private String graphApiBaseUrl;

    public CodeReviewResult review(String className) {
        log.info("Running code review for {}", className);

        String contextJson = restTemplate.getForObject(
            graphApiBaseUrl + "/api/context/review/" + className, String.class);

        String response = claudeApiClient.sendMessage(
            ReviewPrompts.SYSTEM,
            ReviewPrompts.userPrompt(contextJson));

        return CodeReviewResult.builder()
            .className(className)
            .findings(responseParser.parseFindings(response))
            .rawResponse(response)
            .build();
    }
}
