package com.demo.intelligence.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DataLineageResult {
    private String entityName;
    private String question;
    private List<String> affectedSystems;
    private List<String> affectedServices;
    private String implementationPlan;
    private List<String> risks;
    private String rawResponse;
}
