package com.demo.intelligence.engine;

public final class ReviewPrompts {
    private ReviewPrompts() {}

    public static final String SYSTEM = "You are a senior Java architect performing a code review.";

    public static String userPrompt(String contextJson) {
        return """
            Using the AST-extracted architectural context below, identify:

            1. ARCHITECTURAL VIOLATIONS - layer breaches, missing patterns
            2. CROSS-CUTTING GAPS - missing @Transactional, unhandled exceptions, audit gaps
            3. STATE MANAGEMENT ISSUES - invalid transitions, missing guards
            4. DESIGN CONCERNS - god classes, tight coupling, missing abstractions
            5. SECURITY GAPS - unsecured endpoints, missing validation

            For each finding provide: severity (CRITICAL/HIGH/MEDIUM/LOW), the specific code location, why it's a problem, and a recommended fix.

            Format each finding as:
            ### SEVERITY
            - **Location** - Description

            Architectural Context:
            %s
            """.formatted(contextJson);
    }
}
