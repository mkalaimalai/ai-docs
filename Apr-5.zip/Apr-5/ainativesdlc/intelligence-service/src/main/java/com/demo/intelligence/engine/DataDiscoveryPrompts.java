package com.demo.intelligence.engine;

public final class DataDiscoveryPrompts {
    private DataDiscoveryPrompts() {}

    public static final String SYSTEM = "You are a data architect helping developers understand data lineage across systems.";

    public static String userPrompt(String question, String contextJson) {
        return """
            A developer wants to answer: "%s"

            Using the AST-extracted data lineage context below:
            1. Which downstream systems already have the relevant data? What specific fields?
            2. Which internal services would need changes?
            3. What's the recommended data flow - cache locally or fetch on demand?
            4. What entity/DTO changes are needed?
            5. What are the integration risks (data staleness, consistency, error handling)?
            6. Provide a concrete implementation plan with code-level specificity.

            Data Lineage Context:
            %s
            """.formatted(question, contextJson);
    }
}
