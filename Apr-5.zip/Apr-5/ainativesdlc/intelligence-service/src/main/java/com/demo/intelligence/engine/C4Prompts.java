package com.demo.intelligence.engine;

public final class C4Prompts {
    private C4Prompts() {}

    public static final String SYSTEM = "You are a software architect. Generate accurate C4 diagrams from structured AST context.";

    public static String userPrompt(String level, String contextJson) {
        return """
            Given this architectural context extracted from the codebase AST graph, generate:
            1. A C4 %s diagram in PlantUML format
            2. Use accurate names, relationships, and technologies from the context
            3. Include async flows (events) as dashed arrows
            4. Include external system integrations with correct names
            5. Use proper C4 PlantUML includes and syntax

            Context:
            %s
            """.formatted(level, contextJson);
    }
}
