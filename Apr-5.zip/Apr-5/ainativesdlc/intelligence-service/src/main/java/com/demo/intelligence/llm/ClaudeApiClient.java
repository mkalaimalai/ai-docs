package com.demo.intelligence.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class ClaudeApiClient {

    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    private static final String API_VERSION = "2023-06-01";

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Value("${intelligence.claude.api-key:}")
    private String apiKey;

    @Value("${intelligence.claude.model:claude-sonnet-4-20250514}")
    private String model;

    @Value("${intelligence.claude.max-tokens:4096}")
    private int maxTokens;

    @Value("${intelligence.claude.temperature:0.3}")
    private double temperature;

    public ClaudeApiClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        this.objectMapper = new ObjectMapper();
    }

    public String sendMessage(String systemPrompt, String userMessage) {
        if (apiKey == null || apiKey.isBlank()) {
            log.warn("ANTHROPIC_API_KEY not set. Returning mock response.");
            return getMockResponse(userMessage);
        }

        int retries = 3;
        int[] delays = {1000, 2000, 4000};

        for (int attempt = 0; attempt < retries; attempt++) {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.set("x-api-key", apiKey);
                headers.set("anthropic-version", API_VERSION);

                ObjectNode requestBody = objectMapper.createObjectNode();
                requestBody.put("model", model);
                requestBody.put("max_tokens", maxTokens);
                requestBody.put("temperature", temperature);

                if (systemPrompt != null && !systemPrompt.isBlank()) {
                    requestBody.put("system", systemPrompt);
                }

                ArrayNode messages = requestBody.putArray("messages");
                ObjectNode message = messages.addObject();
                message.put("role", "user");
                message.put("content", userMessage);

                HttpEntity<String> entity = new HttpEntity<>(
                    objectMapper.writeValueAsString(requestBody), headers);

                ResponseEntity<String> response = restTemplate.exchange(
                    API_URL, HttpMethod.POST, entity, String.class);

                JsonNode responseJson = objectMapper.readTree(response.getBody());
                JsonNode content = responseJson.get("content");
                if (content != null && content.isArray() && content.size() > 0) {
                    return content.get(0).get("text").asText();
                }
                return "No content in response";

            } catch (Exception e) {
                log.warn("Claude API attempt {} failed: {}", attempt + 1, e.getMessage());
                if (attempt < retries - 1) {
                    try {
                        Thread.sleep(delays[attempt]);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                } else {
                    log.error("Claude API failed after {} retries", retries, e);
                    return "Error: Unable to get response from Claude API after " + retries + " attempts. " + e.getMessage();
                }
            }
        }
        return "Error: Unexpected failure";
    }

    private String getMockResponse(String userMessage) {
        if (userMessage.contains("C4") || userMessage.contains("diagram")) {
            return "```plantuml\n@startuml C4_Context\n!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Context.puml\n\nSystem(orderService, \"Order Service\", \"Manages orders, payments, and customers\")\nSystem_Ext(paymentGateway, \"Payment Gateway\", \"Processes payments\")\nSystem_Ext(inventorySystem, \"Inventory System\", \"Manages stock\")\nSystem_Ext(crmSystem, \"CRM System\", \"Customer relationship management\")\n\nRel(orderService, paymentGateway, \"Processes payments\")\nRel(orderService, inventorySystem, \"Reserves stock\")\nRel(orderService, crmSystem, \"Enriches customer data\")\n@enduml\n```";
        }
        if (userMessage.contains("review") || userMessage.contains("Review")) {
            return "## Code Review Findings\n\n### CRITICAL\n1. **Missing @Transactional on updateOrderStatus()** - This method calls OrderRepository.save() without transaction management.\n\n### HIGH\n2. **No state transition validation** - updateOrderStatus() accepts any status transition.\n3. **Missing audit logging** - updateOrderStatus() doesn't call AuditService.\n4. **Unhandled CreditLimitExceededException** - Returns 500 instead of 422.\n\n### MEDIUM\n5. **@Async methods without error handling** - NotificationService methods have no try-catch.\n6. **Missing @PreAuthorize on getOrderSummary()** - Inconsistent with getRevenueByPeriod().\n7. **God class risk** - OrderService has 6 injected dependencies.";
        }
        if (userMessage.contains("test") || userMessage.contains("Test")) {
            return "```java\n@ExtendWith(MockitoExtension.class)\nclass OrderServiceTest {\n    @Mock private OrderRepository orderRepository;\n    @Mock private CustomerService customerService;\n    // ... 15 test methods covering happy path, exception paths, validation, state transitions\n}\n```";
        }
        return "Mock response for: " + userMessage.substring(0, Math.min(100, userMessage.length()));
    }
}
