package com.demo.intelligence.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class C4DiagramResult {
    private String diagramCode;
    private String level;
    @Builder.Default
    private LocalDateTime generatedAt = LocalDateTime.now();
}
