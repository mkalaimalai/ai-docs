package com.demo.intelligence.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GeneratedTest {
    private String testCode;
    private int testCount;
    private List<String> coverageAreas;
    private String className;
    private String methodName;
}
