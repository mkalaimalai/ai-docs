package com.demo.intelligence.llm;

import com.demo.intelligence.model.CodeReviewResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@Slf4j
public class ResponseParser {

    private static final Pattern CODE_BLOCK_PATTERN = Pattern.compile("```(\\w+)?\\n(.*?)```", Pattern.DOTALL);
    private static final Pattern FINDING_PATTERN = Pattern.compile("###\\s*(CRITICAL|HIGH|MEDIUM|LOW)\\n(.*?)(?=###|$)", Pattern.DOTALL);

    public String extractCodeBlock(String response, String language) {
        Matcher matcher = CODE_BLOCK_PATTERN.matcher(response);
        while (matcher.find()) {
            String lang = matcher.group(1);
            if (lang == null || lang.equalsIgnoreCase(language)) {
                return matcher.group(2).trim();
            }
        }
        return response;
    }

    public List<String> extractAllCodeBlocks(String response) {
        List<String> blocks = new ArrayList<>();
        Matcher matcher = CODE_BLOCK_PATTERN.matcher(response);
        while (matcher.find()) {
            blocks.add(matcher.group(2).trim());
        }
        return blocks;
    }

    public List<CodeReviewResult.Finding> parseFindings(String response) {
        List<CodeReviewResult.Finding> findings = new ArrayList<>();
        Matcher matcher = FINDING_PATTERN.matcher(response);
        int index = 1;

        while (matcher.find()) {
            String severity = matcher.group(1);
            String content = matcher.group(2).trim();

            String[] lines = content.split("\\n");
            for (String line : lines) {
                line = line.trim();
                if (line.startsWith("-") || line.matches("^\\d+\\..*")) {
                    line = line.replaceFirst("^[-\\d.]+\\s*", "").trim();
                    if (line.startsWith("**")) {
                        String[] parts = line.split("\\*\\*", 3);
                        String location = parts.length > 1 ? parts[1].trim() : "";
                        String description = parts.length > 2 ? parts[2].replaceFirst("^\\s*[-–]\\s*", "") : line;

                        findings.add(CodeReviewResult.Finding.builder()
                            .id(index++)
                            .severity(severity)
                            .category(categorize(description))
                            .location(location)
                            .description(description.trim())
                            .recommendation(extractRecommendation(description))
                            .build());
                    }
                }
            }
        }

        if (findings.isEmpty()) {
            findings.add(CodeReviewResult.Finding.builder()
                .id(1)
                .severity("INFO")
                .category("GENERAL")
                .location("N/A")
                .description(response.substring(0, Math.min(500, response.length())))
                .recommendation("Review the full analysis above.")
                .build());
        }

        return findings;
    }

    private String categorize(String description) {
        String lower = description.toLowerCase();
        if (lower.contains("transactional") || lower.contains("transaction")) return "CROSS_CUTTING_GAPS";
        if (lower.contains("state") || lower.contains("transition")) return "STATE_MANAGEMENT";
        if (lower.contains("security") || lower.contains("authorize") || lower.contains("preauthorize")) return "SECURITY_GAPS";
        if (lower.contains("god class") || lower.contains("dependency") || lower.contains("coupling")) return "DESIGN_CONCERNS";
        if (lower.contains("exception") || lower.contains("error handling")) return "CROSS_CUTTING_GAPS";
        if (lower.contains("audit")) return "CROSS_CUTTING_GAPS";
        if (lower.contains("layer") || lower.contains("violation")) return "ARCHITECTURAL_VIOLATIONS";
        return "GENERAL";
    }

    private String extractRecommendation(String description) {
        if (description.contains("Add @Transactional") || description.contains("@Transactional")) {
            return "Add @Transactional annotation to ensure database consistency.";
        }
        if (description.contains("state")) {
            return "Implement state machine validation before allowing transitions.";
        }
        if (description.contains("audit")) {
            return "Add AuditService.logAction() call for consistency.";
        }
        return "Review and address this finding.";
    }
}
