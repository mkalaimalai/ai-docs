package com.demo.intelligence.engine;

import com.demo.intelligence.llm.ClaudeApiClient;
import com.demo.intelligence.llm.ResponseParser;
import com.demo.intelligence.model.GeneratedTest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
@Slf4j
public class TestGenerationEngine {

    private final ClaudeApiClient claudeApiClient;
    private final ResponseParser responseParser;
    private final RestTemplate restTemplate;

    @Value("${intelligence.graph-api-base-url:http://localhost:8081}")
    private String graphApiBaseUrl;

    public GeneratedTest generate(String className, String methodName) {
        log.info("Generating tests for {}.{}", className, methodName);

        String contextJson = restTemplate.getForObject(
            graphApiBaseUrl + "/api/context/test/" + className + "/" + methodName, String.class);

        String response = claudeApiClient.sendMessage(
            TestPrompts.SYSTEM,
            TestPrompts.userPrompt(className, methodName, contextJson));

        String testCode = responseParser.extractCodeBlock(response, "java");
        int testCount = countTests(testCode);
        List<String> coverageAreas = extractCoverageAreas(testCode);

        return GeneratedTest.builder()
            .testCode(testCode)
            .testCount(testCount)
            .coverageAreas(coverageAreas)
            .className(className)
            .methodName(methodName)
            .build();
    }

    private int countTests(String testCode) {
        Pattern pattern = Pattern.compile("@Test|@ParameterizedTest");
        Matcher matcher = pattern.matcher(testCode);
        int count = 0;
        while (matcher.find()) count++;
        return Math.max(count, 1);
    }

    private List<String> extractCoverageAreas(String testCode) {
        List<String> areas = new java.util.ArrayList<>();
        if (testCode.contains("happy") || testCode.contains("success")) areas.add("Happy Path");
        if (testCode.contains("Exception") || testCode.contains("Throw")) areas.add("Exception Paths");
        if (testCode.contains("valid") || testCode.contains("Invalid")) areas.add("Validation");
        if (testCode.contains("state") || testCode.contains("Status")) areas.add("State Transitions");
        if (testCode.contains("event") || testCode.contains("publish")) areas.add("Event Publishing");
        if (testCode.contains("tier") || testCode.contains("GOLD") || testCode.contains("SILVER")) areas.add("Business Logic (Tiers)");
        if (areas.isEmpty()) areas.add("General");
        return areas;
    }
}
