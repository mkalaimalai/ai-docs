package com.demo.intelligence.engine;

public final class TestPrompts {
    private TestPrompts() {}

    public static final String SYSTEM = "You are a senior Java test engineer. Generate comprehensive JUnit 5 + Mockito tests.";

    public static String userPrompt(String className, String methodName, String contextJson) {
        return """
            Generate comprehensive JUnit 5 + Mockito functional tests for %s.%s().

            Using the AST-extracted context below:
            - Generate happy path test with all steps in the call chain verified
            - Generate one test PER exception path identified in the call chain
            - Generate boundary tests for each validation rule on the request DTO
            - Generate state transition verification test
            - Generate event publishing verification test
            - Generate tier-based business logic tests (one per tier)
            - Use realistic domain data (not "test123" or "foo/bar")
            - Verify mock interactions in call chain order
            - Use @DisplayName with descriptive test names

            Method Context:
            %s
            """.formatted(className, methodName, contextJson);
    }
}
