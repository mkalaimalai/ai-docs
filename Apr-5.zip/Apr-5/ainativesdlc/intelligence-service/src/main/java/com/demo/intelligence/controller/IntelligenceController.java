package com.demo.intelligence.controller;

import com.demo.intelligence.engine.*;
import com.demo.intelligence.model.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/intelligence")
@RequiredArgsConstructor
@Slf4j
public class IntelligenceController {

    private final C4DiagramEngine c4DiagramEngine;
    private final CodeReviewEngine codeReviewEngine;
    private final TestGenerationEngine testGenerationEngine;
    private final DomainDataEngine domainDataEngine;
    private final ComparisonEngine comparisonEngine;

    @PostMapping("/c4")
    public ResponseEntity<C4DiagramResult> generateC4Diagram(@RequestBody C4Request request) {
        log.info("POST /api/intelligence/c4 - level: {}", request.getLevel());
        return ResponseEntity.ok(c4DiagramEngine.generate(request.getLevel()));
    }

    @PostMapping("/review")
    public ResponseEntity<CodeReviewResult> reviewCode(@RequestBody ReviewRequest request) {
        log.info("POST /api/intelligence/review - class: {}", request.getClassName());
        return ResponseEntity.ok(codeReviewEngine.review(request.getClassName()));
    }

    @PostMapping("/tests")
    public ResponseEntity<GeneratedTest> generateTests(@RequestBody TestRequest request) {
        log.info("POST /api/intelligence/tests - {}.{}", request.getClassName(), request.getMethodName());
        return ResponseEntity.ok(testGenerationEngine.generate(request.getClassName(), request.getMethodName()));
    }

    @PostMapping("/data-lineage")
    public ResponseEntity<DataLineageResult> discoverData(@RequestBody DataRequest request) {
        log.info("POST /api/intelligence/data-lineage - entity: {}", request.getEntityName());
        return ResponseEntity.ok(domainDataEngine.discover(request.getEntityName(), request.getQuestion()));
    }

    @PostMapping("/compare")
    public ResponseEntity<ComparisonResult> compare(@RequestBody CompareRequest request) {
        log.info("POST /api/intelligence/compare - class: {}", request.getClassName());
        return ResponseEntity.ok(comparisonEngine.compare(request.getClassName(), request.getQuestion()));
    }
}
