package com.demo.intelligence.engine;

import com.demo.intelligence.llm.ClaudeApiClient;
import com.demo.intelligence.llm.ResponseParser;
import com.demo.intelligence.model.C4DiagramResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
@Slf4j
public class C4DiagramEngine {

    private final ClaudeApiClient claudeApiClient;
    private final ResponseParser responseParser;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${intelligence.graph-api-base-url:http://localhost:8081}")
    private String graphApiBaseUrl;

    public C4DiagramResult generate(String level) {
        log.info("Generating C4 {} diagram", level);

        String contextJson = restTemplate.getForObject(
            graphApiBaseUrl + "/api/context/c4", String.class);

        String response = claudeApiClient.sendMessage(
            C4Prompts.SYSTEM,
            C4Prompts.userPrompt(level, contextJson));

        String diagramCode = responseParser.extractCodeBlock(response, "plantuml");

        return C4DiagramResult.builder()
            .diagramCode(diagramCode)
            .level(level)
            .build();
    }
}
