package com.demo.intelligence.engine;

import com.demo.intelligence.llm.ClaudeApiClient;
import com.demo.intelligence.model.ComparisonResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
@Slf4j
public class ComparisonEngine {

    private final ClaudeApiClient claudeApiClient;
    private final RestTemplate restTemplate;

    @Value("${intelligence.graph-api-base-url:http://localhost:8081}")
    private String graphApiBaseUrl;

    public ComparisonResult compare(String className, String question) {
        log.info("Running comparison for {} - question: {}", className, question);

        // Fetch both contexts
        String rawCode = restTemplate.getForObject(
            graphApiBaseUrl + "/api/context/raw-code/" + className, String.class);
        String structuredContext = restTemplate.getForObject(
            graphApiBaseUrl + "/api/context/review/" + className, String.class);

        // Send both to Claude in parallel
        CompletableFuture<String> rawFuture = CompletableFuture.supplyAsync(() ->
            claudeApiClient.sendMessage(
                "You are a helpful assistant analyzing source code.",
                "Here is the source code for " + className + " and its dependencies:\n" +
                rawCode + "\n\nQuestion: " + question)
        );

        CompletableFuture<String> astFuture = CompletableFuture.supplyAsync(() ->
            claudeApiClient.sendMessage(
                "You are a helpful assistant analyzing code architecture using AST graph intelligence.",
                "Here is the architectural context for " + className + " extracted from our code intelligence graph:\n" +
                structuredContext + "\n\nQuestion: " + question)
        );

        String rawResponse = rawFuture.join();
        String astResponse = astFuture.join();

        return ComparisonResult.builder()
            .rawResponse(rawResponse)
            .astResponse(astResponse)
            .question(question)
            .className(className)
            .build();
    }
}
