package com.demo.intelligence.engine;

import com.demo.intelligence.llm.ClaudeApiClient;
import com.demo.intelligence.model.DataLineageResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
@Slf4j
public class DomainDataEngine {

    private final ClaudeApiClient claudeApiClient;
    private final RestTemplate restTemplate;

    @Value("${intelligence.graph-api-base-url:http://localhost:8081}")
    private String graphApiBaseUrl;

    public DataLineageResult discover(String entityName, String question) {
        log.info("Discovering data lineage for {} - question: {}", entityName, question);

        String contextJson = restTemplate.getForObject(
            graphApiBaseUrl + "/api/context/data-lineage/" + entityName, String.class);

        String response = claudeApiClient.sendMessage(
            DataDiscoveryPrompts.SYSTEM,
            DataDiscoveryPrompts.userPrompt(question, contextJson));

        return DataLineageResult.builder()
            .entityName(entityName)
            .question(question)
            .affectedSystems(extractListItems(response, "system"))
            .affectedServices(extractListItems(response, "service"))
            .implementationPlan(response)
            .risks(extractListItems(response, "risk"))
            .rawResponse(response)
            .build();
    }

    private List<String> extractListItems(String text, String keyword) {
        List<String> items = new ArrayList<>();
        Pattern pattern = Pattern.compile("(?i)" + keyword + ".*?:\\s*(.+?)(?:\\n|$)");
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) {
            items.add(matcher.group(1).trim());
        }
        if (items.isEmpty()) {
            items.add("See full analysis");
        }
        return items;
    }
}
