package com.demo.intelligence.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CodeReviewResult {
    private String className;
    private List<Finding> findings;
    private String rawResponse;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Finding {
        private int id;
        private String severity;
        private String category;
        private String location;
        private String description;
        private String recommendation;
    }
}
