# AST Intelligence Platform

## Project Structure
Maven multi-module monorepo with 4 Java modules + React UI.

## Build Commands
- Full build: `mvn compile`
- Single module: `mvn compile -pl order-service`
- Run order-service: `mvn spring-boot:run -pl order-service`
- Run graph-api: `mvn spring-boot:run -pl graph-api`
- Run intelligence-service: `mvn spring-boot:run -pl intelligence-service`
- Run ast-engine: `mvn spring-boot:run -pl ast-engine -Dspring-boot.run.arguments="--source=../order-service/src/main/java --neo4j-uri=bolt://localhost:7687 --neo4j-user=neo4j --neo4j-password=password"`
- Run React UI: `cd ui && npm start`

## Package Naming
- order-service: `com.demo.orderservice`
- ast-engine: `com.demo.astengine`
- graph-api: `com.demo.graphapi`
- intelligence-service: `com.demo.intelligence`

## Ports
- order-service: 8080
- graph-api: 8081
- intelligence-service: 8082
- React UI: 3000
- Neo4j browser: 7474
- Neo4j bolt: 7687

## Infrastructure
- `docker compose up -d` to start Neo4j
- Neo4j auth: neo4j/password

## Key Context
- The order-service has 7 **intentional bugs** planted for the code review demo (UC2). Do NOT fix them.
- The original detailed spec is in `AST-INTELLIGENCE-PLATFORM-PLAN.md`.
- The refined design is in `docs/superpowers/specs/2026-04-04-ast-intelligence-platform-design.md`.
