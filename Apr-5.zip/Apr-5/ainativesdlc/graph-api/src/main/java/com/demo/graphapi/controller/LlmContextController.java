package com.demo.graphapi.controller;

import com.demo.graphapi.model.C4ContextPayload;
import com.demo.graphapi.model.DataLineageContextPayload;
import com.demo.graphapi.model.ReviewContextPayload;
import com.demo.graphapi.model.TestContextPayload;
import com.demo.graphapi.service.ContextBuilderService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/context")
@RequiredArgsConstructor
public class LlmContextController {

    private final ContextBuilderService contextBuilderService;

    @GetMapping("/c4")
    public C4ContextPayload getC4Context() {
        return contextBuilderService.buildC4Context();
    }

    @GetMapping("/review/{className}")
    public ReviewContextPayload getReviewContext(@PathVariable String className) {
        return contextBuilderService.buildReviewContext(className);
    }

    @GetMapping("/test/{className}/{methodName}")
    public TestContextPayload getTestContext(@PathVariable String className, @PathVariable String methodName) {
        return contextBuilderService.buildTestContext(className, methodName);
    }

    @GetMapping("/data-lineage/{entityName}")
    public DataLineageContextPayload getDataLineageContext(@PathVariable String entityName) {
        return contextBuilderService.buildDataLineageContext(entityName);
    }

    @GetMapping("/raw-code/{className}")
    public String getRawCodeContext(@PathVariable String className) {
        return contextBuilderService.buildRawCodeContext(className);
    }
}
