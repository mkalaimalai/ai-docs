package com.demo.graphapi.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class C4ContextPayload {

    private SystemContext systemContext;
    private List<Container> containers;
    private List<ComponentInfo> components;
    private List<CallFlow> callGraph;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SystemContext {
        private String systemName;
        private List<ExternalSystemInfo> externalSystems;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ExternalSystemInfo {
        private String name;
        private String type;
        private List<String> integrationPoints;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Container {
        private String name;
        private String technology;
        private String description;
        private List<String> classes;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ComponentInfo {
        private String name;
        private String type;
        private List<String> annotations;
        private List<String> dependencies;
        private List<String> methods;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CallFlow {
        private String source;
        private String target;
        private String method;
        private String description;
    }
}
