package com.demo.graphapi.controller;

import com.demo.graphapi.model.ClassContext;
import com.demo.graphapi.model.ClassSummary;
import com.demo.graphapi.service.GraphQueryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/viz")
@RequiredArgsConstructor
public class VisualizationController {

    private final GraphQueryService graphQueryService;

    @GetMapping("/class/{name}")
    public Map<String, Object> getClassVisualization(@PathVariable String name) {
        ClassContext classContext = graphQueryService.getClassContext(name);

        List<Map<String, Object>> nodes = new ArrayList<>();
        List<Map<String, Object>> links = new ArrayList<>();

        Map<String, Object> classNode = new HashMap<>();
        classNode.put("id", classContext.getName());
        classNode.put("label", classContext.getName());
        classNode.put("type", "Class");
        nodes.add(classNode);

        if (classContext.getMethods() != null) {
            for (ClassContext.MethodInfo method : classContext.getMethods()) {
                String methodId = classContext.getName() + "." + method.getName();
                Map<String, Object> methodNode = new HashMap<>();
                methodNode.put("id", methodId);
                methodNode.put("label", method.getName());
                methodNode.put("type", "Method");
                methodNode.put("returnType", method.getReturnType());
                nodes.add(methodNode);

                Map<String, Object> link = new HashMap<>();
                link.put("source", classContext.getName());
                link.put("target", methodId);
                link.put("type", "HAS_METHOD");
                links.add(link);
            }
        }

        if (classContext.getFields() != null) {
            for (ClassContext.FieldInfo field : classContext.getFields()) {
                String fieldId = classContext.getName() + "." + field.getName();
                Map<String, Object> fieldNode = new HashMap<>();
                fieldNode.put("id", fieldId);
                fieldNode.put("label", field.getName());
                fieldNode.put("type", "Field");
                fieldNode.put("fieldType", field.getType());
                nodes.add(fieldNode);

                Map<String, Object> link = new HashMap<>();
                link.put("source", classContext.getName());
                link.put("target", fieldId);
                link.put("type", "HAS_FIELD");
                links.add(link);
            }
        }

        if (classContext.getDependencies() != null) {
            for (String dep : classContext.getDependencies()) {
                Map<String, Object> depNode = new HashMap<>();
                depNode.put("id", dep);
                depNode.put("label", dep);
                depNode.put("type", "Class");
                nodes.add(depNode);

                Map<String, Object> link = new HashMap<>();
                link.put("source", classContext.getName());
                link.put("target", dep);
                link.put("type", "DEPENDS_ON");
                links.add(link);
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("nodes", nodes);
        result.put("links", links);
        return result;
    }

    @GetMapping("/full-graph")
    public Map<String, Object> getFullGraph(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {

        List<ClassSummary> allClasses = graphQueryService.listAllClasses();

        int start = page * size;
        int end = Math.min(start + size, allClasses.size());

        List<ClassSummary> pageClasses = start < allClasses.size()
                ? allClasses.subList(start, end)
                : List.of();

        List<Map<String, Object>> nodes = new ArrayList<>();
        List<Map<String, Object>> links = new ArrayList<>();
        Set<String> addedNodes = new HashSet<>();

        for (ClassSummary cls : pageClasses) {
            Map<String, Object> node = new HashMap<>();
            node.put("id", cls.getName());
            node.put("label", cls.getName());
            node.put("type", cls.getType());
            node.put("annotations", cls.getAnnotations());
            nodes.add(node);
            addedNodes.add(cls.getName());
        }

        for (ClassSummary cls : pageClasses) {
            ClassContext ctx = graphQueryService.getClassContext(cls.getName());
            if (ctx.getDependencies() != null) {
                for (String dep : ctx.getDependencies()) {
                    if (!addedNodes.contains(dep)) {
                        Map<String, Object> depNode = new HashMap<>();
                        depNode.put("id", dep);
                        depNode.put("label", dep);
                        depNode.put("type", "Class");
                        nodes.add(depNode);
                        addedNodes.add(dep);
                    }

                    Map<String, Object> link = new HashMap<>();
                    link.put("source", cls.getName());
                    link.put("target", dep);
                    link.put("type", "DEPENDS_ON");
                    links.add(link);
                }
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("nodes", nodes);
        result.put("links", links);
        result.put("page", page);
        result.put("size", size);
        result.put("totalClasses", allClasses.size());
        result.put("totalPages", (int) Math.ceil((double) allClasses.size() / size));
        return result;
    }
}
