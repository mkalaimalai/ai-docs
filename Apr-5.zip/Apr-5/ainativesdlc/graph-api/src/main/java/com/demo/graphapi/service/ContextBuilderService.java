package com.demo.graphapi.service;

import com.demo.graphapi.model.C4ContextPayload;
import com.demo.graphapi.model.ClassContext;
import com.demo.graphapi.model.ClassSummary;
import com.demo.graphapi.model.CallChainResponse;
import com.demo.graphapi.model.DataLineageContextPayload;
import com.demo.graphapi.model.ReviewContextPayload;
import com.demo.graphapi.model.TestContextPayload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ContextBuilderService {

    private final GraphQueryService graphQueryService;

    public C4ContextPayload buildC4Context() {
        log.info("Building C4 context payload");

        List<Map<String, Object>> externalSystems = graphQueryService.getExternalSystems();
        List<ClassSummary> allClasses = graphQueryService.listAllClasses();

        List<C4ContextPayload.ExternalSystemInfo> extSysInfos = externalSystems.stream()
                .map(sys -> C4ContextPayload.ExternalSystemInfo.builder()
                        .name((String) sys.get("system"))
                        .type((String) sys.get("type"))
                        .integrationPoints(extractIntegrationPoints(sys))
                        .build())
                .collect(Collectors.toList());

        C4ContextPayload.SystemContext systemContext = C4ContextPayload.SystemContext.builder()
                .systemName("Application")
                .externalSystems(extSysInfos)
                .build();

        Map<String, List<ClassSummary>> classesByType = allClasses.stream()
                .collect(Collectors.groupingBy(ClassSummary::getType));

        List<C4ContextPayload.Container> containers = new ArrayList<>();
        containers.add(buildContainer("API Layer", "Spring MVC", "REST API controllers",
                classesByType.getOrDefault("Controller", Collections.emptyList())));
        containers.add(buildContainer("Service Layer", "Spring", "Business logic services",
                classesByType.getOrDefault("Service", Collections.emptyList())));
        containers.add(buildContainer("Data Layer", "Spring Data", "Data access repositories",
                classesByType.getOrDefault("Repository", Collections.emptyList())));
        containers.add(buildContainer("Domain Model", "JPA", "Domain entities",
                classesByType.getOrDefault("Entity", Collections.emptyList())));

        List<C4ContextPayload.ComponentInfo> components = allClasses.stream()
                .map(cls -> {
                    ClassContext ctx = graphQueryService.getClassContext(cls.getName());
                    return C4ContextPayload.ComponentInfo.builder()
                            .name(cls.getName())
                            .type(cls.getType())
                            .annotations(cls.getAnnotations())
                            .dependencies(ctx.getDependencies() != null ? ctx.getDependencies() : Collections.emptyList())
                            .methods(ctx.getMethods() != null
                                    ? ctx.getMethods().stream().map(ClassContext.MethodInfo::getName).collect(Collectors.toList())
                                    : Collections.emptyList())
                            .build();
                })
                .collect(Collectors.toList());

        List<C4ContextPayload.CallFlow> callGraph = new ArrayList<>();
        for (ClassSummary cls : allClasses) {
            ClassContext ctx = graphQueryService.getClassContext(cls.getName());
            if (ctx.getDependencies() != null) {
                for (String dep : ctx.getDependencies()) {
                    callGraph.add(C4ContextPayload.CallFlow.builder()
                            .source(cls.getName())
                            .target(dep)
                            .method("depends_on")
                            .description(cls.getName() + " depends on " + dep)
                            .build());
                }
            }
        }

        return C4ContextPayload.builder()
                .systemContext(systemContext)
                .containers(containers)
                .components(components)
                .callGraph(callGraph)
                .build();
    }

    public ReviewContextPayload buildReviewContext(String className) {
        log.info("Building review context for: {}", className);

        ClassContext classContext = graphQueryService.getClassContext(className);
        List<Map<String, String>> missingTransactional = graphQueryService.getMissingTransactional();
        List<Map<String, String>> layerViolations = graphQueryService.getLayerViolations();

        List<String> allMethods = classContext.getMethods() != null
                ? classContext.getMethods().stream().map(ClassContext.MethodInfo::getName).collect(Collectors.toList())
                : Collections.emptyList();

        List<String> methodsWithTransactional = classContext.getMethods() != null
                ? classContext.getMethods().stream()
                    .filter(m -> m.getAnnotations() != null && m.getAnnotations().contains("Transactional"))
                    .map(ClassContext.MethodInfo::getName)
                    .collect(Collectors.toList())
                : Collections.emptyList();

        List<String> methodsWithoutTransactional = allMethods.stream()
                .filter(m -> !methodsWithTransactional.contains(m))
                .collect(Collectors.toList());

        List<String> repoCallingWithout = missingTransactional.stream()
                .filter(v -> className.equals(v.get("className")))
                .map(v -> v.get("methodName"))
                .collect(Collectors.toList());

        ReviewContextPayload.TransactionManagement txMgmt = ReviewContextPayload.TransactionManagement.builder()
                .methodsWithTransactional(methodsWithTransactional)
                .methodsWithoutTransactional(methodsWithoutTransactional)
                .repositoryCallingMethodsWithoutTransactional(repoCallingWithout)
                .build();

        List<String> methodsWithAudit = classContext.getMethods() != null
                ? classContext.getMethods().stream()
                    .filter(m -> m.getName() != null && m.getName().toLowerCase().contains("audit"))
                    .map(ClassContext.MethodInfo::getName)
                    .collect(Collectors.toList())
                : Collections.emptyList();

        List<String> methodsWithoutAudit = allMethods.stream()
                .filter(m -> !methodsWithAudit.contains(m))
                .collect(Collectors.toList());

        ReviewContextPayload.AuditLogging auditLogging = ReviewContextPayload.AuditLogging.builder()
                .methodsWithAuditCall(methodsWithAudit)
                .methodsWithoutAuditCall(methodsWithoutAudit)
                .build();

        List<ReviewContextPayload.SecurityInfo> securityAnnotations = new ArrayList<>();
        if (classContext.getMethods() != null) {
            for (ClassContext.MethodInfo method : classContext.getMethods()) {
                if (method.getAnnotations() != null) {
                    for (String ann : method.getAnnotations()) {
                        if (ann.startsWith("Secured") || ann.startsWith("PreAuthorize") || ann.startsWith("RolesAllowed")) {
                            securityAnnotations.add(ReviewContextPayload.SecurityInfo.builder()
                                    .method(method.getName())
                                    .annotation(ann)
                                    .value(ann)
                                    .build());
                        }
                    }
                }
            }
        }

        int depCount = classContext.getDependencies() != null ? classContext.getDependencies().size() : 0;
        int methodCount = allMethods.size();
        String godClassRisk = methodCount > 20 ? "High" : methodCount > 10 ? "Medium" : "Low";

        ReviewContextPayload.ArchitecturalContext archContext = ReviewContextPayload.ArchitecturalContext.builder()
                .transactionManagement(txMgmt)
                .auditLogging(auditLogging)
                .stateTransitions(Collections.emptyList())
                .dependencyCount(depCount)
                .godClassRisk(godClassRisk)
                .securityAnnotations(securityAnnotations)
                .build();

        return ReviewContextPayload.builder()
                .classUnderReview(className)
                .architecturalContext(archContext)
                .build();
    }

    public TestContextPayload buildTestContext(String className, String methodName) {
        log.info("Building test context for: {}.{}", className, methodName);

        CallChainResponse callChain = graphQueryService.getCallChain(className, methodName);
        ClassContext classContext = graphQueryService.getClassContext(className);

        ClassContext.MethodInfo targetMethod = null;
        if (classContext.getMethods() != null) {
            targetMethod = classContext.getMethods().stream()
                    .filter(m -> methodName.equals(m.getName()))
                    .findFirst()
                    .orElse(null);
        }

        TestContextPayload.MethodUnderTest methodUnderTest = TestContextPayload.MethodUnderTest.builder()
                .className(className)
                .methodName(methodName)
                .returnType(targetMethod != null ? targetMethod.getReturnType() : "void")
                .parameters(targetMethod != null && targetMethod.getParameters() != null
                        ? targetMethod.getParameters().stream()
                            .map(p -> TestContextPayload.ParameterInfo.builder()
                                    .name(p)
                                    .type("Object")
                                    .validations(Collections.emptyList())
                                    .build())
                            .collect(Collectors.toList())
                        : Collections.emptyList())
                .annotations(targetMethod != null ? targetMethod.getAnnotations() : Collections.emptyList())
                .build();

        List<TestContextPayload.CallChainStep> chainSteps = new ArrayList<>();
        if (callChain.getSteps() != null) {
            int step = 1;
            for (CallChainResponse.CallStep cs : callChain.getSteps()) {
                chainSteps.add(TestContextPayload.CallChainStep.builder()
                        .step(step++)
                        .call(cs.getCallerClass() + "." + cs.getCallerMethod() + " -> " + cs.getCalledClass() + "." + cs.getCalledMethod())
                        .canThrow(cs.getCanThrow() != null && !cs.getCanThrow().isEmpty() ? cs.getCanThrow().get(0) : null)
                        .description(cs.getCallerMethod() + " calls " + cs.getCalledMethod())
                        .build());
            }
        }

        return TestContextPayload.builder()
                .methodUnderTest(methodUnderTest)
                .callChain(chainSteps)
                .validations(Collections.emptyList())
                .stateTransitions(Collections.emptyList())
                .build();
    }

    @SuppressWarnings("unchecked")
    public DataLineageContextPayload buildDataLineageContext(String entityName) {
        log.info("Building data lineage context for: {}", entityName);

        Map<String, Object> lineage = graphQueryService.getDataLineage(entityName);
        ClassContext classContext = graphQueryService.getClassContext(entityName);

        List<DataLineageContextPayload.EntityField> entityFields = classContext.getFields() != null
                ? classContext.getFields().stream()
                    .map(f -> DataLineageContextPayload.EntityField.builder()
                            .name(f.getName())
                            .type(f.getType())
                            .annotations(f.getAnnotations())
                            .build())
                    .collect(Collectors.toList())
                : Collections.emptyList();

        DataLineageContextPayload.EntityDefinition entityDef = DataLineageContextPayload.EntityDefinition.builder()
                .name(entityName)
                .fields(entityFields)
                .build();

        List<DataLineageContextPayload.DownstreamIntegration> downstreamIntegrations = new ArrayList<>();
        List<String> externalSources = (List<String>) lineage.getOrDefault("externalSources", Collections.emptyList());
        for (String source : externalSources) {
            downstreamIntegrations.add(DataLineageContextPayload.DownstreamIntegration.builder()
                    .system(source)
                    .client(source + "Client")
                    .methods(Collections.emptyList())
                    .dataFields(Collections.emptyList())
                    .build());
        }

        List<Map<String, Object>> usedIn = (List<Map<String, Object>>) lineage.getOrDefault("usedIn", Collections.emptyList());
        List<String> repositories = (List<String>) lineage.getOrDefault("repositories", Collections.emptyList());

        List<String> services = usedIn.stream()
                .map(m -> (String) m.get("class"))
                .filter(name -> name != null && !name.endsWith("Repository"))
                .distinct()
                .collect(Collectors.toList());

        DataLineageContextPayload.InternalUsage internalUsage = DataLineageContextPayload.InternalUsage.builder()
                .servicesUsingEntity(services)
                .repositoriesForEntity(repositories)
                .build();

        return DataLineageContextPayload.builder()
                .queryEntity(entityName)
                .entityDefinition(entityDef)
                .downstreamIntegrations(downstreamIntegrations)
                .internalUsage(internalUsage)
                .build();
    }

    public String buildRawCodeContext(String className) {
        log.info("Building raw code context for: {}", className);
        return graphQueryService.getRawSourceContext(className);
    }

    @SuppressWarnings("unchecked")
    private List<String> extractIntegrationPoints(Map<String, Object> sys) {
        List<Map<String, Object>> points = (List<Map<String, Object>>) sys.getOrDefault("integrationPoints", Collections.emptyList());
        return points.stream()
                .map(p -> p.get("class") + "." + p.get("method"))
                .collect(Collectors.toList());
    }

    private C4ContextPayload.Container buildContainer(String name, String technology, String description, List<ClassSummary> classes) {
        return C4ContextPayload.Container.builder()
                .name(name)
                .technology(technology)
                .description(description)
                .classes(classes.stream().map(ClassSummary::getName).collect(Collectors.toList()))
                .build();
    }
}
