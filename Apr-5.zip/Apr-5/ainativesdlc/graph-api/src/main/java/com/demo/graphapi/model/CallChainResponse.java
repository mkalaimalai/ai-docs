package com.demo.graphapi.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CallChainResponse {

    private String className;
    private String methodName;
    private List<CallStep> steps;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CallStep {
        private int stepNumber;
        private String callerClass;
        private String callerMethod;
        private String calledClass;
        private String calledMethod;
        private List<String> canThrow;
    }
}
