package com.demo.graphapi.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DataLineageContextPayload {

    private String queryEntity;
    private EntityDefinition entityDefinition;
    private List<DownstreamIntegration> downstreamIntegrations;
    private InternalUsage internalUsage;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EntityDefinition {
        private String name;
        private List<EntityField> fields;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EntityField {
        private String name;
        private String type;
        private List<String> annotations;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DownstreamIntegration {
        private String system;
        private String client;
        private List<String> methods;
        private List<String> dataFields;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class InternalUsage {
        private List<String> servicesUsingEntity;
        private List<String> repositoriesForEntity;
    }
}
