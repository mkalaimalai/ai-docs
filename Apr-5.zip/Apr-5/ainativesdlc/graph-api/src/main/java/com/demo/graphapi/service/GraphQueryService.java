package com.demo.graphapi.service;

import com.demo.graphapi.model.CallChainResponse;
import com.demo.graphapi.model.ClassContext;
import com.demo.graphapi.model.ClassSummary;
import com.demo.graphapi.model.ImpactAnalysisResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.Driver;
import org.neo4j.driver.Record;
import org.neo4j.driver.Session;
import org.neo4j.driver.Value;
import org.neo4j.driver.types.Node;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class GraphQueryService {

    private final Driver neo4jDriver;

    public ClassContext getClassContext(String className) {
        log.info("Fetching class context for: {}", className);
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (c:Class {name: $className}) " +
                    "OPTIONAL MATCH (c)-[:HAS_METHOD]->(m:Method) " +
                    "OPTIONAL MATCH (c)-[:HAS_FIELD]->(f:Field) " +
                    "OPTIONAL MATCH (c)-[:DEPENDS_ON]->(dep:Class) " +
                    "RETURN c, collect(DISTINCT m) as methods, collect(DISTINCT f) as fields, collect(DISTINCT dep.name) as deps",
                    Map.of("className", className)
            );

            if (!result.hasNext()) {
                log.warn("No class found with name: {}", className);
                return ClassContext.builder()
                        .name(className)
                        .methods(Collections.emptyList())
                        .fields(Collections.emptyList())
                        .dependencies(Collections.emptyList())
                        .annotations(Collections.emptyList())
                        .build();
            }

            Record record = result.next();
            Node classNode = record.get("c").asNode();

            List<ClassContext.MethodInfo> methods = record.get("methods").asList(val -> {
                Node m = val.asNode();
                return ClassContext.MethodInfo.builder()
                        .name(getStringProperty(m, "name"))
                        .returnType(getStringProperty(m, "returnType"))
                        .annotations(parseAnnotationsProperty(m.get("annotations")))
                        .parameters(parseAnnotationsProperty(m.get("parameters")))
                        .build();
            });

            List<ClassContext.FieldInfo> fields = record.get("fields").asList(val -> {
                Node f = val.asNode();
                return ClassContext.FieldInfo.builder()
                        .name(getStringProperty(f, "name"))
                        .type(getStringProperty(f, "type"))
                        .annotations(parseAnnotationsProperty(f.get("annotations")))
                        .build();
            });

            List<String> deps = record.get("deps").asList(Value::asString);

            return ClassContext.builder()
                    .name(getStringProperty(classNode, "name"))
                    .fqn(getStringProperty(classNode, "fqn"))
                    .annotations(parseAnnotationsProperty(classNode.get("annotations")))
                    .methods(methods)
                    .fields(fields)
                    .dependencies(deps)
                    .build();
        }
    }

    public CallChainResponse getCallChain(String className, String methodName) {
        log.info("Fetching call chain for: {}.{}", className, methodName);
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (c:Class {name: $className})-[:HAS_METHOD]->(m:Method {name: $methodName}) " +
                    "OPTIONAL MATCH path = (m)-[:CALLS*1..5]->(called:Method) " +
                    "OPTIONAL MATCH (called)<-[:HAS_METHOD]-(owner:Class) " +
                    "OPTIONAL MATCH (called)-[:THROWS]->(ex) " +
                    "RETURN m, called, owner, ex, length(path) as depth " +
                    "ORDER BY depth",
                    Map.of("className", className, "methodName", methodName)
            );

            List<CallChainResponse.CallStep> steps = new ArrayList<>();
            int stepNumber = 1;
            String previousCaller = className;
            String previousMethod = methodName;

            while (result.hasNext()) {
                Record record = result.next();
                Value calledVal = record.get("called");
                if (calledVal.isNull()) {
                    continue;
                }

                Node calledNode = calledVal.asNode();
                Value ownerVal = record.get("owner");
                String ownerName = ownerVal.isNull() ? "Unknown" : ownerVal.asNode().get("name").asString("Unknown");
                String calledMethodName = getStringProperty(calledNode, "name");

                List<String> canThrow = new ArrayList<>();
                Value exVal = record.get("ex");
                if (!exVal.isNull()) {
                    canThrow.add(exVal.asNode().get("name").asString("Exception"));
                }

                int depth = record.get("depth").asInt(0);

                steps.add(CallChainResponse.CallStep.builder()
                        .stepNumber(stepNumber++)
                        .callerClass(depth == 1 ? className : previousCaller)
                        .callerMethod(depth == 1 ? methodName : previousMethod)
                        .calledClass(ownerName)
                        .calledMethod(calledMethodName)
                        .canThrow(canThrow)
                        .build());

                previousCaller = ownerName;
                previousMethod = calledMethodName;
            }

            return CallChainResponse.builder()
                    .className(className)
                    .methodName(methodName)
                    .steps(steps)
                    .build();
        }
    }

    public ImpactAnalysisResponse getImpactAnalysis(String className) {
        log.info("Fetching impact analysis for: {}", className);
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (changed:Class {name: $className}) " +
                    "OPTIONAL MATCH (affected:Class)-[:DEPENDS_ON*1..3]->(changed) " +
                    "OPTIONAL MATCH (affected)-[:HAS_METHOD]->(m:Method)-[:CALLS]->(cm:Method)<-[:HAS_METHOD]-(changed) " +
                    "RETURN affected.name as name, " +
                    "  length(shortestPath((affected)-[:DEPENDS_ON*]->(changed))) as distance, " +
                    "  collect(DISTINCT m.name) as affectedMethods " +
                    "ORDER BY distance",
                    Map.of("className", className)
            );

            List<ImpactAnalysisResponse.AffectedClass> affectedClasses = new ArrayList<>();
            while (result.hasNext()) {
                Record record = result.next();
                Value nameVal = record.get("name");
                if (nameVal.isNull()) {
                    continue;
                }

                affectedClasses.add(ImpactAnalysisResponse.AffectedClass.builder()
                        .name(nameVal.asString())
                        .distance(record.get("distance").asInt(0))
                        .affectedMethods(record.get("affectedMethods").asList(Value::asString))
                        .build());
            }

            return ImpactAnalysisResponse.builder()
                    .className(className)
                    .affectedClasses(affectedClasses)
                    .build();
        }
    }

    public List<ClassSummary> listAllClasses() {
        log.info("Listing all classes");
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (c:Class) " +
                    "RETURN c.name as name, c.annotations as annotations " +
                    "ORDER BY c.name"
            );

            List<ClassSummary> classes = new ArrayList<>();
            while (result.hasNext()) {
                Record record = result.next();
                String name = record.get("name").asString();
                List<String> annotations = parseAnnotationsProperty(record.get("annotations"));
                String type = deriveTypeFromAnnotations(annotations);

                classes.add(ClassSummary.builder()
                        .name(name)
                        .type(type)
                        .annotations(annotations)
                        .build());
            }
            return classes;
        }
    }

    public List<String> getMethodsForClass(String className) {
        log.info("Fetching methods for class: {}", className);
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (c:Class {name: $className})-[:HAS_METHOD]->(m:Method) " +
                    "RETURN m.name ORDER BY m.name",
                    Map.of("className", className)
            );

            return result.list(record -> record.get("m.name").asString());
        }
    }

    public List<Map<String, Object>> getAnnotatedElements(String annotationName) {
        log.info("Fetching elements annotated with: {}", annotationName);
        try (Session session = neo4jDriver.session()) {
            // Search classes annotated with the given annotation
            var classResult = session.run(
                    "MATCH (c:Class) WHERE c.annotations CONTAINS $annotationName " +
                    "RETURN c.name as element, 'Class' as type, null as ownerClass",
                    Map.of("annotationName", annotationName)
            );

            List<Map<String, Object>> elements = new ArrayList<>();
            while (classResult.hasNext()) {
                Record record = classResult.next();
                Map<String, Object> element = new HashMap<>();
                element.put("element", record.get("element").asString());
                element.put("type", record.get("type").asString());
                element.put("ownerClass", null);
                elements.add(element);
            }

            // Search methods annotated with the given annotation
            var methodResult = session.run(
                    "MATCH (c:Class)-[:HAS_METHOD]->(m:Method) WHERE m.annotations CONTAINS $annotationName " +
                    "RETURN m.name as element, 'Method' as type, c.name as ownerClass",
                    Map.of("annotationName", annotationName)
            );

            while (methodResult.hasNext()) {
                Record record = methodResult.next();
                Map<String, Object> element = new HashMap<>();
                element.put("element", record.get("element").asString());
                element.put("type", record.get("type").asString());
                element.put("ownerClass", record.get("ownerClass").isNull() ? null : record.get("ownerClass").asString());
                elements.add(element);
            }

            return elements;
        }
    }

    public Map<String, Object> getDataLineage(String entityName) {
        log.info("Fetching data lineage for: {}", entityName);
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (e:Class {name: $entityName}) " +
                    "OPTIONAL MATCH (e)<-[:OF_TYPE]-(f:Field)<-[:HAS_FIELD]-(owner:Class) " +
                    "OPTIONAL MATCH (e)-[:SOURCED_FROM]->(ext:ExternalSystem) " +
                    "OPTIONAL MATCH (repo:Class)-[:HAS_METHOD]->(m:Method)-[:RETURNS]->(e) " +
                    "WHERE repo.name ENDS WITH 'Repository' " +
                    "RETURN e.name as name, " +
                    "  collect(DISTINCT ext.name) as externalSources, " +
                    "  collect(DISTINCT {class: owner.name, field: f.name}) as usedIn, " +
                    "  collect(DISTINCT repo.name) as repositories",
                    Map.of("entityName", entityName)
            );

            if (!result.hasNext()) {
                log.warn("No entity found with name: {}", entityName);
                return Map.of("name", entityName, "externalSources", List.of(), "usedIn", List.of(), "repositories", List.of());
            }

            Record record = result.next();
            Map<String, Object> lineage = new HashMap<>();
            lineage.put("name", record.get("name").asString());
            lineage.put("externalSources", record.get("externalSources").asList(Value::asString));
            lineage.put("usedIn", record.get("usedIn").asList(Value::asMap));
            lineage.put("repositories", record.get("repositories").asList(Value::asString));
            return lineage;
        }
    }

    public List<Map<String, String>> getMissingTransactional() {
        log.info("Fetching methods missing @Transactional");
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (c:Class)-[:HAS_METHOD]->(m:Method)-[:CALLS]->(rm:Method)<-[:HAS_METHOD]-(repo:Class) " +
                    "WHERE repo.name ENDS WITH 'Repository' " +
                    "AND NOT m.annotations CONTAINS 'Transactional' " +
                    "RETURN c.name as className, m.name as methodName, repo.name as repository"
            );

            List<Map<String, String>> violations = new ArrayList<>();
            while (result.hasNext()) {
                Record record = result.next();
                Map<String, String> violation = new HashMap<>();
                violation.put("className", record.get("className").asString());
                violation.put("methodName", record.get("methodName").asString());
                violation.put("repository", record.get("repository").asString());
                violations.add(violation);
            }
            return violations;
        }
    }

    public List<Map<String, String>> getLayerViolations() {
        log.info("Fetching layer violations");
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (ctrl:Class) WHERE ctrl.annotations CONTAINS 'RestController' " +
                    "MATCH (ctrl)-[:HAS_METHOD]->(m:Method)-[:CALLS]->(rm:Method)<-[:HAS_METHOD]-(repo:Class) " +
                    "WHERE repo.name ENDS WITH 'Repository' " +
                    "RETURN ctrl.name as controller, m.name as method, repo.name as repository"
            );

            List<Map<String, String>> violations = new ArrayList<>();
            while (result.hasNext()) {
                Record record = result.next();
                Map<String, String> violation = new HashMap<>();
                violation.put("controller", record.get("controller").asString());
                violation.put("method", record.get("method").asString());
                violation.put("repository", record.get("repository").asString());
                violations.add(violation);
            }
            return violations;
        }
    }

    public List<Map<String, Object>> getExternalSystems() {
        log.info("Fetching external systems");
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (c:Class)-[:INTEGRATES_WITH]->(ext:ExternalSystem) " +
                    "OPTIONAL MATCH (c)-[:HAS_METHOD]->(m:Method)-[:CALLS_EXTERNAL]->(ext) " +
                    "RETURN ext.name as system, ext.type as type, " +
                    "  collect(DISTINCT {class: c.name, method: m.name}) as integrationPoints"
            );

            List<Map<String, Object>> systems = new ArrayList<>();
            while (result.hasNext()) {
                Record record = result.next();
                Map<String, Object> system = new HashMap<>();
                system.put("system", record.get("system").asString());
                system.put("type", record.get("type").isNull() ? "Unknown" : record.get("type").asString());
                system.put("integrationPoints", record.get("integrationPoints").asList(Value::asMap));
                systems.add(system);
            }
            return systems;
        }
    }

    public String getRawSourceContext(String className) {
        log.info("Fetching raw source context for: {}", className);
        try (Session session = neo4jDriver.session()) {
            var result = session.run(
                    "MATCH (c:Class {name: $className}) " +
                    "OPTIONAL MATCH (c)-[:HAS_METHOD]->(m:Method) " +
                    "OPTIONAL MATCH (c)-[:HAS_FIELD]->(f:Field) " +
                    "RETURN c.name, c.fqn, " +
                    "  collect(DISTINCT {name: m.name, returnType: m.returnType, annotations: m.annotations}) as methods, " +
                    "  collect(DISTINCT {name: f.name, type: f.type}) as fields",
                    Map.of("className", className)
            );

            if (!result.hasNext()) {
                return "// Class not found: " + className;
            }

            Record record = result.next();
            String name = record.get("c.name").asString();
            String fqn = record.get("c.fqn").isNull() ? name : record.get("c.fqn").asString();

            StringBuilder sb = new StringBuilder();
            sb.append("// ").append(fqn).append("\n");
            sb.append("class ").append(name).append(" {\n\n");

            List<Map<String, Object>> fields = record.get("fields").asList(Value::asMap);
            for (Map<String, Object> field : fields) {
                Object fieldName = field.get("name");
                Object fieldType = field.get("type");
                if (fieldName != null) {
                    sb.append("  ").append(fieldType != null ? fieldType : "Object")
                      .append(" ").append(fieldName).append(";\n");
                }
            }

            if (!fields.isEmpty()) {
                sb.append("\n");
            }

            List<Map<String, Object>> methods = record.get("methods").asList(Value::asMap);
            for (Map<String, Object> method : methods) {
                Object methodName = method.get("name");
                Object returnType = method.get("returnType");
                if (methodName != null) {
                    sb.append("  ").append(returnType != null ? returnType : "void")
                      .append(" ").append(methodName).append("(...);\n");
                }
            }

            sb.append("}");
            return sb.toString();
        }
    }

    /**
     * Parse the annotations property string (e.g., "[Service, RequiredArgsConstructor]") into a list.
     */
    private List<String> parseAnnotationsProperty(Value val) {
        if (val == null || val.isNull()) {
            return Collections.emptyList();
        }
        String raw = val.asString();
        if (raw.isEmpty() || "[]".equals(raw)) {
            return Collections.emptyList();
        }
        // Remove surrounding brackets
        if (raw.startsWith("[") && raw.endsWith("]")) {
            raw = raw.substring(1, raw.length() - 1);
        }
        return List.of(raw.split(",\\s*"));
    }

    private String deriveTypeFromAnnotations(List<String> annotations) {
        if (annotations == null) {
            return "Unknown";
        }
        for (String annotation : annotations) {
            if ("RestController".equals(annotation) || "Controller".equals(annotation)) {
                return "Controller";
            }
            if ("Service".equals(annotation)) {
                return "Service";
            }
            if ("Repository".equals(annotation)) {
                return "Repository";
            }
            if ("Entity".equals(annotation)) {
                return "Entity";
            }
            if ("Configuration".equals(annotation)) {
                return "Config";
            }
        }
        return "Unknown";
    }

    private String getStringProperty(Node node, String key) {
        Value val = node.get(key);
        return val.isNull() ? null : val.asString();
    }

    private List<String> getListProperty(Node node, String key) {
        Value val = node.get(key);
        if (val.isNull()) {
            return Collections.emptyList();
        }
        try {
            return val.asList(Value::asString);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }
}
