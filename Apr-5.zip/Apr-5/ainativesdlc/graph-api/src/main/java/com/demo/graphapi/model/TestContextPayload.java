package com.demo.graphapi.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestContextPayload {

    private MethodUnderTest methodUnderTest;
    private List<CallChainStep> callChain;
    private List<ValidationInfo> validations;
    private List<String> stateTransitions;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MethodUnderTest {
        private String className;
        private String methodName;
        private String returnType;
        private List<ParameterInfo> parameters;
        private List<String> annotations;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ParameterInfo {
        private String name;
        private String type;
        private List<String> validations;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CallChainStep {
        private int step;
        private String call;
        private String canThrow;
        private String description;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ValidationInfo {
        private String field;
        private String constraint;
        private String message;
    }
}
