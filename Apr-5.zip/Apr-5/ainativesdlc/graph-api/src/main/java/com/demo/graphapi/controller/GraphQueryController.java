package com.demo.graphapi.controller;

import com.demo.graphapi.model.CallChainResponse;
import com.demo.graphapi.model.ClassContext;
import com.demo.graphapi.model.ClassSummary;
import com.demo.graphapi.model.ImpactAnalysisResponse;
import com.demo.graphapi.service.GraphQueryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/graph")
@RequiredArgsConstructor
public class GraphQueryController {

    private final GraphQueryService graphQueryService;

    @GetMapping("/class/{name}")
    public ClassContext getClassContext(@PathVariable String name) {
        return graphQueryService.getClassContext(name);
    }

    @GetMapping("/call-chain/{className}/{methodName}")
    public CallChainResponse getCallChain(@PathVariable String className, @PathVariable String methodName) {
        return graphQueryService.getCallChain(className, methodName);
    }

    @GetMapping("/impact/{className}")
    public ImpactAnalysisResponse getImpactAnalysis(@PathVariable String className) {
        return graphQueryService.getImpactAnalysis(className);
    }

    @GetMapping("/annotations/{annotationName}")
    public List<Map<String, Object>> getAnnotatedElements(@PathVariable String annotationName) {
        return graphQueryService.getAnnotatedElements(annotationName);
    }

    @GetMapping("/data-lineage/{entityName}")
    public Map<String, Object> getDataLineage(@PathVariable String entityName) {
        return graphQueryService.getDataLineage(entityName);
    }

    @GetMapping("/classes")
    public List<ClassSummary> listAllClasses() {
        return graphQueryService.listAllClasses();
    }

    @GetMapping("/class/{className}/methods")
    public List<String> getMethodsForClass(@PathVariable String className) {
        return graphQueryService.getMethodsForClass(className);
    }
}
