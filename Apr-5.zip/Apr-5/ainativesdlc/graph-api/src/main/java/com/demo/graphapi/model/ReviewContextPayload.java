package com.demo.graphapi.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReviewContextPayload {

    private String classUnderReview;
    private ArchitecturalContext architecturalContext;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ArchitecturalContext {
        private TransactionManagement transactionManagement;
        private AuditLogging auditLogging;
        private List<StateTransitionInfo> stateTransitions;
        private int dependencyCount;
        private String godClassRisk;
        private List<SecurityInfo> securityAnnotations;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TransactionManagement {
        private List<String> methodsWithTransactional;
        private List<String> methodsWithoutTransactional;
        private List<String> repositoryCallingMethodsWithoutTransactional;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AuditLogging {
        private List<String> methodsWithAuditCall;
        private List<String> methodsWithoutAuditCall;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class StateTransitionInfo {
        private String method;
        private String fromState;
        private String toState;
        private boolean hasValidation;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SecurityInfo {
        private String method;
        private String annotation;
        private String value;
    }
}
