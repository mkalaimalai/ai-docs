package com.demo.graphapi.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClassContext {

    private String name;
    private String fqn;
    private List<String> annotations;
    private List<MethodInfo> methods;
    private List<FieldInfo> fields;
    private List<String> dependencies;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MethodInfo {
        private String name;
        private String returnType;
        private List<String> annotations;
        private List<String> parameters;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FieldInfo {
        private String name;
        private String type;
        private List<String> annotations;
    }
}
