import React, { useState, useEffect } from 'react';
import { fetchClasses, discoverData } from '../api';
import LoadingSpinner from './LoadingSpinner';
import ErrorBanner from './ErrorBanner';

export default function DataDiscoveryPanel() {
  const [classes, setClasses] = useState([]);
  const [selectedEntity, setSelectedEntity] = useState('');
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchClasses().then(res => setClasses(res.data)).catch(() => {});
  }, []);

  const entities = classes.filter(c => c.type === 'Entity');

  const handleDiscover = async () => {
    if (!selectedEntity || !question) return;
    setLoading(true);
    setError(null);
    try {
      const res = await discoverData(selectedEntity, question);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>Domain Data Discovery</h2>
      <p style={{ color: '#666', marginBottom: '16px' }}>Find where data lives across systems using graph lineage</p>

      <div style={{ display: 'flex', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
        <select value={selectedEntity} onChange={e => setSelectedEntity(e.target.value)}
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db', minWidth: '200px' }}>
          <option value="">Select an entity...</option>
          {entities.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
        </select>
        <input value={question} onChange={e => setQuestion(e.target.value)}
          placeholder="e.g., Where is loyalty data?"
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db', flex: 1, minWidth: '300px' }}
        />
        <button onClick={handleDiscover} disabled={loading || !selectedEntity || !question}
          style={{ padding: '8px 20px', borderRadius: '6px', background: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer' }}>
          Discover
        </button>
      </div>

      <ErrorBanner error={error} onDismiss={() => setError(null)} />
      {loading && <LoadingSpinner message="Analyzing data lineage..." />}

      {result && (
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
            <div style={{ background: '#eff6ff', padding: '16px', borderRadius: '8px' }}>
              <h4 style={{ fontWeight: 'bold', marginBottom: '8px' }}>Affected Systems</h4>
              <ul>{result.affectedSystems?.map((s, i) => <li key={i}>{s}</li>)}</ul>
            </div>
            <div style={{ background: '#f0fdf4', padding: '16px', borderRadius: '8px' }}>
              <h4 style={{ fontWeight: 'bold', marginBottom: '8px' }}>Affected Services</h4>
              <ul>{result.affectedServices?.map((s, i) => <li key={i}>{s}</li>)}</ul>
            </div>
          </div>
          {result.risks && result.risks.length > 0 && (
            <div style={{ background: '#fef2f2', padding: '16px', borderRadius: '8px', marginBottom: '16px' }}>
              <h4 style={{ fontWeight: 'bold', marginBottom: '8px' }}>Risks</h4>
              <ul>{result.risks.map((r, i) => <li key={i}>{r}</li>)}</ul>
            </div>
          )}
          <details>
            <summary style={{ cursor: 'pointer', color: '#666' }}>Full Analysis</summary>
            <pre style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px', whiteSpace: 'pre-wrap', fontSize: '13px', marginTop: '8px' }}>
              {result.rawResponse}
            </pre>
          </details>
        </div>
      )}
    </div>
  );
}
