import React, { useState, useEffect } from 'react';
import { fetchClasses, runReview } from '../api';
import LoadingSpinner from './LoadingSpinner';
import ErrorBanner from './ErrorBanner';
import TreeView from './TreeView';

const severityColors = {
  CRITICAL: { bg: '#fef2f2', border: '#dc2626', text: '#dc2626', badge: '#dc2626' },
  HIGH: { bg: '#fff7ed', border: '#ea580c', text: '#ea580c', badge: '#ea580c' },
  MEDIUM: { bg: '#fefce8', border: '#ca8a04', text: '#ca8a04', badge: '#ca8a04' },
  LOW: { bg: '#eff6ff', border: '#2563eb', text: '#2563eb', badge: '#2563eb' },
  INFO: { bg: '#f0fdf4', border: '#16a34a', text: '#16a34a', badge: '#16a34a' },
};

export default function CodeReviewPanel() {
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchClasses().then(res => setClasses(res.data)).catch(() => {});
  }, []);

  const handleReview = async () => {
    if (!selectedClass) return;
    setLoading(true);
    setError(null);
    try {
      const res = await runReview(selectedClass);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>Code Review</h2>
      <p style={{ color: '#666', marginBottom: '16px' }}>Catch architectural violations using AST graph intelligence</p>

      <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
        <select value={selectedClass} onChange={e => setSelectedClass(e.target.value)}
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db', minWidth: '200px' }}>
          <option value="">Select a class...</option>
          {classes.map(c => <option key={c.name} value={c.name}>{c.name} ({c.type})</option>)}
        </select>
        <button onClick={handleReview} disabled={loading || !selectedClass}
          style={{ padding: '8px 20px', borderRadius: '6px', background: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer' }}>
          Run Review
        </button>
      </div>

      <ErrorBanner error={error} onDismiss={() => setError(null)} />
      {loading && <LoadingSpinner message="Running architectural review..." />}

      {result && result.findings && (
        <div>
          <h3 style={{ fontWeight: 'bold', marginBottom: '12px' }}>
            Findings ({result.findings.length})
          </h3>
          {result.findings.map((f, i) => {
            const colors = severityColors[f.severity] || severityColors.INFO;
            return (
              <div key={i} style={{ background: colors.bg, border: `1px solid ${colors.border}`, borderRadius: '8px', padding: '12px', marginBottom: '8px' }}>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '4px' }}>
                  <span style={{ background: colors.badge, color: 'white', padding: '2px 8px', borderRadius: '4px', fontSize: '12px', fontWeight: 'bold' }}>
                    {f.severity}
                  </span>
                  <span style={{ fontWeight: 'bold', color: colors.text }}>{f.category}</span>
                </div>
                <div style={{ fontWeight: '600', marginBottom: '4px' }}>{f.location}</div>
                <div>{f.description}</div>
                {f.recommendation && <div style={{ color: '#666', marginTop: '4px', fontStyle: 'italic' }}>Fix: {f.recommendation}</div>}
              </div>
            );
          })}
          <details style={{ marginTop: '16px' }}>
            <summary style={{ cursor: 'pointer', color: '#666' }}>Raw LLM Response</summary>
            <pre style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px', whiteSpace: 'pre-wrap', fontSize: '13px', marginTop: '8px' }}>
              {result.rawResponse}
            </pre>
          </details>
        </div>
      )}
    </div>
  );
}
