import React, { useState, useEffect } from 'react';
import { fetchClasses, runComparison } from '../api';
import LoadingSpinner from './LoadingSpinner';
import ErrorBanner from './ErrorBanner';

export default function ComparisonPanel() {
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchClasses().then(res => setClasses(res.data)).catch(() => {});
  }, []);

  const handleCompare = async () => {
    if (!selectedClass || !question) return;
    setLoading(true);
    setError(null);
    try {
      const res = await runComparison(selectedClass, question);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>Raw vs AST Comparison</h2>
      <p style={{ color: '#666', marginBottom: '16px' }}>Same LLM, same question - dramatically different quality</p>

      <div style={{ display: 'flex', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
        <select value={selectedClass} onChange={e => setSelectedClass(e.target.value)}
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db', minWidth: '200px' }}>
          <option value="">Select a class...</option>
          {classes.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
        </select>
        <input value={question} onChange={e => setQuestion(e.target.value)}
          placeholder="e.g., What happens when I POST /api/orders?"
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db', flex: 1, minWidth: '300px' }}
        />
        <button onClick={handleCompare} disabled={loading || !selectedClass || !question}
          style={{ padding: '8px 20px', borderRadius: '6px', background: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer' }}>
          Compare
        </button>
      </div>

      <ErrorBanner error={error} onDismiss={() => setError(null)} />
      {loading && <LoadingSpinner message="Running both analyses in parallel..." />}

      {result && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          <div style={{ border: '3px solid #dc2626', borderRadius: '8px', padding: '16px' }}>
            <h3 style={{ color: '#dc2626', fontWeight: 'bold', marginBottom: '12px', fontSize: '16px' }}>
              WITHOUT AST (Raw Code)
            </h3>
            <pre style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px', whiteSpace: 'pre-wrap', fontSize: '13px', maxHeight: '500px', overflow: 'auto' }}>
              {result.rawResponse}
            </pre>
          </div>
          <div style={{ border: '3px solid #16a34a', borderRadius: '8px', padding: '16px' }}>
            <h3 style={{ color: '#16a34a', fontWeight: 'bold', marginBottom: '12px', fontSize: '16px' }}>
              WITH AST (Graph Intelligence)
            </h3>
            <pre style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px', whiteSpace: 'pre-wrap', fontSize: '13px', maxHeight: '500px', overflow: 'auto' }}>
              {result.astResponse}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
