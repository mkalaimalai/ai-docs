import React from 'react';

export default function LoadingSpinner({ message = 'Processing...' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '20px', color: '#666' }}>
      <div style={{
        width: '24px', height: '24px', border: '3px solid #e5e7eb',
        borderTop: '3px solid #3b82f6', borderRadius: '50%',
        animation: 'spin 1s linear infinite',
      }} />
      <span>{message}</span>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
