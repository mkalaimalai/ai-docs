import React from 'react';

export default function ErrorBanner({ error, onDismiss }) {
  if (!error) return null;
  return (
    <div style={{
      background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '8px',
      padding: '12px 16px', marginBottom: '16px', display: 'flex',
      justifyContent: 'space-between', alignItems: 'center',
    }}>
      <span style={{ color: '#dc2626' }}>{error}</span>
      {onDismiss && (
        <button onClick={onDismiss} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#dc2626', fontSize: '18px' }}>
          x
        </button>
      )}
    </div>
  );
}
