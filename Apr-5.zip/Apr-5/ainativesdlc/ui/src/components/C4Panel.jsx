import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { generateC4 } from '../api';
import LoadingSpinner from './LoadingSpinner';
import ErrorBanner from './ErrorBanner';

export default function C4Panel() {
  const [level, setLevel] = useState('SYSTEM_CONTEXT');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await generateC4(level);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>C4 Architecture Diagrams</h2>
      <p style={{ color: '#666', marginBottom: '16px' }}>Generate accurate C4 diagrams from AST graph context</p>

      <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
        <select value={level} onChange={e => setLevel(e.target.value)}
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db' }}>
          <option value="SYSTEM_CONTEXT">System Context</option>
          <option value="CONTAINER">Container</option>
          <option value="COMPONENT">Component</option>
        </select>
        <button onClick={handleGenerate} disabled={loading}
          style={{ padding: '8px 20px', borderRadius: '6px', background: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer' }}>
          Generate
        </button>
      </div>

      <ErrorBanner error={error} onDismiss={() => setError(null)} />
      {loading && <LoadingSpinner message="Generating C4 diagram..." />}

      {result && (
        <div>
          <h3 style={{ fontWeight: 'bold', marginBottom: '8px' }}>PlantUML / Structurizr DSL</h3>
          <SyntaxHighlighter language="text" style={vscDarkPlus} customStyle={{ borderRadius: '8px' }}>
            {result.diagramCode}
          </SyntaxHighlighter>
        </div>
      )}
    </div>
  );
}
