import React, { useState } from 'react';

function TreeNode({ label, children, defaultOpen = false }) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const hasChildren = children && (Array.isArray(children) ? children.length > 0 : true);

  return (
    <div style={{ marginLeft: '16px' }}>
      <div
        onClick={() => hasChildren && setIsOpen(!isOpen)}
        style={{
          cursor: hasChildren ? 'pointer' : 'default',
          padding: '2px 0',
          fontFamily: 'monospace',
          fontSize: '13px',
        }}
      >
        {hasChildren ? (isOpen ? '▼ ' : '▶ ') : '  '}
        {label}
      </div>
      {isOpen && hasChildren && <div>{children}</div>}
    </div>
  );
}

export default function TreeView({ data, title }) {
  if (!data) return null;

  const renderValue = (key, value) => {
    if (value === null || value === undefined) return null;
    if (Array.isArray(value)) {
      if (value.length === 0) return <TreeNode key={key} label={`${key}: []`} />;
      return (
        <TreeNode key={key} label={`${key} (${value.length})`}>
          {value.map((item, i) => {
            if (typeof item === 'object') {
              return (
                <TreeNode key={i} label={`[${i}]`}>
                  {Object.entries(item).map(([k, v]) => renderValue(k, v))}
                </TreeNode>
              );
            }
            return <TreeNode key={i} label={String(item)} />;
          })}
        </TreeNode>
      );
    }
    if (typeof value === 'object') {
      return (
        <TreeNode key={key} label={key}>
          {Object.entries(value).map(([k, v]) => renderValue(k, v))}
        </TreeNode>
      );
    }
    return <TreeNode key={key} label={`${key}: ${String(value)}`} />;
  };

  return (
    <div style={{ background: '#1e1e1e', color: '#d4d4d4', padding: '12px', borderRadius: '8px', overflow: 'auto', maxHeight: '400px' }}>
      {title && <div style={{ fontWeight: 'bold', marginBottom: '8px', color: '#569cd6' }}>{title}</div>}
      {typeof data === 'object' ? (
        Object.entries(data).map(([k, v]) => renderValue(k, v))
      ) : (
        <pre>{String(data)}</pre>
      )}
    </div>
  );
}
