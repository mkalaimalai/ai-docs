import React, { useState, useEffect } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { fetchClasses, fetchMethods, generateTests } from '../api';
import LoadingSpinner from './LoadingSpinner';
import ErrorBanner from './ErrorBanner';

export default function TestGenPanel() {
  const [classes, setClasses] = useState([]);
  const [methods, setMethods] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchClasses().then(res => setClasses(res.data)).catch(() => {});
  }, []);

  useEffect(() => {
    if (selectedClass) {
      fetchMethods(selectedClass).then(res => setMethods(res.data)).catch(() => setMethods([]));
      setSelectedMethod('');
    }
  }, [selectedClass]);

  const handleGenerate = async () => {
    if (!selectedClass || !selectedMethod) return;
    setLoading(true);
    setError(null);
    try {
      const res = await generateTests(selectedClass, selectedMethod);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>Test Generation</h2>
      <p style={{ color: '#666', marginBottom: '16px' }}>Generate comprehensive tests from AST call chain analysis</p>

      <div style={{ display: 'flex', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
        <select value={selectedClass} onChange={e => setSelectedClass(e.target.value)}
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db', minWidth: '200px' }}>
          <option value="">Select a class...</option>
          {classes.filter(c => c.type === 'Service').map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
        </select>
        <select value={selectedMethod} onChange={e => setSelectedMethod(e.target.value)}
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db', minWidth: '200px' }}>
          <option value="">Select a method...</option>
          {methods.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
        <button onClick={handleGenerate} disabled={loading || !selectedClass || !selectedMethod}
          style={{ padding: '8px 20px', borderRadius: '6px', background: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer' }}>
          Generate Tests
        </button>
      </div>

      <ErrorBanner error={error} onDismiss={() => setError(null)} />
      {loading && <LoadingSpinner message="Generating tests (this may take a moment)..." />}

      {result && (
        <div>
          <div style={{ display: 'flex', gap: '16px', marginBottom: '16px', flexWrap: 'wrap' }}>
            <div style={{ background: '#eff6ff', padding: '8px 16px', borderRadius: '8px' }}>
              <strong>{result.testCount}</strong> tests generated
            </div>
            {result.coverageAreas && result.coverageAreas.map((area, i) => (
              <div key={i} style={{ background: '#f0fdf4', padding: '8px 16px', borderRadius: '8px' }}>
                {area}
              </div>
            ))}
          </div>
          <SyntaxHighlighter language="java" style={vscDarkPlus} customStyle={{ borderRadius: '8px' }}>
            {result.testCode}
          </SyntaxHighlighter>
        </div>
      )}
    </div>
  );
}
