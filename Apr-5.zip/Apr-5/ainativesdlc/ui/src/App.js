import React, { useState } from 'react';
import C4Panel from './components/C4Panel';
import CodeReviewPanel from './components/CodeReviewPanel';
import TestGenPanel from './components/TestGenPanel';
import DataDiscoveryPanel from './components/DataDiscoveryPanel';
import ComparisonPanel from './components/ComparisonPanel';

const tabs = [
  { id: 'c4', label: 'C4 Diagrams', component: C4Panel },
  { id: 'review', label: 'Code Review', component: CodeReviewPanel },
  { id: 'tests', label: 'Test Generation', component: TestGenPanel },
  { id: 'data', label: 'Data Discovery', component: DataDiscoveryPanel },
  { id: 'compare', label: 'Raw vs AST', component: ComparisonPanel },
];

function App() {
  const [activeTab, setActiveTab] = useState('c4');
  const ActiveComponent = tabs.find(t => t.id === activeTab)?.component;

  return (
    <div style={{ minHeight: '100vh', background: '#f9fafb' }}>
      <header style={{ background: '#1e293b', color: 'white', padding: '16px 24px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>
          AST Intelligence Platform
        </h1>
        <p style={{ color: '#94a3b8', margin: '4px 0 0', fontSize: '14px' }}>
          LLM Context Quality via AST Graph Intelligence
        </p>
      </header>

      <nav style={{ background: 'white', borderBottom: '1px solid #e5e7eb', display: 'flex', padding: '0 24px' }}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              padding: '12px 20px',
              border: 'none',
              background: 'none',
              cursor: 'pointer',
              borderBottom: activeTab === tab.id ? '3px solid #3b82f6' : '3px solid transparent',
              color: activeTab === tab.id ? '#3b82f6' : '#6b7280',
              fontWeight: activeTab === tab.id ? '600' : '400',
              fontSize: '14px',
            }}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      <main style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto' }}>
        {ActiveComponent && <ActiveComponent />}
      </main>
    </div>
  );
}

export default App;
