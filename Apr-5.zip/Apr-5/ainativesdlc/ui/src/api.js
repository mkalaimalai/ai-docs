import axios from 'axios';

const graphApi = axios.create({
  baseURL: 'http://localhost:8081',
  timeout: 30000,
});

const intelligenceApi = axios.create({
  baseURL: 'http://localhost:8082',
  timeout: 120000, // LLM calls can be slow
});

export const fetchClasses = () => graphApi.get('/api/graph/classes');
export const fetchMethods = (className) => graphApi.get(`/api/graph/class/${className}/methods`);
export const fetchClassContext = (className) => graphApi.get(`/api/graph/class/${className}`);
export const fetchVisualization = (className) => graphApi.get(`/api/viz/class/${className}`);

export const generateC4 = (level) => intelligenceApi.post('/api/intelligence/c4', { level });
export const runReview = (className) => intelligenceApi.post('/api/intelligence/review', { className });
export const generateTests = (className, methodName) => intelligenceApi.post('/api/intelligence/tests', { className, methodName });
export const discoverData = (entityName, question) => intelligenceApi.post('/api/intelligence/data-lineage', { entityName, question });
export const runComparison = (className, question) => intelligenceApi.post('/api/intelligence/compare', { className, question });
