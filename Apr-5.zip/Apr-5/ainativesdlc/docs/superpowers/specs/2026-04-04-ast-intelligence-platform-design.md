# AST-Powered Engineering Intelligence Platform — Refined Design

> Demonstrating LLM Context Quality Improvement via AST Graph Intelligence

## Context

Engineering teams feed raw source code to LLMs and get generic, surface-level output. This platform proves that structured AST graph context produces dramatically better results across 5 use cases: C4 diagrams, code review, test generation, domain data discovery, and a direct raw-vs-AST comparison. The audience is technical architects who care about accuracy and graph quality.

---

## Architecture

```
┌───────────────────────────────────────────────────────────┐
│  MONO-REPO (Maven multi-module)                           │
│                                                           │
│  Module 1: order-service        (Complex Spring Boot app) │
│  Module 2: ast-engine           (JavaParser + Neo4j)      │
│  Module 3: graph-api            (Query + Context Builder) │
│  Module 4: intelligence-service (5 Use Case Engines)      │
│                                                           │
│  Infrastructure: Neo4j (Docker), React UI                 │
└───────────────────────────────────────────────────────────┘
```

**Data Flow:** `Spring Boot App → JavaParser (AST) → Neo4j (Store) → Graph API (Query) → Intelligence Service (LLM) → React UI (Visualize + Compare)`

---

## Build Sequence with Verification Gates

### Phase 0: Scaffolding

**Deliverables:**
- Maven parent POM (Java 17, Spring Boot 3.2+, 4 modules)
- `docker-compose.yml` (Neo4j 5.x with APOC, ports 7474/7687)
- `CLAUDE.md` with project conventions
- `.gitignore` for Java/Maven/Node

**Verification:**
- `mvn validate` succeeds
- `docker compose up -d` starts Neo4j
- Neo4j browser accessible at http://localhost:7474

### Phase 1: order-service

All ~30 Java classes as specified in the original plan. A realistic order management microservice with:
- 4 controllers, 10 services, 5 repositories, 7 entities, 6 DTOs, 3 enums, 4 exceptions
- Spring events (OrderCreatedEvent, OrderCancelledEvent, PaymentCompletedEvent)
- External client integrations (PaymentGateway, InventorySystem, CRM)
- Security config, async config, cache config
- 7 intentional demo bugs (see Intentional Demo Bugs section)
- H2 in-memory database with seed data

**Verification:**
- `mvn compile -pl order-service` succeeds
- Application starts on port 8080
- H2 console accessible, seed data present

### Phase 2: ast-engine

JavaParser + JavaSymbolSolver parses Module 1's source and ingests AST into Neo4j.

**Key components:**
- `ProjectParser` — walks source directory, parses all .java files
- `ClassVisitor` / `MethodVisitor` / `AnnotationVisitor` — extract AST nodes
- `DependencyResolver` — resolves types and method calls via JavaSymbolSolver
- `CallGraphBuilder` — post-processing to build cross-class CALLS relationships
- `Neo4jIngestionService` — batch MERGE ingestion (500 ops/transaction)
- `GraphSchemaInitializer` — constraints and indexes

**Symbol resolution fallback:** If JavaSymbolSolver fails to resolve a method call, use heuristic matching: match `methodName` against known methods in parsed classes by name + parameter count. Log unresolved calls as warnings.

**Neo4j Graph Schema:**

Node types: Package, Class, Interface, Method, Field, Parameter, Annotation, Constructor, EnumConstant, Exception, ExternalSystem

Key relationships:
- `(:Class)-[:HAS_METHOD]->(:Method)`
- `(:Method)-[:CALLS]->(:Method)` (resolved via JavaSymbolSolver)
- `(:Method)-[:ANNOTATED_WITH]->(:Annotation)`
- `(:Method)-[:PUBLISHES]->(:Class)` (event publishing)
- `(:Method)-[:LISTENS_TO]->(:Class)` (@EventListener)
- `(:Class)-[:DEPENDS_ON]->(:Class)` (injection, field types)
- `(:Class)-[:INTEGRATES_WITH]->(:ExternalSystem)`

Full relationship list in original plan document.

**Verification:**
- Run against order-service source
- Neo4j browser shows: 30+ Class nodes, 100+ Method nodes
- CALLS relationships exist between OrderService methods and CustomerService/InventoryService/etc.
- ANNOTATED_WITH relationships on @Transactional methods
- Smoke test: parse a known file, assert expected node/relationship counts

### Phase 3: graph-api

Spring Boot service that queries Neo4j and serves structured context.

**Three controller groups:**
1. `GraphQueryController` — general graph queries (class context, call chains, impact analysis)
2. `VisualizationController` — tree-view compatible JSON for the UI
3. `LlmContextController` — structured context payloads for each use case

**Context builders (the core innovation):**
- `C4ContextPayload` — system context, containers, components, call graph
- `ReviewContextPayload` — transactional coverage, audit gaps, state transitions, dependency counts
- `TestContextPayload` — method signature, validations, full call chain with exceptions, state transitions
- `DataLineageContextPayload` — entity definition, downstream integrations, internal usage
- Raw code endpoint for UC5 comparison

**Key Cypher queries:** All queries from the original plan (full class context, endpoint-to-database trace, impact analysis, missing @Transactional detection, layer violation detection, domain data lineage).

**Verification:**
- `curl http://localhost:8081/api/context/c4` returns valid JSON with externalSystems
- `curl http://localhost:8081/api/context/review/OrderService` returns transactionManagement data
- Each `/api/context/*` endpoint returns expected JSON shape
- Integration test with embedded Neo4j verifies query shapes

### Phase 4: intelligence-service

5 use case engines + Claude API integration.

**Engines:**
1. `C4DiagramEngine` — generates PlantUML C4 diagrams at System Context/Container/Component levels
2. `CodeReviewEngine` — identifies architectural violations, cross-cutting gaps, state management issues
3. `TestGenerationEngine` — generates comprehensive JUnit 5 + Mockito tests
4. `DomainDataEngine` — discovers data across downstream systems
5. `ComparisonEngine` — sends same question with raw code vs. AST context, returns both responses

**Claude API client:**
- HTTP client calling Anthropic Messages API
- Model: `claude-sonnet-4-20250514` (configurable via application.yml)
- Retry with exponential backoff (3 retries, 1s/2s/4s delays)
- Configurable temperature and max_tokens per engine
- Graceful error responses (not 500s)

**Prompt templates:** All templates from the original plan, stored as dedicated template classes per engine.

**Verification:**
- `curl -X POST http://localhost:8082/api/intelligence/review -d '{"className":"OrderService"}'` returns findings
- UC5 comparison returns both raw and AST responses
- Each engine returns well-structured results

### Phase 5: React UI (Simplified)

5-tab interface with simplified visualization.

**Simplifications from original plan:**
- Collapsible tree views instead of D3 force-directed graphs
- PlantUML output as Structurizr DSL text in syntax-highlighted code blocks
- No PlantUML image rendering (architects can paste DSL into their own tools)
- Syntax-highlighted Java code for test generation
- Split-screen text comparison with color-coded borders for UC5

**Components:**
- `App.jsx` — 5-tab layout
- `C4Panel.jsx` — level selector + generate button + code block output + tree view of graph context
- `CodeReviewPanel.jsx` — class selector + findings list with severity badges + tree view
- `TestGenPanel.jsx` — class/method selectors + syntax-highlighted JUnit output + tree view of call chain
- `DataDiscoveryPanel.jsx` — entity selector + question input + structured analysis output + tree view
- `ComparisonPanel.jsx` — class selector + question input + split-screen text output

**Tech:** React, Tailwind CSS, Axios, react-syntax-highlighter

**Verification:**
- All 5 tabs render without errors
- Each tab produces meaningful output end-to-end
- UC5 split-screen clearly shows quality difference

---

## The Five Use Cases

| # | Use Case | What It Proves |
|---|----------|----------------|
| UC1 | **C4 Architecture Diagrams** | AST context produces accurate C4 from code, not from someone's memory |
| UC2 | **Code Review** | Catches architectural violations (missing @Transactional, layer breaches, state machine bugs) that raw code review misses |
| UC3 | **Test Generation** | 12-15 targeted tests vs. 2-3 generic tests from raw code |
| UC4 | **Domain Data Discovery** | Answers "where is this data?" in seconds using graph lineage |
| UC5 | **Raw vs AST Comparison** | Same LLM, same question, dramatically different quality — the proof point |

---

## Intentional Demo Bugs in order-service

These are deliberately planted for UC2 (Code Review) to discover:

1. `OrderService.updateOrderStatus()` — missing `@Transactional` but calls `OrderRepository.save()`
2. `OrderService.updateOrderStatus()` — accepts any state transition without validation
3. `OrderService.updateOrderStatus()` — does NOT call `AuditService.logAction()`
4. `GlobalExceptionHandler` — does NOT handle `CreditLimitExceededException` (returns 500)
5. `NotificationService` `@Async` methods — no error handling
6. `ReportController.getOrderSummary()` — missing `@PreAuthorize` (inconsistent with `getRevenueByPeriod`)
7. `OrderService` — 6 injected dependencies (borderline god class)

---

## Testing Strategy

- **order-service**: No tests (it's the demo target, not production code)
- **ast-engine**: Smoke tests — parse a known Java file, assert expected Class/Method/Field node counts and CALLS/ANNOTATED_WITH relationship counts
- **graph-api**: Integration tests with embedded Neo4j — verify each Cypher query returns expected JSON shape
- **intelligence-service**: No automated tests (LLM responses are non-deterministic). Manual verification via curl.
- **React UI**: Manual testing only

---

## Infrastructure

### docker-compose.yml
- Neo4j 5.x with APOC plugin
- Ports: 7474 (browser), 7687 (bolt)
- Volume mounts for data persistence
- `NEO4J_AUTH=neo4j/password`

### Maven Parent POM
- Java 17, Spring Boot 3.2+
- Modules: order-service, ast-engine, graph-api, intelligence-service
- Dependency management for Neo4j driver, JavaParser, etc.

### Module Ports
- order-service: 8080
- graph-api: 8081
- intelligence-service: 8082
- React UI: 3000
- Neo4j browser: 7474, bolt: 7687

---

## Module Details

All class-level specifications (controllers, services, repositories, entities, DTOs, enums, exceptions, events, external clients, config, mappers, validators) remain exactly as defined in the original plan document (`AST-INTELLIGENCE-PLATFORM-PLAN.md`). This refined design does not change any class definitions — it adds scaffolding, verification gates, resilience (symbol solver fallback), smoke tests, and simplifies the UI.

---

## Success Criteria

1. Neo4j graph accurately represents order-service architecture (30+ Class nodes, 100+ Method nodes, cross-class CALLS relationships)
2. C4 diagrams generated from AST context match actual code structure
3. Code review identifies all 7 intentional demo bugs
4. Generated tests cover 12-15 scenarios vs. 2-3 from raw code
5. Domain data discovery correctly traces data across downstream systems
6. UC5 split-screen makes the quality difference immediately obvious
