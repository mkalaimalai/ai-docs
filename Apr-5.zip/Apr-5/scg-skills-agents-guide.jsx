import { useState } from "react";

const COLORS = {
  bg: "#0D0D12",
  surface: "#16161F",
  surfaceHover: "#1E1E2A",
  border: "#2A2A3A",
  gold: "#D4A843",
  goldDim: "#8B7335",
  cyan: "#56C8D8",
  purple: "#9B7BFF",
  green: "#5AE0A0",
  red: "#E05A6D",
  orange: "#E0985A",
  pink: "#D47BC8",
  text: "#E8E4DC",
  textDim: "#8B8698",
  textMuted: "#5A5668",
};

const layers = [
  {
    id: "static",
    name: "Static Analysis Layer",
    icon: "🌳",
    color: COLORS.cyan,
    description: "Parses code into AST nodes and relationships — the skeleton of your codebase",
    tools: "Tree-sitter, Joern, CodeQL",
    nodes: ["Service", "Class", "Function", "Interface", "Endpoint", "DTO", "Module", "Component"],
    edges: ["CALLS", "IMPLEMENTS", "IMPORTS", "DEFINES", "EXTENDS", "PUBLISHES_EVENT", "CONSUMES_EVENT", "EXPOSES_API"],
    skills: [
      {
        name: "scg-static-indexer",
        type: "skill",
        description: "Parses repos using Tree-sitter, extracts AST nodes, builds initial graph",
        trigger: "When onboarding a new service or after major refactors",
        scripts: ["parse-repo.py (Tree-sitter AST extraction)", "build-graph.py (Neo4j node/edge creation)", "detect-patterns.py (DDD aggregate/entity detection)"],
      },
      {
        name: "cross-service-mapper",
        type: "skill",
        description: "Maps sync API calls (REST/gRPC) and async event flows (Kafka/RabbitMQ) across microservices",
        trigger: "When tracing a request flow or debugging integration issues",
        scripts: ["map-api-contracts.sh (OpenAPI/Proto parsing)", "map-event-schemas.sh (AsyncAPI/Avro schema extraction)", "build-service-mesh.py (Neo4j cross-service edges)"],
      },
    ],
    agents: [
      {
        name: "architecture-explorer",
        model: "sonnet",
        tools: "Read, Grep, Glob, Bash(cypher-shell *)",
        description: "Read-only agent that queries the SCG to answer architectural questions: 'What services depend on PaymentService?' 'Show me the event chain from OrderCreated'",
      },
    ],
    distributedContext: {
      microFrontend: "Parses React/Angular module federation boundaries, shared component imports, micro-app routing",
      backendService: "Extracts Spring Boot @RestController endpoints, gRPC service definitions, domain aggregates",
      asyncFlow: "Maps @KafkaListener / @EventHandler annotations to topics, builds PUBLISHES→TOPIC→CONSUMES chains",
      syncFlow: "Traces Feign/WebClient calls to downstream services, maps API gateway routes to backend endpoints",
    },
  },
  {
    id: "runtime",
    name: "Runtime Observability Layer",
    icon: "📡",
    color: COLORS.orange,
    description: "Captures actual runtime behavior — what the code REALLY does in production",
    tools: "OpenTelemetry, Jaeger, Prometheus",
    nodes: ["Trace", "Span", "Metric", "LogEntry", "RuntimeEndpoint"],
    edges: ["CALLS_AT_RUNTIME", "LATENCY_P99", "ERROR_RATE", "TRACES_TO", "TRIGGERED_BY"],
    skills: [
      {
        name: "scg-runtime-enricher",
        type: "skill",
        description: "Pulls OTel traces/metrics and enriches the static graph with actual runtime data",
        trigger: "Periodic enrichment or when debugging production issues",
        scripts: ["fetch-traces.py (Jaeger/Tempo API → trace data)", "enrich-graph.py (adds runtime edges to Neo4j)", "detect-hot-paths.py (identifies high-latency call chains)"],
      },
      {
        name: "distributed-trace-analyzer",
        type: "skill",
        description: "Follows a distributed trace across microservices, correlates with static graph to show code paths",
        trigger: "When debugging a production incident or performance issue",
        scripts: ["trace-to-code.py (maps trace spans → source functions)", "latency-breakdown.sh (P50/P95/P99 per span)", "error-chain.py (follows error propagation across services)"],
      },
    ],
    agents: [
      {
        name: "incident-debugger",
        model: "opus",
        tools: "Read, Bash(cypher-shell *), Bash(curl *), Grep",
        description: "Deep reasoning agent that correlates runtime traces with code structure. 'Why is checkout slow?' → queries traces → finds hot path → maps to code → suggests fix",
      },
    ],
    distributedContext: {
      microFrontend: "Captures browser performance metrics (LCP, FID), maps to micro-app bundles and shared dependencies",
      backendService: "Enriches service graph with actual call frequencies, latencies, error rates from OTel spans",
      asyncFlow: "Maps consumer lag, processing time per topic, dead letter queue rates to event-driven services",
      syncFlow: "Identifies circuit breaker trips, retry storms, timeout cascades across synchronous call chains",
    },
  },
  {
    id: "iac",
    name: "Infrastructure Layer",
    icon: "☁️",
    color: COLORS.green,
    description: "Parses IaC to understand deployment topology and infrastructure dependencies",
    tools: "Terraform/Helm/K8s manifest parsers",
    nodes: ["K8sDeployment", "K8sService", "IngressRoute", "ConfigMap", "Secret", "Queue", "Database", "Cache"],
    edges: ["DEPLOYED_ON", "ROUTES_TO", "CONNECTS_TO", "READS_FROM", "WRITES_TO", "PUBLISHES_TO", "SUBSCRIBES_FROM"],
    skills: [
      {
        name: "scg-infra-mapper",
        type: "skill",
        description: "Parses Terraform/Helm/K8s manifests to build infrastructure topology in the graph",
        trigger: "When onboarding infrastructure or after IaC changes",
        scripts: ["parse-terraform.py (HCL → Neo4j nodes)", "parse-k8s.py (K8s manifests → deployment topology)", "link-infra-to-code.py (maps K8s services → code services)"],
      },
    ],
    agents: [
      {
        name: "infra-impact-analyzer",
        model: "sonnet",
        tools: "Read, Bash(cypher-shell *), Bash(kubectl *), Grep, Glob",
        description: "Answers: 'If I scale down this pod, which services are affected?' 'What happens if Redis goes down?' by traversing infra→code→runtime graph",
      },
    ],
    distributedContext: {
      microFrontend: "Maps CDN config, nginx ingress routes, module federation remote entries to deployment units",
      backendService: "Links K8s deployments → services → ingress → API gateway → backend code endpoints",
      asyncFlow: "Maps Kafka cluster topology, topic partitioning, consumer group assignments to code consumers",
      syncFlow: "Maps service mesh (Istio/Linkerd) routes, load balancer config, circuit breaker policies",
    },
  },
  {
    id: "knowledge",
    name: "Organizational Knowledge Layer",
    icon: "🧠",
    color: COLORS.purple,
    description: "Captures human decisions, ADRs, Confluence docs, Slack conversations, team ownership",
    tools: "Confluence API, Slack API, ADR parsers",
    nodes: ["ADR", "ConfluencePage", "SlackThread", "Team", "Owner", "Decision", "Incident"],
    edges: ["DECIDED_BY", "OWNED_BY", "DOCUMENTED_IN", "DISCUSSED_IN", "CAUSED_BY", "RESOLVED_BY"],
    skills: [
      {
        name: "scg-knowledge-ingestor",
        type: "skill",
        description: "Indexes ADRs, Confluence pages, and Slack threads into the graph as decision/knowledge nodes",
        trigger: "Periodic sync or when researching why a decision was made",
        scripts: ["ingest-adrs.py (parses ADR markdown files)", "fetch-confluence.sh (Confluence REST API → pages)", "index-slack.py (Slack API → relevant threads)"],
      },
      {
        name: "decision-tracer",
        type: "skill",
        description: "Traces from code → ADR → Confluence → team, answering 'Why was this pattern chosen?'",
        trigger: "When understanding legacy decisions or evaluating change impact",
        scripts: ["trace-decision.py (code entity → linked ADR → rationale)", "find-owner.sh (code path → team ownership via CODEOWNERS + graph)"],
      },
    ],
    agents: [
      {
        name: "knowledge-researcher",
        model: "haiku",
        tools: "Read, Bash(cypher-shell *), Bash(curl *), Grep, Glob",
        description: "Fast, cheap agent for researching context: 'Who owns this service?' 'What ADR covers our auth pattern?' 'When was this decided and why?'",
      },
    ],
    distributedContext: {
      microFrontend: "Links design system decisions, component library ADRs, micro-app ownership to frontend teams",
      backendService: "Maps domain ownership (DDD bounded contexts), API versioning decisions, migration ADRs",
      asyncFlow: "Traces event schema evolution decisions, dead letter handling policies, idempotency patterns",
      syncFlow: "Documents circuit breaker thresholds, retry policies, timeout decisions per integration point",
    },
  },
];

const orchestratorAgent = {
  name: "scg-orchestrator",
  model: "opus",
  tools: "Read, Write, Edit, Bash, Glob, Grep",
  description: "The head chef. Receives complex queries, decomposes them across layers, delegates to specialist agents, synthesizes results. Example: 'What's the full impact of deprecating UserService v1?' → spawns architecture-explorer + infra-impact-analyzer + knowledge-researcher in parallel → merges findings → presents unified impact report.",
  delegationFlow: [
    { agent: "architecture-explorer", query: "Find all services calling UserService v1 API" },
    { agent: "incident-debugger", query: "Pull last 30 days of error rates for UserService v1 consumers" },
    { agent: "infra-impact-analyzer", query: "Which K8s deployments route to UserService v1?" },
    { agent: "knowledge-researcher", query: "Find ADRs and Confluence docs about UserService migration" },
  ],
};

const Badge = ({ text, color }) => (
  <span style={{
    display: "inline-block",
    fontSize: 9,
    fontWeight: 600,
    color,
    border: `1px solid ${color}44`,
    background: `${color}11`,
    padding: "2px 8px",
    borderRadius: 99,
    fontFamily: "'JetBrains Mono', monospace",
    letterSpacing: 0.3,
  }}>{text}</span>
);

const LayerCard = ({ layer, isOpen, onToggle }) => (
  <div style={{
    border: `1px solid ${isOpen ? layer.color : COLORS.border}`,
    borderRadius: 10,
    marginBottom: 10,
    background: isOpen ? `${layer.color}08` : COLORS.surface,
    transition: "all 0.2s",
  }}>
    <div onClick={onToggle} style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "14px 16px", cursor: "pointer",
    }}>
      <span style={{ fontSize: 22 }}>{layer.icon}</span>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: layer.color }}>{layer.name}</div>
        <div style={{ fontSize: 11, color: COLORS.textDim, marginTop: 2 }}>{layer.description}</div>
      </div>
      <span style={{ color: layer.color, transform: isOpen ? "rotate(180deg)" : "", transition: "0.2s" }}>▾</span>
    </div>

    {isOpen && (
      <div style={{ padding: "0 16px 16px" }}>
        {/* Tools */}
        <div style={{ display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 12 }}>
          <Badge text={layer.tools} color={layer.color} />
        </div>

        {/* Graph model */}
        <div style={{
          background: COLORS.bg, borderRadius: 8, padding: "10px 12px", marginBottom: 14,
          border: `1px solid ${COLORS.border}`,
        }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 6 }}>Graph Model</div>
          <div style={{ marginBottom: 6 }}>
            <span style={{ fontSize: 9, color: COLORS.textMuted }}>NODES: </span>
            <span style={{ fontSize: 10, color: COLORS.cyan, fontFamily: "'JetBrains Mono', monospace" }}>
              {layer.nodes.join(" · ")}
            </span>
          </div>
          <div>
            <span style={{ fontSize: 9, color: COLORS.textMuted }}>EDGES: </span>
            <span style={{ fontSize: 10, color: COLORS.gold, fontFamily: "'JetBrains Mono', monospace" }}>
              {layer.edges.join(" · ")}
            </span>
          </div>
        </div>

        {/* Skills */}
        <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gold, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8 }}>📖 Skills</div>
        {layer.skills.map((s, i) => (
          <div key={i} style={{
            background: COLORS.bg, borderRadius: 8, padding: "10px 12px", marginBottom: 8,
            borderLeft: `3px solid ${COLORS.gold}`,
          }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.text, fontFamily: "'JetBrains Mono', monospace" }}>{s.name}</div>
            <div style={{ fontSize: 11, color: COLORS.textDim, margin: "4px 0" }}>{s.description}</div>
            <div style={{ fontSize: 10, color: COLORS.goldDim, fontStyle: "italic", marginBottom: 6 }}>Triggers: {s.trigger}</div>
            <div style={{ fontSize: 9, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1, marginBottom: 4 }}>Bundled Scripts</div>
            {s.scripts.map((sc, j) => (
              <div key={j} style={{ fontSize: 10, color: COLORS.green, fontFamily: "'JetBrains Mono', monospace", padding: "1px 0" }}>
                → {sc}
              </div>
            ))}
          </div>
        ))}

        {/* Agents */}
        <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.purple, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8, marginTop: 12 }}>👨‍🍳 Sub-Agents</div>
        {layer.agents.map((a, i) => (
          <div key={i} style={{
            background: COLORS.bg, borderRadius: 8, padding: "10px 12px", marginBottom: 8,
            borderLeft: `3px solid ${COLORS.purple}`,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
              <span style={{ fontSize: 12, fontWeight: 700, color: COLORS.text, fontFamily: "'JetBrains Mono', monospace" }}>{a.name}</span>
              <Badge text={`model: ${a.model}`} color={COLORS.purple} />
            </div>
            <div style={{ fontSize: 11, color: COLORS.textDim, marginBottom: 4 }}>{a.description}</div>
            <div style={{ fontSize: 10, color: COLORS.textMuted, fontFamily: "'JetBrains Mono', monospace" }}>tools: {a.tools}</div>
          </div>
        ))}

        {/* Distributed context */}
        <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.cyan, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8, marginTop: 12 }}>🌐 Distributed Architecture Mapping</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
          {Object.entries(layer.distributedContext).map(([key, val]) => {
            const labels = { microFrontend: "Micro Frontend", backendService: "Backend Service", asyncFlow: "Async Flow", syncFlow: "Sync Flow" };
            const icons = { microFrontend: "🖥️", backendService: "⚙️", asyncFlow: "📨", syncFlow: "🔗" };
            const cols = { microFrontend: COLORS.cyan, backendService: COLORS.green, asyncFlow: COLORS.orange, syncFlow: COLORS.pink };
            return (
              <div key={key} style={{
                background: COLORS.bg, borderRadius: 6, padding: "8px 10px",
                border: `1px solid ${cols[key]}22`,
              }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: cols[key], marginBottom: 3 }}>
                  {icons[key]} {labels[key]}
                </div>
                <div style={{ fontSize: 10, color: COLORS.textDim, lineHeight: 1.5 }}>{val}</div>
              </div>
            );
          })}
        </div>
      </div>
    )}
  </div>
);

const OrchestratorView = () => (
  <div style={{ padding: "0 0 24px" }}>
    <div style={{
      background: `linear-gradient(135deg, ${COLORS.purple}22, ${COLORS.gold}11)`,
      border: `1px solid ${COLORS.purple}44`,
      borderRadius: 10, padding: 16, marginBottom: 16,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <span style={{ fontSize: 24 }}>🎭</span>
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.purple, fontFamily: "'JetBrains Mono', monospace" }}>{orchestratorAgent.name}</div>
          <div style={{ fontSize: 10, color: COLORS.textMuted }}>The Head Chef — Opus-powered orchestrator</div>
        </div>
      </div>
      <div style={{ fontSize: 12, color: COLORS.textDim, lineHeight: 1.6, marginBottom: 12 }}>{orchestratorAgent.description}</div>

      <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gold, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8 }}>
        Example: Parallel Delegation Flow
      </div>
      {orchestratorAgent.delegationFlow.map((d, i) => (
        <div key={i} style={{
          display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 6,
          background: COLORS.bg, borderRadius: 6, padding: "8px 10px",
        }}>
          <span style={{ fontSize: 10, color: COLORS.purple, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", whiteSpace: "nowrap" }}>
            @{d.agent}
          </span>
          <span style={{ fontSize: 10, color: COLORS.textDim }}>→ "{d.query}"</span>
        </div>
      ))}
    </div>

    {/* File structure */}
    <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gold, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8 }}>
      📁 Complete Plugin Structure
    </div>
    <pre style={{
      fontSize: 9.5, fontFamily: "'JetBrains Mono', monospace",
      background: COLORS.bg, color: COLORS.green, padding: 14,
      borderRadius: 8, border: `1px solid ${COLORS.border}`,
      overflow: "auto", lineHeight: 1.7,
    }}>{`scg-platform-plugin/
├── .claude-plugin/
│   └── plugin.json                    # Plugin manifest
│
├── skills/
│   ├── scg-static-indexer/
│   │   ├── SKILL.md                   # Tree-sitter parsing instructions
│   │   ├── scripts/
│   │   │   ├── parse-repo.py          # AST extraction (all languages)
│   │   │   ├── build-graph.py         # Neo4j node/edge creation
│   │   │   └── detect-patterns.py     # DDD aggregate detection
│   │   └── references/
│   │       ├── graph-schema.md        # Node/edge type definitions
│   │       └── language-support.md    # Per-language parsing rules
│   │
│   ├── cross-service-mapper/
│   │   ├── SKILL.md                   # Maps sync + async flows
│   │   └── scripts/
│   │       ├── map-api-contracts.sh   # OpenAPI/Proto → graph edges
│   │       ├── map-event-schemas.sh   # AsyncAPI/Avro → event chains
│   │       └── build-service-mesh.py  # Cross-service relationship builder
│   │
│   ├── scg-runtime-enricher/
│   │   ├── SKILL.md                   # OTel trace ingestion
│   │   └── scripts/
│   │       ├── fetch-traces.py        # Jaeger/Tempo API client
│   │       ├── enrich-graph.py        # Runtime edges → Neo4j
│   │       └── detect-hot-paths.py    # Latency analysis
│   │
│   ├── distributed-trace-analyzer/
│   │   ├── SKILL.md                   # Trace → code correlation
│   │   └── scripts/
│   │       ├── trace-to-code.py       # Span → source function mapping
│   │       └── error-chain.py         # Error propagation tracker
│   │
│   ├── scg-infra-mapper/
│   │   ├── SKILL.md                   # IaC → graph topology
│   │   └── scripts/
│   │       ├── parse-terraform.py     # HCL → Neo4j
│   │       ├── parse-k8s.py           # K8s manifests → topology
│   │       └── link-infra-to-code.py  # Infra ↔ code service linking
│   │
│   ├── scg-knowledge-ingestor/
│   │   ├── SKILL.md                   # ADR/Confluence/Slack indexing
│   │   └── scripts/
│   │       ├── ingest-adrs.py         # ADR markdown → graph
│   │       ├── fetch-confluence.sh    # Confluence REST API
│   │       └── index-slack.py         # Slack thread indexing
│   │
│   ├── decision-tracer/
│   │   ├── SKILL.md                   # Code → decision lineage
│   │   └── scripts/
│   │       ├── trace-decision.py      # Entity → ADR → rationale
│   │       └── find-owner.sh          # CODEOWNERS + graph lookup
│   │
│   └── scg-query/
│       ├── SKILL.md                   # General SCG query interface
│       └── references/
│           ├── cypher-patterns.md     # Common Cypher query templates
│           └── graph-schema.md        # Full schema reference
│
├── agents/
│   ├── scg-orchestrator/
│   │   └── AGENT.md                   # Opus — head chef / delegator
│   ├── architecture-explorer/
│   │   └── AGENT.md                   # Sonnet — read-only graph explorer
│   ├── incident-debugger/
│   │   └── AGENT.md                   # Opus — runtime + code correlator
│   ├── infra-impact-analyzer/
│   │   └── AGENT.md                   # Sonnet — infra dependency tracer
│   └── knowledge-researcher/
│       └── AGENT.md                   # Haiku — fast context lookup
│
└── hooks.json                         # Auto-index on git push, etc.`}</pre>

    {/* Sample SKILL.md */}
    <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.cyan, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8, marginTop: 16 }}>
      📝 Sample SKILL.md — cross-service-mapper
    </div>
    <pre style={{
      fontSize: 9.5, fontFamily: "'JetBrains Mono', monospace",
      background: COLORS.bg, color: COLORS.text, padding: 14,
      borderRadius: 8, border: `1px solid ${COLORS.border}`,
      overflow: "auto", lineHeight: 1.7,
    }}>{`---
name: cross-service-mapper
description: >
  Maps synchronous and asynchronous communication flows across
  microservices. Use when tracing request flows, debugging
  integration issues, onboarding new services, or understanding
  event-driven architectures. Handles REST, gRPC, Kafka,
  RabbitMQ, and SQS patterns.
allowed-tools: Bash(python *), Bash(cypher-shell *), Bash(curl *), Read, Glob, Grep
version: 1.0.0
---

# Cross-Service Communication Mapper

Maps sync (REST/gRPC) and async (Kafka/RabbitMQ/SQS) flows
across microservices into the Semantic Code Graph.

## Sync Flow Mapping
1. Find all OpenAPI specs: \`find . -name "openapi*.yaml"\`
2. Find Feign/WebClient calls: grep for @FeignClient, WebClient
3. Run: \`python scripts/map-api-contracts.sh <repo-root>\`
4. Verify edges: \`cypher-shell "MATCH (a)-[:CALLS_API]->(b) RETURN a.name, b.name"\`

## Async Flow Mapping
1. Find Kafka producers: grep for @KafkaTemplate, @SendTo
2. Find Kafka consumers: grep for @KafkaListener, @StreamListener
3. Run: \`python scripts/map-event-schemas.sh <repo-root>\`
4. Verify: \`cypher-shell "MATCH (a)-[:PUBLISHES]->(t:Topic)-[:CONSUMED_BY]->(b) RETURN *"\`

## Micro Frontend Mapping
1. Find Module Federation configs: webpack.config.js remotes/exposes
2. Find shared dependencies: grep for shared in federation config
3. Map component imports across micro-apps

## Output
Creates edges in Neo4j:
- Service -[:CALLS_API {method, path}]-> Service
- Service -[:PUBLISHES {schema}]-> Topic
- Topic -[:CONSUMED_BY {group}]-> Service
- MicroApp -[:IMPORTS_REMOTE {module}]-> MicroApp`}</pre>

    {/* Sample AGENT.md */}
    <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.purple, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8, marginTop: 16 }}>
      🤖 Sample AGENT.md — scg-orchestrator
    </div>
    <pre style={{
      fontSize: 9.5, fontFamily: "'JetBrains Mono', monospace",
      background: COLORS.bg, color: COLORS.text, padding: 14,
      borderRadius: 8, border: `1px solid ${COLORS.border}`,
      overflow: "auto", lineHeight: 1.7,
    }}>{`---
name: scg-orchestrator
description: >
  Orchestrates complex queries across the Semantic Code Graph.
  Use for impact analysis, architecture questions, incident
  debugging, or any query spanning multiple SCG layers
  (static, runtime, infra, knowledge). Delegates to specialist
  agents and synthesizes results.
model: opus
tools: Read, Write, Edit, Bash, Glob, Grep
skills:
  - scg-query
  - cross-service-mapper
  - distributed-trace-analyzer
  - decision-tracer
---

You are the SCG Orchestrator for a distributed architecture with:
- Micro frontends (React, Module Federation)
- Backend microservices (Spring Boot, DDD, Clean Architecture)
- Sync flows (REST/gRPC via API Gateway)
- Async flows (Kafka event-driven, CQRS, Saga patterns)
- Infrastructure (K8s, Terraform, Harness CI/CD)

## Your workflow:
1. DECOMPOSE the user's query into sub-queries per SCG layer
2. DELEGATE to specialist agents in parallel:
   - @architecture-explorer for static code structure
   - @incident-debugger for runtime behavior
   - @infra-impact-analyzer for infrastructure dependencies
   - @knowledge-researcher for ADRs, docs, ownership
3. SYNTHESIZE findings into a unified answer
4. VISUALIZE using ASCII diagrams showing service flows

## Neo4j access:
Query via: cypher-shell -u neo4j -p \$NEO4J_PASSWORD "QUERY"

## Key graph patterns:
- Full request trace: MATCH path=(gw:Gateway)-[:ROUTES*]->(svc) RETURN path
- Event chain: MATCH (s)-[:PUBLISHES]->(t:Topic)-[:CONSUMED_BY]->(c) RETURN *
- Impact radius: MATCH (s {name:$svc})<-[:CALLS*1..3]-(dep) RETURN dep
- Owner lookup: MATCH (s)-[:OWNED_BY]->(team) RETURN team`}</pre>
  </div>
);

const QueryExamples = () => {
  const examples = [
    {
      question: "What happens when a user clicks 'Place Order'?",
      icon: "🛒",
      color: COLORS.cyan,
      flow: [
        { agent: "architecture-explorer", action: "Traces: OrderButton (micro-frontend) → API Gateway → OrderService → PaymentService → InventoryService" },
        { agent: "cross-service-mapper", action: "Maps: OrderCreated event → Kafka → NotificationService, AnalyticsService, ShippingService" },
        { agent: "incident-debugger", action: "Shows: P95 latency per hop, error rates, recent failures" },
        { agent: "scg-orchestrator", action: "Synthesizes: Complete flow diagram with sync + async paths, latencies, and error points" },
      ],
    },
    {
      question: "What's the blast radius if PaymentService v2 has a breaking change?",
      icon: "💥",
      color: COLORS.red,
      flow: [
        { agent: "architecture-explorer", action: "Finds: 4 services with Feign clients calling PaymentService v2 endpoints" },
        { agent: "infra-impact-analyzer", action: "Shows: 3 K8s deployments, 2 ingress routes, 1 API gateway path affected" },
        { agent: "knowledge-researcher", action: "Finds: ADR-047 (payment API versioning), Confluence page on migration plan" },
        { agent: "scg-orchestrator", action: "Produces: Impact matrix with affected services, teams, infra, and recommended migration order" },
      ],
    },
    {
      question: "Why is the Dashboard micro-app loading slowly?",
      icon: "🐌",
      color: COLORS.orange,
      flow: [
        { agent: "architecture-explorer", action: "Maps: Dashboard imports 12 shared components from 3 remote micro-apps via Module Federation" },
        { agent: "incident-debugger", action: "Finds: SharedAnalytics remote has 2.1s load time, blocking LCP. ReportService P99 = 4.3s" },
        { agent: "infra-impact-analyzer", action: "Shows: CDN cache miss rate 40% for analytics bundle, ReportService pod at 92% memory" },
        { agent: "scg-orchestrator", action: "Root cause: Oversized analytics bundle + memory-starved backend. Recommends: lazy-load analytics, scale ReportService" },
      ],
    },
  ];

  return (
    <div>
      <div style={{ fontSize: 12, color: COLORS.textDim, marginBottom: 14, lineHeight: 1.6 }}>
        These show how the orchestrator decomposes real questions across all SCG layers:
      </div>
      {examples.map((ex, i) => (
        <div key={i} style={{
          background: COLORS.surface, borderRadius: 10, padding: 14,
          marginBottom: 12, border: `1px solid ${COLORS.border}`,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <span style={{ fontSize: 20 }}>{ex.icon}</span>
            <div style={{ fontSize: 13, fontWeight: 700, color: ex.color, lineHeight: 1.4 }}>
              "{ex.question}"
            </div>
          </div>
          {ex.flow.map((step, j) => (
            <div key={j} style={{
              display: "flex", gap: 8, marginBottom: 4, padding: "6px 8px",
              background: COLORS.bg, borderRadius: 6, alignItems: "flex-start",
            }}>
              <span style={{
                fontSize: 9, color: COLORS.purple, fontWeight: 700,
                fontFamily: "'JetBrains Mono', monospace",
                whiteSpace: "nowrap", marginTop: 1,
              }}>@{step.agent}</span>
              <span style={{ fontSize: 10, color: COLORS.textDim, lineHeight: 1.5 }}>{step.action}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default function App() {
  const [openLayer, setOpenLayer] = useState(null);
  const [tab, setTab] = useState("layers");

  const tabs = [
    { id: "layers", label: "🌳 SCG Layers", sub: "Skills + Agents" },
    { id: "orchestrator", label: "🎭 Orchestrator", sub: "Plugin structure" },
    { id: "queries", label: "❓ Live Queries", sub: "Real examples" },
  ];

  return (
    <div style={{ fontFamily: "'DM Sans', sans-serif", background: COLORS.bg, minHeight: "100vh", color: COLORS.text }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=JetBrains+Mono:wght@400;600;700&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet" />

      {/* Header */}
      <div style={{
        background: `linear-gradient(135deg, ${COLORS.purple}33 0%, ${COLORS.gold}22 50%, ${COLORS.cyan}22 100%)`,
        borderBottom: `1px solid ${COLORS.border}`,
        padding: "24px 18px 18px",
      }}>
        <div style={{ fontSize: 9, letterSpacing: 3, color: COLORS.gold, fontFamily: "'JetBrains Mono', monospace", textTransform: "uppercase" }}>
          Semantic Code Graph × Claude Code
        </div>
        <div style={{ fontSize: 24, fontWeight: 900, fontFamily: "'Playfair Display', serif", lineHeight: 1.15, marginTop: 4, color: COLORS.text }}>
          SCG Skills & Agents
        </div>
        <div style={{ fontSize: 11, color: COLORS.textDim, marginTop: 4, lineHeight: 1.5 }}>
          For distributed systems: micro-frontends, microservices, sync + async flows
        </div>
      </div>

      {/* Tabs */}
      <div style={{
        display: "flex", background: COLORS.surface,
        borderBottom: `1px solid ${COLORS.border}`,
        position: "sticky", top: 0, zIndex: 10,
      }}>
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex: 1, padding: "10px 6px 8px", border: "none", cursor: "pointer",
            borderBottom: tab === t.id ? `2px solid ${COLORS.gold}` : "2px solid transparent",
            background: tab === t.id ? COLORS.bg : "transparent",
            color: tab === t.id ? COLORS.gold : COLORS.textMuted,
            transition: "all 0.2s", textAlign: "center",
          }}>
            <div style={{ fontSize: 13 }}>{t.label}</div>
            <div style={{ fontSize: 8, color: COLORS.textMuted, fontFamily: "'JetBrains Mono', monospace" }}>{t.sub}</div>
          </button>
        ))}
      </div>

      <div style={{ padding: "14px 14px 40px" }}>
        {tab === "layers" && (
          <div>
            {/* Architecture overview */}
            <div style={{
              background: COLORS.surface, borderRadius: 10, padding: 14,
              border: `1px solid ${COLORS.border}`, marginBottom: 14,
            }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gold, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8 }}>
                How SCG + Claude Code Work Together
              </div>
              <div style={{ fontSize: 11, color: COLORS.textDim, lineHeight: 1.7 }}>
                Your SCG builds a unified graph in Neo4j from four data sources. Each source gets a <strong style={{ color: COLORS.gold }}>Skill</strong> (with bundled bash/python scripts) that indexes data into the graph, and a <strong style={{ color: COLORS.purple }}>Sub-Agent</strong> that queries the graph to answer questions. An <strong style={{ color: COLORS.text }}>Orchestrator agent</strong> coordinates them all for complex cross-cutting queries. No MCP needed — all graph access via <code style={{ color: COLORS.green, fontSize: 10 }}>cypher-shell</code> CLI.
              </div>
            </div>

            {/* Layer cards */}
            {layers.map((layer) => (
              <LayerCard
                key={layer.id}
                layer={layer}
                isOpen={openLayer === layer.id}
                onToggle={() => setOpenLayer(openLayer === layer.id ? null : layer.id)}
              />
            ))}
          </div>
        )}

        {tab === "orchestrator" && <OrchestratorView />}
        {tab === "queries" && <QueryExamples />}
      </div>
    </div>
  );
}
