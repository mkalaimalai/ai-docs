# AST-Powered Engineering Intelligence Platform

> **Implementation Plan for Claude Code**
> Demonstrating LLM Context Quality Improvement via AST Graph Intelligence

---

## Project Overview

Build a demo platform that proves: when you feed an LLM structured AST graph context instead of raw source code, the output quality improves dramatically across five engineering use cases — C4 diagrams, code review, test generation, domain data discovery, and a direct raw-vs-AST comparison.

**Leadership pitch:** "Our LLMs today see code as text files. When we give them architectural understanding through AST graphs, they produce architect-grade C4 diagrams, catch real bugs in code review, generate meaningful tests, and understand our data lineage across systems — without a human explaining context every time."

---

## Architecture

```
┌───────────────────────────────────────────────────────────┐
│  MONO-REPO (Maven multi-module)                           │
│                                                           │
│  Module 1: order-service        (Complex Spring Boot app) │
│  Module 2: ast-engine           (JavaParser + Neo4j)      │
│  Module 3: graph-api            (Query + Context Builder) │
│  Module 4: intelligence-service (5 Use Case Engines)      │
│                                                           │
│  Infrastructure: Neo4j (Docker), React UI                 │
└───────────────────────────────────────────────────────────┘
```

Data Flow: `Spring Boot App → JavaParser (AST) → Neo4j (Store) → Graph API (Query) → Intelligence Service (LLM) → React UI (Visualize + Compare)`

---

## The Five Use Cases

| # | Use Case | Value Proposition |
|---|----------|-------------------|
| UC1 | **C4 Architecture Diagrams** | Generate accurate C4 from code, not from someone's memory. Diagrams never go stale. |
| UC2 | **Code Review** | Catch architectural violations, not just lint errors. Missing @Transactional, layer breaches, state machine bugs. |
| UC3 | **Functional Test Generation** | Tests that understand the full call chain, every exception path, every validation rule. 3 generic tests become 15. |
| UC4 | **Domain Data Discovery** | What data exists in downstream systems for this entity? Answer in seconds, not days of Slack threads. |
| UC5 | **Raw vs AST Comparison** | Same LLM, same question, dramatically different quality. The proof point. |

---

## Build Sequence

| Day | Deliverable | Details |
|-----|-------------|---------|
| 1-2 | Order Service | All ~30 Java classes, realistic logic, compiles on H2 |
| 3-4 | AST Engine | JavaParser + JavaSymbolSolver, Neo4j Docker, verify in Browser |
| 5 | Graph API | All Cypher queries for 5 use cases, context builders, REST |
| 6-7 | Intelligence Service | 5 engines, prompt templates, Claude API, response parsing |
| 8-9 | React UI | 5-tab interface, D3 graph, PlantUML render, split-screen |
| 10 | Integration + Polish | End-to-end flow, error handling, demo rehearsal |

---

## Infrastructure

### docker-compose.yml

Create a Docker Compose file with:

- **Neo4j 5.x** with APOC plugin enabled
- Ports: 7474 (browser), 7687 (bolt)
- Volume mounts for data persistence
- Environment: `NEO4J_AUTH=neo4j/password`, `NEO4J_PLUGINS=["apoc"]`

### pom.xml (Parent)

Maven multi-module parent POM with:

- Java 17
- Spring Boot 3.2+ parent
- Modules: `order-service`, `ast-engine`, `graph-api`, `intelligence-service`
- Dependency management for shared versions (Neo4j driver, JavaParser, etc.)

---

## Module 1: order-service (Complex Spring Boot App)

A realistic order management microservice — NOT a hello-world. Leadership needs to see cross-class relationships, event flows, and cross-cutting concerns in the graph.

### Domain Model

```
Customer ──places──▶ Order ──contains──▶ OrderLineItem
                       │                       │
                       ▼                       ▼
                  Payment               Product (ref)
                       │
                       ▼
                  Notification
```

### Dependencies (pom.xml)

- Spring Boot Starter Web
- Spring Boot Starter Data JPA
- Spring Boot Starter Security
- Spring Boot Starter Validation
- Spring Cloud OpenFeign
- H2 Database (runtime)
- Lombok

### Package: `com.demo.orderservice`

#### Controllers

**OrderController.java** — `@RestController`, `@RequestMapping("/api/orders")`
- `POST /` — createOrder(@Valid @RequestBody CreateOrderRequest) → OrderResponse
- `GET /{id}` — getOrder(@PathVariable Long id) → OrderResponse
- `GET /` — searchOrders(@ModelAttribute OrderSearchCriteria) → Page<OrderResponse>
- `PUT /{id}/status` — updateOrderStatus(@PathVariable Long id, @RequestParam OrderStatus status) → OrderResponse
- `POST /bulk` — createBulkOrders(@Valid @RequestBody List<CreateOrderRequest>) → List<OrderResponse>
- `DELETE /{id}` — cancelOrder(@PathVariable Long id) → void
- Inject: OrderService, OrderMapper

**CustomerController.java** — `@RestController`, `@RequestMapping("/api/customers")`
- `GET /{id}` — getCustomer(@PathVariable Long id) → CustomerProfileResponse
- `GET /{id}/orders` — getCustomerOrders(@PathVariable Long id) → List<OrderResponse>
- `GET /{id}/history` — getCustomerHistory(@PathVariable Long id) → CustomerProfileResponse
- Inject: CustomerService, OrderService

**PaymentController.java** — `@RestController`, `@RequestMapping("/api/payments")`
- `POST /` — processPayment(@Valid @RequestBody PaymentRequest) → PaymentResponse
- `POST /{id}/refund` — refundPayment(@PathVariable Long id) → PaymentResponse
- `GET /order/{orderId}` — getPaymentsForOrder(@PathVariable Long orderId) → List<PaymentResponse>
- Inject: PaymentService

**ReportController.java** — `@RestController`, `@RequestMapping("/api/reports")`
- `GET /summary` — getOrderSummary(@RequestParam LocalDate from, @RequestParam LocalDate to) → OrderSummaryReport
- `GET /revenue` — getRevenueByPeriod(@RequestParam String period) → Map<String, BigDecimal>
- Inject: ReportingService
- Secured: `@PreAuthorize("hasRole('ADMIN')")`

#### Services

**OrderService.java** — `@Service`
- `@Transactional` createOrder(CreateOrderRequest request) → OrderResponse
  - Calls: CustomerService.getCustomer(), OrderValidationService.validateOrder(), InventoryService.validateAndReserveStock(), PricingService.calculateTotal(), OrderRepository.save(), ApplicationEventPublisher.publishEvent(new OrderCreatedEvent(order)), AuditService.logAction()
  - Throws: CustomerNotFoundException, InsufficientStockException, CreditLimitExceededException
  - State: null → OrderStatus.DRAFT
- `@Transactional` cancelOrder(Long orderId) → void
  - Calls: OrderRepository.findById(), validateCancellable(), OrderRepository.save(), eventPublisher.publishEvent(new OrderCancelledEvent()), AuditService.logAction()
  - Throws: OrderNotFoundException
  - State: * → OrderStatus.CANCELLED
- updateOrderStatus(Long orderId, OrderStatus newStatus) → OrderResponse
  - NOTE: Intentionally MISSING @Transactional (this is a demo bug for code review UC2 to catch)
  - NOTE: Intentionally NO state transition validation (another demo bug)
  - Calls: OrderRepository.findById(), OrderRepository.save()
  - Does NOT call AuditService (another demo gap for code review)
- getOrder(Long id) → OrderResponse
- searchOrders(OrderSearchCriteria criteria) → Page<OrderResponse>
- Inject: OrderRepository, CustomerService, OrderValidationService, InventoryService, PricingService, ApplicationEventPublisher, AuditService (6 dependencies — borderline god class risk)

**OrderValidationService.java** — `@Service`
- validateOrder(CreateOrderRequest request, Customer customer) → void
  - Validates: non-empty items, valid product IDs, positive quantities
  - Calls: CreditCheckValidator.validate()
  - Throws: IllegalArgumentException, CreditLimitExceededException

**PricingService.java** — `@Service`
- calculateTotal(List<OrderLineItem> items, CustomerTier tier) → BigDecimal
  - Business logic: base price × quantity, then apply tier discount (STANDARD=0%, SILVER=5%, GOLD=10%, PLATINUM=15%)
  - Also calculates tax (8.5%)
  - Also checks for promotional pricing

**PaymentService.java** — `@Service`
- `@Transactional` processPayment(PaymentRequest request) → PaymentResponse
  - Calls: OrderRepository.findById(), PaymentGatewayClient.charge(), PaymentRepository.save(), eventPublisher.publishEvent(new PaymentCompletedEvent())
  - State: Order CONFIRMED → PAID on success
  - Throws: PaymentDeclinedException, OrderNotFoundException
- `@Transactional` refundPayment(Long paymentId) → PaymentResponse
  - Calls: PaymentRepository.findById(), PaymentGatewayClient.refund(), PaymentRepository.save()
  - State: Payment CAPTURED → REFUNDED

**PaymentReconciliationService.java** — `@Service`
- `@Scheduled(cron = "0 0 2 * * *")` reconcilePendingPayments() → void
  - Calls: PaymentRepository.findByStatus(PENDING), PaymentGatewayClient.checkStatus(), PaymentRepository.save()
  - Batch job: checks all PENDING payments against gateway

**NotificationService.java** — `@Service`
- `@Async` sendOrderConfirmation(Order order) → void
  - Sends email notification (simulated)
- `@Async` sendPaymentReceipt(Payment payment) → void
- NOTE: @Async methods intentionally have no error handling (demo bug for UC2)

**InventoryService.java** — `@Service`
- validateAndReserveStock(List<OrderLineItem> items) → void
  - Calls: InventorySystemClient.checkAvailability(), InventorySystemClient.reserve()
  - Throws: InsufficientStockException
- releaseReservation(List<OrderLineItem> items) → void

**CustomerService.java** — `@Service`
- getCustomer(Long customerId) → Customer
  - Calls: CustomerRepository.findById(), CrmClient.getCustomerProfile() (enriches with CRM data)
  - Throws: CustomerNotFoundException
- `@Cacheable("customers")` getCustomerProfile(Long customerId) → CustomerProfileResponse

**AuditService.java** — `@Service`
- logAction(String action, String entityType, Long entityId, String actor) → void
  - Calls: AuditLogRepository.save()

**ReportingService.java** — `@Service`
- getOrderSummary(LocalDate from, LocalDate to) → OrderSummaryReport
  - Calls: OrderRepository.countByStatusAndDateRange(), OrderRepository.sumRevenueByDateRange()
- getRevenueByPeriod(String period) → Map<String, BigDecimal>

#### Repositories

**OrderRepository.java** — extends `JpaRepository<Order, Long>`
- `@Query("SELECT o FROM Order o WHERE o.customer.id = :customerId")` findByCustomerId(Long customerId) → List<Order>
- `@Query("SELECT o FROM Order o WHERE o.status = :status AND o.createdAt BETWEEN :from AND :to")` findByStatusAndDateRange(OrderStatus status, LocalDate from, LocalDate to) → List<Order>
- findByStatus(OrderStatus status) → List<Order>
- `@Query` countByStatusAndDateRange() → Map<OrderStatus, Long>
- `@Query` sumRevenueByDateRange() → BigDecimal

**CustomerRepository.java** — extends `JpaRepository<Customer, Long>`
- findByEmail(String email) → Optional<Customer>
- findByTier(CustomerTier tier) → List<Customer>

**PaymentRepository.java** — extends `JpaRepository<Payment, Long>`
- findByOrderId(Long orderId) → List<Payment>
- findByStatus(PaymentStatus status) → List<Payment>
- `@Query(nativeQuery = true)` findPendingOlderThan(LocalDateTime cutoff) → List<Payment>

**OrderLineItemRepository.java** — extends `JpaRepository<OrderLineItem, Long>`

**AuditLogRepository.java** — extends `JpaRepository<AuditLog, Long>`
- findByEntityTypeAndEntityId(String entityType, Long entityId) → List<AuditLog>

#### Entities

**Order.java** — `@Entity`, `@Table(name = "orders")`
- `@Id @GeneratedValue` Long id
- `@ManyToOne @JoinColumn(name = "customer_id")` Customer customer
- `@OneToMany(mappedBy = "order", cascade = CascadeType.ALL)` List<OrderLineItem> items
- `@Enumerated(EnumType.STRING)` OrderStatus status
- BigDecimal totalAmount
- BigDecimal taxAmount
- BigDecimal discountAmount
- LocalDateTime createdAt
- LocalDateTime updatedAt
- String notes

**OrderLineItem.java** — `@Entity`
- `@Id @GeneratedValue` Long id
- `@ManyToOne @JoinColumn(name = "order_id")` Order order
- `@ManyToOne @JoinColumn(name = "product_id")` Product product
- Integer quantity
- BigDecimal unitPrice
- BigDecimal lineTotal

**Customer.java** — `@Entity`
- `@Id @GeneratedValue` Long id
- `@Column(unique = true)` String email
- String firstName, lastName
- `@Enumerated(EnumType.STRING)` CustomerTier tier
- BigDecimal creditLimit
- `@Embedded` Address address
- LocalDateTime createdAt

**Payment.java** — `@Entity`
- `@Id @GeneratedValue` Long id
- `@ManyToOne` Order order
- BigDecimal amount
- `@Enumerated(EnumType.STRING)` PaymentStatus status
- String gatewayReference
- String paymentMethod
- LocalDateTime processedAt

**Product.java** — `@Entity`
- `@Id @GeneratedValue` Long id
- String name, description, category
- BigDecimal basePrice
- Integer stockQuantity
- Boolean active

**AuditLog.java** — `@Entity`
- `@Id @GeneratedValue` Long id
- String action
- String entityType
- Long entityId
- String actor
- LocalDateTime timestamp
- String details

**Address.java** — `@Embeddable`
- String street, city, state, zipCode, country

#### DTOs

**CreateOrderRequest.java**
- `@NotNull` Long customerId
- `@NotEmpty @Valid` List<OrderItemRequest> items
- String notes
- Inner class OrderItemRequest:
  - `@NotNull` Long productId
  - `@Min(1) @Max(999)` Integer quantity

**OrderResponse.java**
- Long id, Long customerId, String customerName
- List<OrderItemResponse> items
- OrderStatus status, BigDecimal totalAmount, BigDecimal taxAmount, BigDecimal discountAmount
- LocalDateTime createdAt, updatedAt

**OrderSearchCriteria.java**
- Long customerId, OrderStatus status
- LocalDate fromDate, LocalDate toDate
- int page = 0, int size = 20

**PaymentRequest.java**
- `@NotNull` Long orderId
- `@NotNull` BigDecimal amount
- `@NotBlank` String paymentMethod

**PaymentResponse.java**
- Long id, Long orderId, BigDecimal amount, PaymentStatus status, String gatewayReference, LocalDateTime processedAt

**CustomerProfileResponse.java**
- Long id, String fullName, String email, CustomerTier tier
- BigDecimal creditLimit, BigDecimal totalSpent
- Integer orderCount
- LocalDateTime memberSince

**OrderSummaryReport.java**
- Map<OrderStatus, Long> orderCountByStatus
- BigDecimal totalRevenue, BigDecimal averageOrderValue
- Integer totalOrders
- LocalDate fromDate, LocalDate toDate

#### Enums

**OrderStatus.java**
- DRAFT, CONFIRMED, PAID, SHIPPED, DELIVERED, CANCELLED

**PaymentStatus.java**
- PENDING, AUTHORIZED, CAPTURED, FAILED, REFUNDED

**CustomerTier.java**
- STANDARD, SILVER, GOLD, PLATINUM

#### Exceptions

**OrderNotFoundException.java** — extends RuntimeException
**InsufficientStockException.java** — extends RuntimeException
**PaymentDeclinedException.java** — extends RuntimeException
**CreditLimitExceededException.java** — extends RuntimeException

**GlobalExceptionHandler.java** — `@ControllerAdvice`
- `@ExceptionHandler(OrderNotFoundException.class)` → 404 with RFC 7807 ProblemDetail
- `@ExceptionHandler(InsufficientStockException.class)` → 409
- `@ExceptionHandler(PaymentDeclinedException.class)` → 422
- NOTE: Intentionally does NOT handle CreditLimitExceededException (demo bug for UC2)
- `@ExceptionHandler(MethodArgumentNotValidException.class)` → 400

#### Events

**OrderCreatedEvent.java** — contains Order reference, timestamp
**OrderCancelledEvent.java** — contains Order reference, reason, timestamp
**PaymentCompletedEvent.java** — contains Payment reference, timestamp

**OrderEventListener.java**
- `@TransactionalEventListener` handleOrderCreated(OrderCreatedEvent event) → calls NotificationService.sendOrderConfirmation()
- `@EventListener` handleOrderCancelled(OrderCancelledEvent event) → calls InventoryService.releaseReservation(), NotificationService.sendCancellationNotice()
- `@EventListener` handlePaymentCompleted(PaymentCompletedEvent event) → calls NotificationService.sendPaymentReceipt()

#### External Clients

**PaymentGatewayClient.java** — simulated external payment gateway
- charge(String paymentMethod, BigDecimal amount) → GatewayResponse
- refund(String gatewayReference) → GatewayResponse
- checkStatus(String gatewayReference) → PaymentStatus
- Uses: RestTemplate or @FeignClient annotation

**InventorySystemClient.java** — simulated external inventory system
- checkAvailability(Long productId, Integer quantity) → Boolean
- reserve(Long productId, Integer quantity) → String reservationId
- release(String reservationId) → void

**CrmClient.java** — simulated CRM system (Salesforce)
- getCustomerProfile(String email) → CrmCustomerDTO
  - CrmCustomerDTO contains: loyaltyPoints, lifetimeValue, segment, lastInteraction
- updateCustomerTier(Long customerId, CustomerTier newTier) → void

#### Config

**SecurityConfig.java** — `@Configuration`, `@EnableMethodSecurity`
- Configures HTTP basic auth, role-based access
- /api/reports/** requires ADMIN role
- All other /api/** requires USER role

**AsyncConfig.java** — `@Configuration`, `@EnableAsync`
- Custom thread pool: coreSize=5, maxSize=10, queueCapacity=25

**CacheConfig.java** — `@Configuration`, `@EnableCaching`
- Simple cache manager for customer profile caching

#### Validation

**OrderValidator.java**
- validateOrder(CreateOrderRequest request) → void
- Checks: non-empty items, valid quantities, no duplicate products

**CreditCheckValidator.java**
- validate(Customer customer, BigDecimal orderTotal) → void
- Throws: CreditLimitExceededException if orderTotal > customer.creditLimit

#### Mappers

**OrderMapper.java**
- toResponse(Order order) → OrderResponse
- toEntity(CreateOrderRequest request, Customer customer, List<Product> products) → Order

**CustomerMapper.java**
- toProfileResponse(Customer customer, List<Order> orders) → CustomerProfileResponse

#### application.yml

```yaml
spring:
  datasource:
    url: jdbc:h2:mem:orderdb
    driver-class-name: org.h2.Driver
  jpa:
    hibernate:
      ddl-auto: create-drop
    show-sql: true
  h2:
    console:
      enabled: true
server:
  port: 8080
```

Also include a `data.sql` with seed data: 5 customers (one per tier + one STANDARD), 10 products, a few sample orders.

---

## Module 2: ast-engine (JavaParser + Neo4j Ingestion)

A Java application that parses Module 1's source using JavaParser and ingests the AST into Neo4j.

### Dependencies (pom.xml)

- com.github.javaparser:javaparser-symbol-solver-core:3.25+
- org.neo4j.driver:neo4j-java-driver:5.x
- Spring Boot (for CLI runner)

### Neo4j Graph Schema

#### Node Types

| Node Label | Properties |
|------------|------------|
| :Package | name |
| :Class | name, fqn, annotations[], modifiers[], javadoc |
| :Interface | name, fqn, annotations[] |
| :Method | name, returnType, annotations[], modifiers[], lineStart, lineEnd |
| :Field | name, type, annotations[], modifiers[] |
| :Parameter | name, type, annotations[] |
| :Annotation | name, attributes{} |
| :Constructor | annotations[], modifiers[] |
| :EnumConstant | name |
| :Exception | name |
| :ExternalSystem | name, type |

#### Relationships

```
(:Package)-[:CONTAINS]->(:Class)
(:Class)-[:HAS_METHOD]->(:Method)
(:Class)-[:HAS_FIELD]->(:Field)
(:Class)-[:HAS_CONSTRUCTOR]->(:Constructor)
(:Class)-[:IMPLEMENTS]->(:Interface)
(:Class)-[:EXTENDS]->(:Class)
(:Class)-[:ANNOTATED_WITH]->(:Annotation)
(:Method)-[:ANNOTATED_WITH]->(:Annotation)
(:Method)-[:HAS_PARAMETER]->(:Parameter)
(:Method)-[:RETURNS]->(:Class)
(:Method)-[:THROWS]->(:Exception)
(:Method)-[:CALLS]->(:Method)              // resolved via JavaSymbolSolver
(:Method)-[:USES_FIELD]->(:Field)
(:Field)-[:OF_TYPE]->(:Class)
(:Class)-[:DEPENDS_ON]->(:Class)           // injection, field types
(:Method)-[:PUBLISHES]->(:Class)           // event publishing detection
(:Method)-[:LISTENS_TO]->(:Class)          // @EventListener detection
(:Class)-[:INTEGRATES_WITH]->(:ExternalSystem)
(:Method)-[:CALLS_EXTERNAL]->(:ExternalSystem)
(:Entity)-[:SOURCED_FROM]->(:ExternalSystem)
```

### Package: `com.demo.astengine`

#### parser/ProjectParser.java

- Takes source directory path as input
- Walks directory recursively, finds all .java files
- Creates JavaParser instance with JavaSymbolSolver configured
- For each .java file: parse → visit with ClassVisitor → collect AstNodes and AstRelationships
- Returns complete list of nodes and relationships

#### parser/ClassVisitor.java

- Extends VoidVisitorAdapter
- Visits ClassOrInterfaceDeclaration:
  - Extract: name, fully qualified name, modifiers, Javadoc
  - Extract all annotations with attributes
  - Detect if it's a controller, service, repository, entity, config based on annotations
  - Delegate to MethodVisitor for each method
  - Delegate to AnnotationVisitor for each annotation
  - Extract fields with types and annotations

#### parser/MethodVisitor.java

- Visits MethodDeclaration:
  - Extract: name, return type, parameters with types and annotations, modifiers
  - Extract all annotations (especially @Transactional, @Async, @Scheduled, @GetMapping, @PostMapping, etc.)
  - Extract thrown exceptions
  - Walk method body for method call expressions → build call targets
  - Detect: ApplicationEventPublisher.publishEvent() calls → extract event class → create PUBLISHES relationship
  - Detect: @EventListener methods → extract event parameter type → create LISTENS_TO relationship

#### parser/AnnotationVisitor.java

- Visits annotations on classes, methods, fields
- Extracts annotation name and all member-value pairs
- Special handling for Spring annotations to extract path values, methods, etc.

#### parser/DependencyResolver.java

- Uses JavaSymbolSolver to resolve types
- For each field in a class: resolve the type → create DEPENDS_ON relationship
- For constructor injection: detect constructor parameters → create DEPENDS_ON
- For each method call: resolve the declaring class → create accurate CALLS relationship
- Detect external system patterns:
  - Classes annotated with @FeignClient → create ExternalSystem node
  - Fields of type RestTemplate, WebClient → trace usage to identify external calls

#### parser/CallGraphBuilder.java

- Post-processing step after all classes are parsed
- Resolves method calls across classes using the symbol table
- Builds CALLS relationships between Method nodes
- Handles polymorphic calls (interface → implementation)

#### model/AstNode.java

- id (generated UUID)
- label (Class, Method, Field, etc.)
- properties (Map<String, Object>)

#### model/AstRelationship.java

- sourceId, targetId
- type (HAS_METHOD, CALLS, DEPENDS_ON, etc.)
- properties (Map<String, Object>)

#### neo4j/GraphSchemaInitializer.java

- Creates uniqueness constraints on (Class.fqn), (Interface.fqn), (Package.name)
- Creates indexes on (Method.name), (Annotation.name), (Field.name)
- Run once before ingestion

#### neo4j/Neo4jIngestionService.java

- Uses Neo4j Java Driver with sessions
- Batch ingestion using UNWIND:
  ```cypher
  UNWIND $nodes AS node
  MERGE (n:Class {fqn: node.fqn})
  SET n.name = node.name, n.annotations = node.annotations, ...
  ```
- Separate batches for: nodes by label, then relationships by type
- MERGE (not CREATE) for idempotent re-runs
- Transaction batching: 500 operations per transaction

#### neo4j/CypherTemplates.java

- Static methods returning parameterized Cypher strings
- mergeClass(), mergeMethod(), mergeField(), etc.
- createRelationship(type) for each relationship type

#### AstEngineApplication.java

- Spring Boot CLI application
- Arguments: `--source=/path/to/order-service/src --neo4j-uri=bolt://localhost:7687 --neo4j-user=neo4j --neo4j-password=password`
- Flow: initialize schema → parse source → ingest nodes → ingest relationships → print stats

---

## Module 3: graph-api (Query + Context Builder)

A Spring Boot service that queries Neo4j and serves structured context for the intelligence service and visualization data for the UI.

### Dependencies (pom.xml)

- Spring Boot Starter Web
- org.neo4j.driver:neo4j-java-driver:5.x
- Jackson (for JSON serialization)

### Package: `com.demo.graphapi`

#### controller/GraphQueryController.java

- `GET /api/graph/class/{name}` — getClassContext(@PathVariable String name) → ClassContext
- `GET /api/graph/call-chain/{className}/{methodName}` — getCallChain() → CallChainResponse
- `GET /api/graph/impact/{className}/{methodName}` — getImpactAnalysis() → ImpactAnalysisResponse
- `GET /api/graph/annotations/{annotationName}` — findByAnnotation() → List<AnnotatedElement>
- `GET /api/graph/data-lineage/{entityName}` — getDataLineage() → DataLineageResponse
- `GET /api/graph/classes` — listAllClasses() → List<ClassSummary> (for UI dropdowns)

#### controller/VisualizationController.java

- `GET /api/viz/class/{name}` → D3-compatible JSON: `{ nodes: [...], links: [...] }`
- `GET /api/viz/call-chain/{className}/{methodName}` → D3 graph of the call chain
- `GET /api/viz/full-graph` → full application graph (paginated)

#### controller/LlmContextController.java

- `GET /api/context/c4` → C4ContextPayload (for UC1)
- `GET /api/context/review/{className}` → ReviewContextPayload (for UC2)
- `GET /api/context/test/{className}/{methodName}` → TestContextPayload (for UC3)
- `GET /api/context/data-lineage/{entityName}` → DataLineageContextPayload (for UC4)
- `GET /api/context/raw-code/{className}` → raw source code string (for UC5 comparison)

#### service/GraphQueryService.java

Executes Cypher queries against Neo4j. Key queries:

**Full Class Context:**
```cypher
MATCH (c:Class {name: $className})
OPTIONAL MATCH (c)-[:HAS_METHOD]->(m:Method)
OPTIONAL MATCH (m)-[:CALLS]->(called:Method)<-[:HAS_METHOD]-(target:Class)
OPTIONAL MATCH (c)-[:HAS_FIELD]->(f:Field)-[:OF_TYPE]->(ft:Class)
OPTIONAL MATCH (c)-[:ANNOTATED_WITH]->(a:Annotation)
RETURN c, m, called, target, f, ft, a
```

**Endpoint-to-Database Trace:**
```cypher
MATCH path = (c:Class {name: $className})-[:HAS_METHOD]->(m:Method {name: $methodName})
             -[:CALLS*1..5]->(leaf:Method)
RETURN path
```

**Impact Analysis:**
```cypher
MATCH (changed:Class {name: $className})<-[:DEPENDS_ON*1..3]-(affected:Class)
RETURN affected.name,
  length(shortestPath((changed)<-[:DEPENDS_ON*]-(affected))) as distance
ORDER BY distance
```

**Cross-Cutting Concerns:**
```cypher
MATCH (m:Method)-[:ANNOTATED_WITH]->(a:Annotation {name: "Transactional"})
MATCH (c:Class)-[:HAS_METHOD]->(m)
RETURN c.name, m.name, m.returnType
```

**Missing @Transactional Detection (for UC2):**
```cypher
MATCH (m:Method)-[:CALLS]->(rm:Method)<-[:HAS_METHOD]-(repo:Class)
WHERE repo.name ENDS WITH 'Repository'
AND NOT EXISTS {
  (m)-[:ANNOTATED_WITH]->(:Annotation {name: 'Transactional'})
}
MATCH (c:Class)-[:HAS_METHOD]->(m)
RETURN c.name, m.name as potentialIssue, repo.name
```

**Layer Violation Detection (for UC2):**
```cypher
MATCH (ctrl:Class)-[:HAS_METHOD]->(m:Method)-[:CALLS]->(rm:Method)
WHERE ANY(a IN ctrl.annotations WHERE a = 'RestController')
MATCH (repo:Class)-[:HAS_METHOD]->(rm)
WHERE repo.name ENDS WITH 'Repository'
RETURN ctrl.name, m.name, repo.name as layerViolation
```

**Domain Data Lineage (for UC4):**
```cypher
MATCH (e:Class {name: $entityName})
OPTIONAL MATCH (e)<-[:OF_TYPE]-(f:Field)<-[:HAS_FIELD]-(owner:Class)
OPTIONAL MATCH (e)-[:SOURCED_FROM]->(ext:ExternalSystem)
OPTIONAL MATCH (repo:Class)-[:HAS_METHOD]->(m:Method)-[:RETURNS]->(e)
WHERE repo.name ENDS WITH 'Repository'
RETURN e.name,
  collect(DISTINCT {system: ext.name}) as externalSources,
  collect(DISTINCT {class: owner.name, field: f.name}) as usedIn,
  collect(DISTINCT repo.name) as repositories
```

#### service/ContextBuilderService.java

Assembles structured JSON context payloads for each use case. This is the core innovation — it transforms graph query results into rich, structured context that dramatically improves LLM output.

**C4 Context (UC1):** Queries system context (external systems), containers (packages by responsibility), components (classes with relationships), and call graph. Returns structured JSON:
```json
{
  "systemContext": {
    "systemName": "Order Service",
    "externalSystems": [
      {"name": "PaymentGateway", "type": "EXTERNAL_API", "integrationPoints": ["PaymentService.processPayment()"]}
    ]
  },
  "containers": [...],
  "components": {...},
  "callGraph": {...}
}
```

**Review Context (UC2):** Queries transactional coverage, audit logging coverage, security annotations, state transitions, dependency counts, exception handling. Returns:
```json
{
  "classUnderReview": "OrderService",
  "architecturalContext": {
    "transactionManagement": {
      "methodsWithTransactional": ["createOrder", "cancelOrder"],
      "methodsWithoutTransactional": ["updateOrderStatus"]
    },
    "auditLogging": {...},
    "stateTransitions": {...},
    "dependencyCount": 6,
    "godClassRisk": "MEDIUM"
  }
}
```

**Test Context (UC3):** Queries method signature, parameter validations (from DTO annotations), full call chain with exception types at each step, state transitions, related exception handler mappings. Returns:
```json
{
  "methodUnderTest": {
    "class": "OrderService",
    "method": "createOrder",
    "parameters": [{"type": "CreateOrderRequest", "validations": [...]}]
  },
  "callChain": [
    {"step": 1, "call": "CustomerService.getCustomer()", "canThrow": "CustomerNotFoundException"},
    ...
  ]
}
```

**Data Lineage Context (UC4):** Queries entity definition, downstream system integrations, internal service usage, repository queries. Returns:
```json
{
  "queryEntity": "Customer",
  "entityDefinition": {"fields": [...]},
  "downstreamIntegrations": [
    {"system": "CRM (Salesforce)", "client": "CrmClient", "methods": [...]}
  ],
  "internalUsage": {"servicesUsingCustomer": [...]}
}
```

---

## Module 4: intelligence-service (5 Use Case Engines + LLM)

A Spring Boot service that implements each use case as a pipeline: Graph Query → Context Assembly → Prompt Engineering → LLM Call → Output Formatting.

### Dependencies (pom.xml)

- Spring Boot Starter Web
- Spring Boot Starter WebFlux (for streaming LLM responses)
- HTTP client for Anthropic API
- Jackson

### Package: `com.demo.intelligence`

#### controller/IntelligenceController.java

- `POST /api/intelligence/c4` — generateC4Diagram(@RequestBody C4Request) → C4DiagramResult
  - C4Request: { level: "SYSTEM_CONTEXT|CONTAINER|COMPONENT" }
- `POST /api/intelligence/review` — reviewCode(@RequestBody ReviewRequest) → CodeReviewResult
  - ReviewRequest: { className: "OrderService" }
- `POST /api/intelligence/tests` — generateTests(@RequestBody TestRequest) → GeneratedTest
  - TestRequest: { className: "OrderService", methodName: "createOrder" }
- `POST /api/intelligence/data-lineage` — discoverData(@RequestBody DataRequest) → DataLineageResult
  - DataRequest: { entityName: "Customer", question: "Where is loyalty data?" }
- `POST /api/intelligence/compare` — compare(@RequestBody CompareRequest) → ComparisonResult
  - CompareRequest: { className: "OrderController", question: "What happens when I POST /api/orders?" }
  - Returns BOTH raw and AST responses side by side

#### engine/C4DiagramEngine.java

- Calls graph-api `/api/context/c4` to get structured context
- Builds prompt using C4Prompts template
- Calls Claude API
- Parses response to extract PlantUML/Structurizr DSL code blocks
- Returns C4DiagramResult with diagram code + rendered image URL

**Prompt template (C4Prompts.java):**
```
Given this architectural context extracted from the codebase AST graph, generate:
1. A C4 {level} diagram in PlantUML format
2. Use accurate names, relationships, and technologies from the context
3. Include async flows (events) as dashed arrows
4. Include external system integrations with correct names
5. Use proper C4 PlantUML includes and syntax

Context:
{contextJson}
```

#### engine/CodeReviewEngine.java

- Calls graph-api `/api/context/review/{className}`
- Builds prompt using ReviewPrompts template
- Calls Claude API
- Parses response into structured findings

**Prompt template (ReviewPrompts.java):**
```
You are a senior Java architect performing a code review.
Using the AST-extracted architectural context below, identify:

1. ARCHITECTURAL VIOLATIONS — layer breaches, missing patterns
2. CROSS-CUTTING GAPS — missing @Transactional, unhandled exceptions, audit gaps
3. STATE MANAGEMENT ISSUES — invalid transitions, missing guards
4. DESIGN CONCERNS — god classes, tight coupling, missing abstractions
5. SECURITY GAPS — unsecured endpoints, missing validation

For each finding provide: severity (CRITICAL/HIGH/MEDIUM/LOW), the specific code location, why it's a problem, and a recommended fix.

Architectural Context:
{contextJson}
```

#### engine/TestGenerationEngine.java

- Calls graph-api `/api/context/test/{className}/{methodName}`
- Builds prompt using TestPrompts template
- Calls Claude API
- Parses response to extract JUnit test code

**Prompt template (TestPrompts.java):**
```
Generate comprehensive JUnit 5 + Mockito functional tests for {className}.{methodName}().

Using the AST-extracted context below:
- Generate happy path test with all steps in the call chain verified
- Generate one test PER exception path identified in the call chain
- Generate boundary tests for each validation rule on the request DTO
- Generate state transition verification test
- Generate event publishing verification test
- Generate tier-based business logic tests (one per tier)
- Use realistic domain data (not "test123" or "foo/bar")
- Verify mock interactions in call chain order
- Use @DisplayName with descriptive test names

Method Context:
{contextJson}
```

#### engine/DomainDataEngine.java

- Calls graph-api `/api/context/data-lineage/{entityName}`
- Builds prompt using DataDiscoveryPrompts template
- Calls Claude API

**Prompt template (DataDiscoveryPrompts.java):**
```
A developer wants to answer: "{question}"

Using the AST-extracted data lineage context below:
1. Which downstream systems already have the relevant data? What specific fields?
2. Which internal services would need changes?
3. What's the recommended data flow — cache locally or fetch on demand?
4. What entity/DTO changes are needed?
5. What are the integration risks (data staleness, consistency, error handling)?
6. Provide a concrete implementation plan with code-level specificity.

Data Lineage Context:
{contextJson}
```

#### engine/ComparisonEngine.java

- For RAW: calls graph-api `/api/context/raw-code/{className}` to get concatenated source
- For AST: calls graph-api `/api/context/review/{className}` (or appropriate context endpoint)
- Sends BOTH to Claude API in parallel (using WebFlux)
- Returns ComparisonResult with both responses

**Raw prompt:**
```
Here is the source code for {className} and its dependencies:
{rawSourceCode}

Question: {question}
```

**AST prompt:**
```
Here is the architectural context for {className} extracted from our code intelligence graph:
{structuredContext}

Question: {question}
```

#### llm/ClaudeApiClient.java

- HTTP client calling Anthropic Messages API
- Endpoint: https://api.anthropic.com/v1/messages
- Model: claude-sonnet-4-20250514
- Headers: x-api-key, anthropic-version
- Supports both blocking and streaming responses
- Configurable: temperature, max_tokens
- Error handling with retries

#### llm/ResponseParser.java

- Extracts code blocks (```plantuml, ```java, ```cypher) from LLM response
- Parses structured findings from code review responses
- Extracts severity levels from review findings

#### model/ classes

**C4DiagramResult.java** — diagramCode (PlantUML string), level, generatedAt
**CodeReviewResult.java** — List<Finding> where Finding has: severity, category, location, description, recommendation
**GeneratedTest.java** — testCode (full JUnit class), testCount, coverageAreas[]
**DataLineageResult.java** — affectedSystems[], affectedServices[], implementationPlan, risks[]
**ComparisonResult.java** — rawResponse, astResponse, question, className

---

## React UI

### Dependencies (package.json)

- react, react-dom
- d3 (force-directed graph)
- axios (API calls)
- plantuml-encoder (for rendering PlantUML via server)
- react-syntax-highlighter (for code display)
- tailwindcss

### App.jsx

5-tab interface:
- Tab 1: C4 Diagrams
- Tab 2: Code Review
- Tab 3: Test Generation
- Tab 4: Domain Data Discovery
- Tab 5: Raw vs AST Comparison

### Components

**GraphVisualizer.jsx**
- D3 force-directed graph
- Fetch from `/api/viz/class/{name}` or `/api/viz/call-chain/{class}/{method}`
- Node colors: blue=Controller, green=Service, orange=Repository, purple=Entity, gray=other
- Click node → expand methods/fields/annotations
- Shows Cypher query at bottom

**C4Panel.jsx**
- Dropdown: Select C4 level (System Context / Container / Component)
- Button: Generate
- Output: Rendered PlantUML diagram (use plantuml.com server or local render)
- Side panel: GraphVisualizer showing the AST subgraph that produced the diagram

**CodeReviewPanel.jsx**
- Dropdown: Select class (populated from `/api/graph/classes`)
- Button: Run Review
- Output: List of findings with severity badges (🔴 CRITICAL, 🟠 HIGH, 🟡 MEDIUM, 🔵 LOW)
- Each finding: category, location, description, recommendation
- Side panel: GraphVisualizer highlighting the relevant nodes

**TestGenPanel.jsx**
- Dropdowns: Select class, then select method
- Button: Generate Tests
- Output: Syntax-highlighted JUnit test code
- Stats bar: test count, coverage areas
- Side panel: GraphVisualizer showing the call chain

**DataDiscoveryPanel.jsx**
- Dropdown: Select entity
- Text input: Question (e.g., "Where is loyalty data?")
- Button: Discover
- Output: Structured analysis with affected systems, services, implementation plan
- Side panel: GraphVisualizer showing data lineage

**ComparisonPanel.jsx** (The Demo Closer)
- Dropdown: Select class
- Text input: Question
- Button: Compare
- Split screen:
  - Left: "WITHOUT AST" — raw code response with red border
  - Right: "WITH AST" — structured context response with green border
- Both stream simultaneously

### API Service (api.js)

- Axios instance with baseURL pointing to intelligence-service
- Functions for each endpoint
- Error handling

---

## Intentional Demo Bugs in Order Service

These are deliberately planted for the Code Review (UC2) to discover:

1. **`OrderService.updateOrderStatus()`** — missing `@Transactional` but calls `OrderRepository.save()`
2. **`OrderService.updateOrderStatus()`** — accepts any state transition without validating against the state machine (CONFIRMED can go back to DRAFT)
3. **`OrderService.updateOrderStatus()`** — does NOT call `AuditService.logAction()` (inconsistent with createOrder/cancelOrder)
4. **`GlobalExceptionHandler`** — does NOT handle `CreditLimitExceededException` (returns 500 instead of 422)
5. **`NotificationService`** `@Async` methods — no error handling / no try-catch
6. **`ReportController.getOrderSummary()`** — missing `@PreAuthorize` (inconsistent with getRevenueByPeriod)
7. **`OrderService`** — has 6 injected dependencies (borderline god class)

These bugs should NOT be obvious from reading the code casually — they should only be discoverable through architectural analysis (which is exactly what the AST graph enables).

---

## Demo Script for Leadership (15 Minutes)

| Min | Use Case | What You Show | What You Say |
|-----|----------|---------------|--------------|
| 0-2 | Setup | Run order service, show Neo4j graph, click through AST | "We parse code into a queryable architecture graph" |
| 2-5 | UC1: C4 | Generate all 3 C4 levels, show accuracy | "Architecture docs auto-generate from code and never go stale" |
| 5-7 | UC2: Review | Run review on OrderService, show CRITICAL/HIGH findings | "We catch architectural violations before production — things human reviewers miss" |
| 7-9 | UC3: Tests | Generate tests for createOrder, count 15 vs 3 | "From 3 generic tests to 15 targeted tests covering every path — automatically" |
| 9-11 | UC4: Data | Ask about loyalty points, show lineage | "Developers find what data exists across systems in seconds, not days" |
| 11-13 | UC5: Proof | Split-screen comparison, same question | "Same LLM, dramatically different quality — this is the difference" |
| 13-15 | Vision | Connect to SCG platform | "Imagine this across every service in our estate. That's what we're building." |

---

## Success Criteria

1. Neo4j graph accurately represents Order Service architecture (classes, methods, calls, annotations, external systems)
2. C4 diagrams generated from AST context match actual code structure (not generic templates)
3. Code review findings identify real architectural issues (missing @Transactional, layer violations, state machine gaps, the 7 planted bugs)
4. Generated tests cover 12-15 scenarios vs 2-3 from raw code, including all exception paths and validation rules
5. Domain data discovery correctly identifies which downstream systems hold specific data fields
6. Split-screen comparison makes the quality difference immediately obvious
